<!--
Mais um produto das organiza��es PsMj
*********************
PsMj (TM) Corp. 2001 - 2004
PSMJ FREESOFTWARE (C) 2001-2004, O pr�prio. WDD(R) - WebDesignDepartament
ver. 2004/02
*********************
POWERED BY GVIM (R)
-->
<html>
	<head>
		<title>Ger�ncia e Administra��o de Projetos: Analisando o Planner</title>
		<link rel="stylesheet" href="style.css" type="text/css" />
	</head>
	<body>

		<div>
			<center><h1>..::Home-Page Do Laborat&oacute;rio::..</h1></center>			
		</div>
		
		<center>
		PROJETO LABORATORIO DE GERENCIA DE PROJETOS<br>
		LAB-GAP1<br>
		Prof. Carlos Morais<br>
		<br>
		Trabalho a ser realizado nas aulas de 14 e 16 de junho.<br>
		Laboratorio IBM - Sala 102
		</center>

		<div>
			<center><h2>..::GRUPO G1::..</h2></center>
			Representantes: Raulito Sena, Mairo Pedrini, &Eacute;verton Foscarini, Peter Elbern, 
			Leandro Gallina, Paulo S&eacute;rgio.
			
		</div>

		<div>
			<center><h2>..::Produto Escolhido::..</h2></center>
			O produto escolhido para an�lise foi o <b>Planner</b>. O <b>Planner</b> � uma ferramenta
			de Ger�ncia de Projetos para Linux que serve para planejar, agendar e rastrear
			projetos. 
		</div>
		<div>
			<center><h2>..::Aloca��o de Recursos::..</h2></center>

  			<table border="1">
				<tr>
		   			<td align="center">Aluno</td>
					<td align="center">Tarefa</td>
		     		</tr>
				<tr>
					<td>Paulo S�rgio</td>
					<td>Coordena��o geral e desenvolvimento da p�gina final.</td>
				</tr>
				<tr>
					<td>Raulito Sena</td>
					<td>Elabora��o do Plano de Testes e do Relat�rio de Aceita��o do <b>Planner</b>.</td>
				</tr>
				<tr>
					<td>Mairo Pedrini</td>
					<td>Elabora��o do Plano de Testes e do Relat�rio de Aceita��o do <b>Planner</b>.</td>
				</tr>
				<tr>
					<td>�verton Foscarini</td>
					<td>Obten��o, instala��o e elabora��o Manual do Laborat�rio</td>
				</tr>
				<tr>
					<td>Marco Furlanetto</td>
					<td>Obten��o, instala��o e elabora��o Manual do Laborat�rio</td>
				</tr>
			</table>

			<br><br>Obs.: Os alunos Leandro Gallina e Peter Elbern foram realocados para outro grupo
			que no momento da atividade estava com n�mero reduzido de alunos. 

		</div>
		<div>
			<center><h2>..::P�ginas Produzidas::..</h2></center>
			Links para os relat�rios produzidos: <br><br>
			<a href=relatorioAvaliacao.php>Relat�rio de Avalia��o</a><br><br>
			<a href=manualdolaboratorio.php>Manual do Laborat�rio</a>
		</div>
	</body>
</html>
