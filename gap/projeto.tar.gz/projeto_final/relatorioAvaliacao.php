<html>
	<head>
		<title>Ger�ncia e Administra��o de Projetos: Analisando o Planner</title>
		<link rel="stylesheet" href="style.css" type="text/css" />
	</head>
	<body>

	<div>
		<center><h1>..::Relatorio de Avalicao::..<h1></center>
		Checklist de Avaliacao<br><br> 
  			<table border="1">
				<tr>
		   			<td align="center">Item</td>
					<td align="center">OK?</td>
		     		</tr>
				<tr>
					<td>Definir Tarefas e Recursos</td>
					<td>Sim</td>
				</tr>
				<tr>
					<td>Definir Inicio e Duracao das Tarefas</td>

					<td>Sim</td>
				</tr>
				<tr>
					<td>Definir Calendarios de Trabalho</td>
					<td>Sim</td>
				</tr>
				<tr>

					<td>Alocar Recursos a Execucao de Tarefas</td>
					<td>Sim</td>
				</tr>
				<tr>
					<td>Controle de Utilizacao dos Recursos</td>
					<td>Sim</td>
				</tr>
				<tr>
					<td>Controle de Deadline e Andamento de Cada Tarefa</td>
					<td>Sim</td>
				</tr>
				<tr>
					<td>Controle de Atrasos</td>
					<td>Nao</td>
				</tr>
				<tr>
					<td>Gerencia de Riscos</td>
					<td>Nao</td>
				</tr>
			</table>


	
	</div>
	
	</body>
</html>
