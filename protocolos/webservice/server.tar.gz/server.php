<?php
	require('nusoap.php');

	$server = new soap_server;

	$server->register('soma');
	$server->register('mult');

	function soma($op1,$op2)
	{
		if( (!is_int($op1)) && (!is_float($op1)) )
		{
			return new soap_fault('Client','','The parameters for soma must be a number!!');
		}	
		if( (!is_int($op2)) && (!is_float($op2)) )
		{
			return new soap_fault('Client','','The parameters for soma must be a number!!');
		}	

		return $op1 + $op2;
	}

	function mult($op1,$op2)
	{
		if( (!is_int($op1)) && (!is_float($op1)) )
		{
			return new soap_fault('Client','','The parameters for soma must be a number!!');
		}	
		if( (!is_int($op2)) && (!is_float($op2)) )
		{
			return new soap_fault('Client','','The parameters for soma must be a number!!');
		}	

		return $op1 * $op2;
	}

	$server->service($HTTP_RAW_POST_DATA);
?>
