<?php
	require('nusoap.php');

	$mult1 = 9;
	$mult2 = 5;

?>

<html>
<head>
	<title>WebServices - Soma e Multiplica��o</title>
</head>

<body>
	<p> Requisitando 2 + 2: </p>
	<?php
		$soma1 = 2;
		$soma2 = 2;

		$c = new soapclient('http://143.54.12.59/~sergio/atividade_webservice/server.php');

		$parameters = array( 'op1' => $soma1, 'op2' => $soma2);

		$result = $c->call('soma',$parameters);

		echo "<b>Resultado = </b><i><b>". $result ."</b></i><br>"; 

	?>
	<p> Requisitando 9 * 5: </p>
	<?php
		$mult1 = 9;
		$mult2 = 5;

		$c = new soapclient('http://143.54.12.59/~sergio/atividade_webservice/server.php');

		$parameters = array( 'op1' => $mult1, 'op2' => $mult2);

		$result = $c->call('mult',$parameters);

		echo "<b>Resultado = </b><i><b>". $result ."</b></i><br>"; 

	?>

</body>

</html>
