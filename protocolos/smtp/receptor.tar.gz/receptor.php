<html>
 <head>
  <title>PSMJ FreeSoftware (c) Webmail Receiver</title>
 </head>
 <body>
 
<?php 

$login = array( "server" =>'',
		"usuario" => '',
		"pass" => '');
$contexto = "";
		
function get_all_data() {
	global $_GET;
	global $login;
	global $contexto;

	foreach( $login as $id => $v )
	{
		if(!isset($_GET[$id]))
			return false;
		else
		{
			$login[$id] = $_GET[$id];
			if( $contexto != '' )
			{
				$contexto .= "&";
			}
			$contexto .= "$id=" . $_GET[$id];
		}
	}
	return true;
}

function conect_pop() 
{
	global $login;
	
	$servidor = $login['server'];
	$porta = 110;
	$address = gethostbyname ($servidor);
	$user = $login['usuario'];
	$pass = $login['pass'];
	
// Create a TCP/IP socket.
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if ($socket < 0) 
	{
	   echo "socket_create() failed: reason: " . socket_strerror($socket) . "\n";
	   exit();
	} 
	else ;

	$result = socket_connect($socket, $address, $porta);
	if ($result < 0) 
	{
	   echo "socket_connect() failed.\nReason: ($result) " . socket_strerror($result) . "\n";
	   exit();
	} 
	else ;

	$sock = $socket;

	$request_user = "USER " . $user . "\n";
	$set_pass = "PASS ". $pass . "\n";
	
	$out = socket_read($socket,1024); //Resposta inicial do servidor

	socket_write($socket, $request_user, strlen($request_user));
	$out = socket_read($socket,1024);

	socket_write($socket, $set_pass, strlen($set_pass));
	$out = socket_read($socket,1024);
	if ( !preg_match("/\+OK/",$out) )
	{	
		echo "<br><br><b>Usu�rio Inv�lido ou Senha Incorreta. Verifique.</b><br>";
		exit();
	}
	
	return $socket;
}

function imprime_lista_email($so)
{
	global $contexto;
	global $login;

	$list = "LIST\n";
	
	socket_write($so, $list, strlen($list));
	
	while ( $out = socket_read($so,1024) )
	{
		$lista .= $out;
		if ( preg_match("/\./",$out) )
			break;
	}	
	
	$emails = explode( "\n", $lista );

	$msg = array();
	
	foreach($emails as $i => $c )	
	{
		if ( !preg_match("/\+OK/",$c) && !preg_match("/\./",$c) && !ctype_space($c) )
		$msg [] = $c;
	}

	echo "<form action=\"receptor.php?\" method=\"get\">";
	echo "<input type=\"hidden\" name=\"usuario\" value=\"" . $_GET ['usuario'] . "\">";
  	echo "<input type=\"hidden\" name=\"pass\" value=\"" . $_GET ['pass'] . "\">";
  	echo "<input type=\"hidden\" name=\"server\" value=\"" . $_GET ['server'] . "\">";

	echo "<table border=\"1\">
		<tr>
			<td>Check</td> <td>Id</td> <td>Assunto</td> <td>Tam</td>
		</tr> ";

	$lista = array();
	
	foreach( $msg as $i => $c )
	{
		ereg("([0-9]*) ([0-9]*)",$c,$regs);

		$subject = get_subject($so,$regs[1]);
		
		echo "<tr>
			<td> <input type=\"checkbox\" name=\"lista_del[]\" value=\"$regs[1]\"> </td> <td>". $regs[1] . "</td> <td> $subject </td> " . "<td>". $regs[2] ."</td> <br>
		      </tr>";
	}
	echo "</table>";
	echo "<input type=\"submit\" name=\"del\" value=\"Deletar\">";
	echo "</form>";
}

function quit_pop($socket)
{
	socket_write($socket, "QUIT\n", strlen("QUIT\n"));
	$out = socket_read($socket,1024);

	socket_close($socket);
}

function init_form()
{
?>
<form action="receptor.php" method="get">
<input type="hidden" name="action" value="none">
	<table>
	<tr>
		<td>Usuario: </td><td><input type="text" name="usuario"></td><br>
	</tr>
	<tr>
		<td>Senha: </td><td> <input type="password" name="pass"></td><br>
	</tr>
	<tr>
		<td>Servidor:</td> <td><input type="text" name="server"></td><br>
	</tr>
	<tr>
		<td></td><td><input type="submit" value="Login"></td><br>
	</tr>
	</table>
</form>
<?

}

function imprime_cabecalho()
{
	global $login;
	global $contexto;

	echo "<html>
	<body>
		Ol� " . $login['usuario'] . "!! Bem-vindo ao ".$login['server'] . ".<br>";
//	</body>
//	</html> ";
}

function apaga_email($socket,$lista)
{
	global $contexto;

	$problem = false;
	for($i=0; $i<count($lista); $i++)
	{
		socket_write($socket,"DELE ". $lista[$i] . "\n");
		$rsp = socket_read($socket,1024);
		if ( !preg_match("/\+OK/",$rsp) )
		{
			echo "Problemas ao excluir mensagem ".$lista[$i]."<br>";
			$problem = true;
			continue;
		}
	}

	if (!$problem)
		echo "Todas as mensagens selecionadas foram exclu�das com sucesso!!";
	
	echo "<br><a href=\"receptor.php?$contexto\">voltar</a><br>";
 
}

function get_subject($socket, $id)
{
	
	socket_write($socket,"RETR $id\n",strlen("RETR $id\n"));

	$out= "";

	while( $resp = socket_read($socket,1024) )
	{
		$out .= $resp;
		if(substr($out,-4) == "\n.\r\n")
		{
			ereg("Subject: ([^\r\n]*)", $out, $reg);
			return $reg[1];
		}
	}

	return "";
}

//MAIN:
if( !get_all_data() ) 
{
	init_form();
} 
else 
{
	$socket = conect_pop ();

	imprime_cabecalho();

	if(isset($_GET['del']))
	{
		$msgs = $_GET['lista_del'];
		apaga_email($socket,$msgs);
	}
	else
		imprime_lista_email($socket);

	quit_pop($socket);
}

 
?>
</body>
</html>
