/*
 * UNIVERSIDADE FEDERAL DO RIO GRANDE DO SUL
 * INSTITUTO DE INFORM�TICA
 * 
 * AUTOR: Paulo S�rgio Morandi J�nior
 * AUTOR: Andre Suslik Spritzer
 * E-MAIL interno da inform�tica: sergio@
 * E-MAIL interno da inform�tica: spritzer@
 * E-MAIL: psmorandi@yahoo.com.br
 * E-MAIL: suslik@terra.com.br
 *
 * pingRequest-1-FINAL.c
 *
 * Atrav�s do comando PING REQUEST, via ICMP e por 
 * BROADCAST, descobrir quais as m�quinas ativas na rede
 * imprimindo o nome e o IP da mesma.
 *
 *         GNU GENERAL PUBLIC LICENSE
 *         
 * Copyright (c) 2004 Paulo S�rgio Morandi J�nior, Andre Suslik Spritzer
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software 
 * Foundation, INC., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * */
#include "ping_defines.h"

/*
 * CHECK SUM PROCEDURE. THIS PROCEDURE IS STRONGLY
 * BASED ON THE PROCEDURE FROM THE BOOK "UNIX NETWORK PROGRAMMING"
 * W. RICHARD STEVENS, PAGE 455. See... 
 * */
unsigned short int check_sum(unsigned short int *msg, int len)
{
	unsigned short int *tmp_msg = msg;
	unsigned int sum = 0;
	unsigned short int answer;
	
	while (len > 1) 
	{
		sum += *tmp_msg++;
		len -= 2;
	}
	
	if (len == 1)
		sum += *(unsigned char *) msg;
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	answer = ~sum;
	return (answer);
}

//Devolve o nome dado um sockaddr_in (para pegar o end. ip)
char *get_host_name( struct sockaddr_in recv )
{
	struct hostent *hostname;

	hostname = gethostbyaddr((char *)&recv.sin_addr.s_addr,sizeof(recv.sin_addr.s_addr),AF_INET);

	if( hostname != NULL )
		return hostname->h_name;
	else
		return (char *)inet_ntoa(recv.sin_addr);

	return NULL;
}

//Devolve o ip em string...
char *get_ip_addr( struct sockaddr_in recv )
{
	return (char *)inet_ntoa(recv.sin_addr);
}

void ping_recv ( int sock )
{
	time_t ini, fim;	
	int n;
	int fromSize;
	_icmp recv_icmp;
	char buffer[RCV_BUFFER_SIZE]; //Para receber as msgs...
	struct sockaddr_in from;
	int ip_header_size;
	int cksum;
	
//	printf("They wanna say \"Hello\" to you....\n");
	ini = time(NULL);
	fim = ini + 15;
	while( time(NULL) < fim  )
	{
		fromSize = sizeof(from);
#ifdef DEBUG
		printf("DEBUG: Preparing to recieve...\n");
#endif
		n = recvfrom(sock,buffer,RCV_BUFFER_SIZE,0,(struct sockaddr *) &from, &fromSize );
		if( n < 0 && errno == EINTR ) 
		{
//			fprintf(stderr,"ping: recvfrom error!!!\n");
			continue;
		}

#ifdef DEBUG
		printf("N = %i\n", n);
#endif
		//Pesquisando o tamanho do cabe�alho IP....
		ip_header_size = (int) buffer[0];
		ip_header_size = 4 * ( (ip_header_size & 0x0f) );

		memcpy(&recv_icmp, buffer + ip_header_size, n - ip_header_size);
#ifdef DEBUG
	printf("DEBUG: Checking if ICMP package was created corretly RECEIVED...\n");
	printf("Type of Msg: %s",(((recv_icmp.type) == ICMP_ECHO)? "ECHO REQUEST\n":"NONE\n") );
	printf("Type of subcode: %i\n",recv_icmp.code);
	printf("Checksum: %i\n",recv_icmp.checksum);
	printf("Proc ID: %i\n",recv_icmp.id);
	printf("Seq. Number: %i\n",recv_icmp.sequence);
#endif
		//Calculando o check sum do pacote recebido....
		cksum = check_sum((unsigned short int *)&recv_icmp,sizeof(recv_icmp));
		if ( cksum != 0 )
		{
			//O check sum do pacote recebido com outro checksum 
			//deve ser 0..
//			fprintf(stderr,"ping: checksum error!! Bad things received...\n");
			continue;
		}

		if ( (recv_icmp.type != 0) || (recv_icmp.code != 0) )
		{
//			fprintf(stderr,"ping: Not an ICMP ECHO REPLAY message... Ignoring...\n");
			continue;
		}

		if ( recv_icmp.id != getpid() )
		{
//			fprintf(stderr,"ping: It's not for me... Don't be curious...\n");
			continue;
		}
		
//		printf("Hi, I'm %s and my IP is %s\n",get_host_name(from), get_ip_addr(from));
		printf("%s %s\n",get_host_name(from), get_ip_addr(from));
	}
}

void ping_send(int sock, struct sockaddr_in dest)
{
	_icmp icmp; 
	struct timeval t;

	//Criando o pacote ICMP para mandar a mensagem ICMP_ECHO_REQUEST
	icmp.type = ICMP_ECHO;  //ICMP ECHO REQUEST..
	icmp.code = 0;
	icmp.id = getpid();
	icmp.sequence = num_sequence++;
	icmp.checksum = 0;

	//Completando a estrutura para o checksum....
	gettimeofday(&t,NULL);
	icmp.t_time.tv_usec = t.tv_usec;
	icmp.t_time.tv_sec = t.tv_sec;

	icmp.checksum = check_sum( (unsigned short int *)&icmp, sizeof(icmp) );

#ifdef DEBUG
	printf("DEBUG: Checking if ICMP package was created corretly...\n");
	printf("Type of Msg: %s",(((icmp.type) == ICMP_ECHO)? "ECHO REQUEST\n":"NONE\n") );
	printf("Type of subcode: %i\n",icmp.code);
	printf("Checksum: %i\n",icmp.checksum);
	printf("Proc ID: %i\n",icmp.id);
	printf("Seq. Number: %i\n",icmp.sequence);
#endif
	//Enviando o broadcast...
	sendto(sock, (char *)&icmp,sizeof(icmp),0,(struct sockaddr *)&dest,sizeof(dest) );
}

void setup_socket(int *sock, struct sockaddr_in *destiny )
{
	int pingB;
	struct protoent *protocol; //Para procurar o protocolo ICMP
	
	//Verifica se o sistema tem o protocolo implementado
	if( (protocol = getprotobyname("icmp")) == NULL )
	{
		//fprintf(stderr,"UNKNOWN PROTOCOL: ICMP\nYour system probably don't support ICMP protocol...\n");
		exit(-1);
	}

	//Verifica se o sistema permite criar um RAW SOCKET e cria o socket
	if ( (*sock = socket(PF_INET, SOCK_RAW, protocol->p_proto)) < 0 ) 
	{
		//fprintf(stderr,"ping: CANNOT CREATE A RAW SOCKET\nYou probably should be root to do that...\n");
		exit(-1);
	}
	else
#ifdef DEBUG
		printf("DEBUG: Socket Created!!!!!....\n")
#endif
	;

	//Configurando socket para msg de broadcast...
	setsockopt(*sock, SOL_SOCKET, SO_BROADCAST, &pingB,sizeof(pingB));

	memset(destiny, 0, sizeof(destiny) );
	
	//Configurando destino de broadcast...
	destiny->sin_family = AF_INET;	//Familia de protocolos
	destiny->sin_addr.s_addr = INADDR_BROADCAST;  //Endere�o de Broadcast
//	destiny->sin_addr.s_addr = inet_addr("143.54.12.255");	

#ifdef DEBUG
		printf("DEBUG: destiny well configured...\n");
#endif
}

int main( int argc, char** argv )
{
	struct sockaddr_in destiny;
	int sock;

	//printf("PsMj FreeSoftware 2004\nThis program comes with ABSOLUTELY NO WARRANTY and it's free software;\nfor more details see the GNU General Public License\nPING REQUEST via ICMP e BROADCAST ver. 0.0 BETA 3\nUso v�lido somente como root\n\n");

	//printf("Wait until setup....");
	setup_socket(&sock,&destiny);
	//printf("Setup done succefull...\n");


	//printf("Sending ICMP Broadcast......\n");
	ping_send(sock,destiny);
	
	//printf("Waiting responses.... This may take a while....\n");
	ping_recv(sock);
	
	return 0;
}
