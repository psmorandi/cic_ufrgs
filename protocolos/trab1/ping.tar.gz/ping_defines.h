/*
 * UNIVERSIDADE FEDERAL DO RIO GRANDE DO SUL
 * INSTITUTO DE INFORM�TICA
 * 
 * AUTOR: Paulo S�rgio Morandi J�nior
 * E-MAIL interno da inform�tica: sergio@
 * E-MAIL: psmorandi@yahoo.com.br
 *
 * ping_defines.h
 *
 * Arquivo de defini��es do pingRequest-1-Final.c 
 * Cria�ao de estruturas e defini�oes de fun�oes
 *
 *         GNU GENERAL PUBLIC LICENSE
 *         
 * Copyright (c) 2004 Paulo S�rgio Morandi J�nior
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software 
 * Foundation, INC., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * */
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/ip_icmp.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netdb.h>
#include <errno.h>
#include <time.h>

//#define DEBUG
#define RCV_BUFFER_SIZE 1024

typedef struct __icmp {
	unsigned char type;
	unsigned char code;
	unsigned short int checksum;
	unsigned short int sequence;
	unsigned short int id;
	struct timeval t_time;
} _icmp;

int num_sequence = 0;

unsigned short int check_sum(unsigned short int *msg, int len);
void ping_send(int sock, struct sockaddr_in destiny);
void setup_socket(int *sock, struct sockaddr_in *destiny );
void ping_recv ( int sock );
