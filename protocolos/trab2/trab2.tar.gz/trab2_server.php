<?php
	
	require_once('nusoap.php');

	$servidor = new soap_server;

	$servidor->register('ping');

	function ping()
	{
		$program = `./pingTrab2`;
		
		$hosts = array();

		$p = explode("\n",trim($program));

		foreach($p as $i)
		{
			$line = explode(" ",$i);
			$hosts[] = array( 0 => $line[1], 1 => $line[0] );
		}

		return $hosts;
	}

	$servidor->service($HTTP_RAW_POST_DATA);
?>
