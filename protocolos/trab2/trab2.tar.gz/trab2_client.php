<?php
	require_once('nusoap.php');

	$soapclient = new soapclient('http://localhost/~sergio/trab2/trab2_server.php');
?>

<html>

<head>
	<title>Trabalho 2 - WebServices</title>
</head>

<body>

<h2>INF01002 - Protocolos de Comunica��o</h2>

<h4>Alunos: Andr� Spritzer (0297/01-0) e Paulo S�rgio Morandi J�nior (2767/01-1)</h4>

<p>Teste do Ping :) </p>

<?php
	echo "<table border=1>";
	
	$result = $soapclient->call('ping');

	if (!$err = $soapclient->getError()) 
	{
		echo $err;
	}

	echo "<tr> 
		<td>IP</td> <td>NOME</td>
		</tr>";

	foreach( $result as $i => $name )
	{
		echo "<tr>";
			echo "<td>".$name[0]."</td> <td>".$name[1]."</td>";
		echo "</tr>";
	}

	echo "</table>";
?>

</body>
