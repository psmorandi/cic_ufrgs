<html>
 <head>
  <title>PsMj FreeSoftware (c) Webmail Compose</title>
 </head>
 <body>
 <?php 

function send_email($origem, $destino, $cab, $data) {
	
#	$servidor = "smtp.inf.ufrgs.br";
	$servidor = "localhost.localdomain";
	$porta = 25;
	
	$address = gethostbyname ($servidor);
	

/* Create a TCP/IP socket. */
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if ($socket < 0) {
	   echo "socket_create() failed: reason: " . socket_strerror($socket) . "\n";
	} else {
	   echo "OK.\n";
	}


	
	$result = socket_connect($socket, $address, $porta);
	if ($result < 0) {
	   echo "socket_connect() failed.\nReason: ($result) " . socket_strerror($result) . "\n";
	} else {
	   echo "OK.\n";
	}

	$helo = "HELO localhost\n";
	$mail = "MAIL FROM:".$origem."\n";
	$recp = "RCPT TO:".$destino."\n";
	$dados = "DATA\n";
	$dados_ef = "Subject: ".$cab."\n".$data."\n.\n";
	
	
	$out = socket_read($socket,1024);
	socket_write($socket, $helo, strlen($helo));
?>
	<br>
<?
	$out = socket_read($socket,1024);
	echo $out;

	socket_write($socket, $mail, strlen($mail));
?>
	<br>
<?
	$out = socket_read($socket,1024);
	echo $out;

	socket_write($socket, $recp, strlen($recp));
?>
	<br>
<?
	$out = socket_read($socket,1024);
	echo $out;

	socket_write($socket, $dados, strlen($dados));
?>
	<br>
<?
	$out = socket_read($socket,1024);
	echo $out;

	socket_write($socket, $dados_ef, strlen($dados_ef));
?>
	<br>
<?
	$out = socket_read($socket,1024);
	echo $out;

	socket_write($socket, "QUIT\n", strlen("QUIT\n"));
?>
	<br>
<?
	$out = socket_read($socket,1024);
	echo $out;
?>
	<br>
<?
	echo "SUA MENSAGEM FOI ENVIADA COM SUCESSO";
?>
	<br>
<?

	echo "Closing socket...";
	socket_close($socket);
	echo "OK.\n\n";

}

if ( !isset($_POST['data']) ) {
?>
<form action="send_mail.php" method="post">
	<table>
		<tr>
			<td>Origem </td> <td><input type="text" name="org"><br></td>
		</tr>
		<tr>
			<td>Destino </td> <td><input type="text" name="dest"><br></td>
		</tr>
		<tr>
			<td>Subject </td> <td><input type="text" name="cabecalho" size=35><br></td>
		<tr>
			<td>Mensagem </td> <td><input type="text" name="data"><br></td>
		</tr>
		<tr>
			<td> </td> <td><input type="submit" value="Enviar"></td>
		</tr>
	</table>
</form>

<?

} else {

	$destino = $_POST ['dest'];
	$origem = $_POST ['org'];
	$cab = $_POST ['cabecalho'];
	$data = $_POST['data'];

	send_email ($origem,$destino,$cab,$data);

}
 ?>



</body>
</html>
