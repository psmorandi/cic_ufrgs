#ifndef ESTATICA_HPP
#define ESTATICA_HPP

/*
class BoardState
{

	class StackElement
	{
		public:

		int i;
		int j;
		int elm;
		int up;
		int down;
		int right_up;
		int right_down;
		int left_up;
		int left_down;

		StackElement()
		{
		}
		StackElement(int ci, int cj, int celm, int cup, int cdown, int cright_up, int cright_down, int cleft_up, int cleft_down)
		{ 
			i = ci;
			j = cj;
			elm = celm;
			up = cup;
			down = cdown;
			right_up = cright_up;
			right_down = cright_down;
			left_up = cleft_up;
			left_down = cleft_down;	
		}
		~StackElement()
		{
		} 
	};

	class Stack
	{
		public:

		int top;
	
		StackElement * stack [MAXHEIGHT+1];

		Stack()
		{
			top = 0;
		}
		void push(BoardState * s, int i, int j)
		{
			StackElement * el = new StackElement(i, j, s->board[i][j], s->board[i-1][j+1], s->board[i+1][j-1], s->board[i][j+1], s->board[i+1][j], s->board[i-1][j], s->board[i][j-1]);
			stack[top] = el;
			top++;
		}
		void pop(BoardState * s)
		{
			top--;
			int i;
			int j;
			i = stack[top]->i;
			j = stack[top]->j;
			s->board[i-1][j+1] = stack[top]->up;
			s->board[i+1][j-1] = stack[top]->down;
			s->board[i][j+1] = stack[top]->right_up;
			s->board[i+1][j] = stack[top]->right_down;
			s->board[i-1][j] = stack[top]->left_up;
			s->board[i][j-1] = stack[top]->left_down;
			s->board[i][j] = stack[top]->elm;
			delete stack[top];
		}
	};
	
	// Atributos
	public:
	int board [TAM][TAM];
 	int pesos [TAM][TAM];
	int player;
	bool line;
	int enemy;
	Stack board_stack;
	//static const int empty = 0;

	// Construtores
	public:
	BoardState()
	{
		player = HOMEM;
		enemy = COMPUTADOR;
		line = true;
		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				board[i][j] = LIVRE;
				pesos[i][j] = 0;    
			}
		}
	}

	BoardState(int *state, int player, bool line)
	{
		this->player = player;
		switch(player)
		{
			case HOMEM : {enemy = COMPUTADOR; break;}
			case COMPUTADOR : {enemy = HOMEM; break;}
		}
		this->line = line;
		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				board[i][j] = *(state + TAM*i  + j);
			}
		}
	}

	BoardState(int player, bool line)
	{
		this->player = player;
		switch(player)
		{
			case HOMEM : {enemy = COMPUTADOR; break;}
			case COMPUTADOR : {enemy = HOMEM; break;}
		}
		this->line = line;
	}

	// Metodos
	public:

	void putPiece(int i, int j)
	{
		board_stack.push(this, i, j);
		board[i][j] = player;

		if (board[i-2][j+1] == player)
		{
			if (((board[i-1][j] == 0)||(board[i-1][j] == player + 5)) && ((board[i-1][j+1] == 0)||(board[i-1][j+1] == player + 5)))
			{
				board[i-1][j] = player + 5;
				board[i-1][j+1] = player + 5;
			}
		}

		if (board[i-1][j-1] == player)
		{
			if (((board[i-1][j] == 0)||(board[i-1][j] == player + 5)) && ((board[i][j-1] == 0)||(board[i][j-1] == player+5)))
			{
				board[i-1][j] = player + 5;
				board[i][j-1] = player + 5;
			}
		}

		if (board[i+1][j-2] == player)
		{
			if (((board[i][j-1] == 0)||(board[i][j-1] == player + 5)) && ((board[i+1][j-1] == 0)||(board[i+1][j-1] == player + 5)))
			{
				board[i][j-1] = player + 5;
				board[i+1][j-1] = player + 5;
			}
		}

		if (board[i+2][j-1] == player)
		{
			if (((board[i+1][j-1] == 0)||(board[i+1][j-1] == player + 5)) && ((board[i+1][j] == 0)||(board[i+1][j] == player + 5)))
			{
				board[i+1][j] = player + 5;
				board[i+1][j-1] = player + 5;
			}
		}

		if (board[i+1][j+1] == player)
		{
			if (((board[i][j+1] == 0)||(board[i][j+1] == player + 5)) && ((board[i+1][j] == 0)||(board[i+1][j] == player + 5)))
			{
				board[i][j+1] = player + 5;
				board[i+1][j] = player + 5;
			}
		}

		if (board[i-1][j+2] == player)
		{
			if (((board[i-1][j+1] == 0)||(board[i-1][j+1] == player + 5)) && ((board[i][j+1] == 0)||(board[i][j+1] == player + 5)))
			{
				board[i-1][j+1] = player + 5;
				board[i][j+1] = player + 5;
			}
		}
	}
	
	void removePiece()
	{
        	board_stack.pop(this);
	}
    
	void switchPlayer()
	{
		int aux;
        
		aux = player;
		player = enemy;
		enemy = aux;

		line = !line;
	}

	int getPlayer()
	{
		return player;
	}
	
	void resetBoard(int player, bool line)
	{
		this->line = line;
		this->player = player;
		switch(player)
		{
			case HOMEM : {enemy = COMPUTADOR; break;}
			case COMPUTADOR : {enemy = HOMEM; break;}
		}

		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				board[i][j] = LIVRE;
				pesos[i][j] = 0;
			}
		}
	}

	void showBoard()
	{
		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				printf ("[%d]\t", board[i][j]);
			}
			printf("\n");
		}
	}

	int evaluateBagassa()
	{
		int player_eval = TAM;
		int enemy_eval = TAM;
		int eval;

		if (line)
		{
			// Linhas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[i][j] == player) || (board[i][j] == player+5))
					{
						player_eval--;
						break;
					}
				}
			}
			// Colunas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[j][i] == enemy) || (board[j][i] == enemy+5))
					{
						enemy_eval--;
						break;
					}
				}
			}
		}
		else
		{
			// Colunas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[j][i] == player) || (board[j][i] == player+5))
					{
						player_eval--;
						break;
					}
				}
			}
			// Linhas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[i][j] == enemy) || (board[i][j] == enemy+5))
					{
						enemy_eval--;
						break;
					}
				}
			}
		}

		// Condicao de Game Over
		if (player_eval == 0)
		{
		}

		return -(player_eval - enemy_eval);
	}
 
};

*/
class BoardState
{
	// Atributos
	public:
	int board [TAM][TAM];
 	int pesos [TAM][TAM];
	int player;
	bool line;
	int enemy;
	//static const int empty = 0;

	// Construtores
	public:
	BoardState()
	{
		player = HOMEM;
		enemy = COMPUTADOR;
		line = false;
		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				board[i][j] = LIVRE;
				pesos[i][j] = 0;    
			}
		}
	}

	BoardState(int *state, int player, bool line)
	{
		this->player = player;
		switch(player)
		{
			case HOMEM : {enemy = COMPUTADOR; break;}
			case COMPUTADOR : {enemy = HOMEM; break;}
		}
		this->line = line;
		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				board[i][j] = *(state + TAM*i  + j);
			}
		}
	}

	BoardState( int player, bool line)
	{
		this->player = player;
		switch(player)
		{
			case HOMEM : {enemy = COMPUTADOR; break;}
			case COMPUTADOR : {enemy = HOMEM; break;}
		}
		this->line = line;
	}

	// Metodos
	public:

    int swap(int player)
    {
        switch(player)
        {
            case HOMEM : return(COMPUTADOR);
            case COMPUTADOR : return(HOMEM);
        }
    }

	void putPiece(int i, int j)
	{
		board[i][j] = player;

		if (board[i-2][j+1] == player)
		{
			if (((board[i-1][j] == 0)||(board[i-1][j] == player + 5)) && ((board[i-1][j+1] == 0)||(board[i-1][j+1] == player + 5)))
			{
				board[i-1][j] = player + 5;
				board[i-1][j+1] = player + 5;
			}
		}

		if (board[i-1][j-1] == player)
		{
			if (((board[i-1][j] == 0)||(board[i-1][j] == player + 5)) && ((board[i][j-1] == 0)||(board[i][j-1] == player+5)))
			{
				board[i-1][j] = player + 5;
				board[i][j-1] = player + 5;
			}
		}

		if (board[i+1][j-2] == player)
		{
			if (((board[i][j-1] == 0)||(board[i][j-1] == player + 5)) && ((board[i+1][j-1] == 0)||(board[i+1][j-1] == player + 5)))
			{
				board[i][j-1] = player + 5;
				board[i+1][j-1] = player + 5;
			}
		}

		if (board[i+2][j-1] == player)
		{
			if (((board[i+1][j-1] == 0)||(board[i+1][j-1] == player + 5)) && ((board[i+1][j] == 0)||(board[i+1][j] == player + 5)))
			{
				board[i+1][j] = player + 5;
				board[i+1][j-1] = player + 5;
			}
		}

		if (board[i+1][j+1] == player)
		{
			if (((board[i][j+1] == 0)||(board[i][j+1] == player + 5)) && ((board[i+1][j] == 0)||(board[i+1][j] == player + 5)))
			{
				board[i][j+1] = player + 5;
				board[i+1][j] = player + 5;
			}
		}

		if (board[i-1][j+2] == player)
		{
			if (((board[i-1][j+1] == 0)||(board[i-1][j+1] == player + 5)) && ((board[i][j+1] == 0)||(board[i][j+1] == player + 5)))
			{
				board[i-1][j+1] = player + 5;
				board[i][j+1] = player + 5;
			}
		}
	}
	void removePiece(int i, int j )
	{
        player = board[i][j];
		board[i][j] = LIVRE;
		if (board[i-1][j] == player + 5) board[i-1][j] = 0;
		if (board[i-1][j+1] == player + 5) board[i-1][j+1] = 0;
		if (board[i][j+1] == player + 5) board[i][j+1] = 0;
		if (board[i+1][j] == player + 5) board[i+1][j] = 0;
		if (board[i+1][j-1] == player + 5) board[i+1][j-1] = 0;
		if (board[i][j-1] == player + 5) board[i][j-1] = 0;
	}
 
    
    void switchPlayer()
    {
        int aux;
        
        aux = player;
        player = enemy;
        enemy = aux;
        line = !line;
    }

    int getPlayer()
    {
       return player;
    }
    void resetBoard(int player, bool line)
    {
        this->line = line;
        this->player = player;
		switch(player)
		{
			case HOMEM : {enemy = COMPUTADOR; break;}
			case COMPUTADOR : {enemy = HOMEM; break;}
		}
        
		for (int i = 0; i<TAM; i++)
        {
			for (int j = 0; j<TAM; j++)
            {
                board[i][j] = LIVRE;
                pesos[i][j] = 0;
            }
        }
    }
	void showBoard()
	{
		for (int i = 0; i<TAM; i++)
		{
			for (int j = 0; j<TAM; j++)
			{
				//cout << "[" << board[i][j] << "]\t";
			}
			//cout << "\n";
		}
	}

	int evaluateBagassa()
	{
		int player_eval = TAM;
		int enemy_eval = TAM;
		int eval;

		if (line)
		{
			// Linhas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[i][j] == player) || (board[i][j] == player+5))
					{
						player_eval--;
						break;
					}
				}
			}
			// Colunas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[j][i] == enemy) || (board[j][i] == enemy+5))
					{
						enemy_eval--;
						break;
					}
				}
			}
		}
		else
		{
			// Colunas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[j][i] == player) || (board[j][i] == player+5))
					{
						player_eval--;
						break;
					}
				}
			}
			// Linhas
			for (int i = 0; i<TAM; i++)
			{
				for (int j = 0; j<TAM; j++)
				{
					if ((board[i][j] == enemy) || (board[i][j] == enemy+5))
					{
						enemy_eval--;
						break;
					}
				}
			}
		}

		// Condicao de Game Over
		if (player_eval == 0)
		{
		}

		return -(player_eval - enemy_eval);
	}
 
};
/*
int main()
{
	BoardState s0;
	s0.putPiece(3,3);
	s0.showBoard();
	cout << s0.evaluateBagassa() << "\n";

	BoardState s1 (*s0.board, 2, !(s0.line));
	s1.putPiece(7,7);
	s1.showBoard();
	cout << s1.evaluateBagassa() << "\n";

	BoardState s2 (*s1.board, 1, !(s1.line));
	s2.putPiece(3,2);
	s2.showBoard();
	cout << s2.evaluateBagassa() << "\n";

	BoardState s3 (*s2.board, 2, !(s2.line));
	s3.putPiece(3,4);
	s3.showBoard();
	cout << s3.evaluateBagassa() << "\n";
     int x;
cin>>x;	exit(0);
} */

#endif
