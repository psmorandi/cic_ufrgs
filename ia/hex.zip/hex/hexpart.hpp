#ifndef HEXPART_HPP
#define HEXPART_HPP

#include "utils.hpp"

class HexPart{
private:
	GLpoint2f p;
	GLcolor3f c;
	int color;
    int jogador; //Qual jogador est� ocupando essa pe�a
    bool visivel;
    
public:
	HexPart()
    {
	   c.set( 1.0, 1.0, 1.0 );
	   color = WHITE;
       visivel = true;
    }
    
    void setVisible( bool x )
    {
       visivel = x;
    }
    
    bool getVisible()
    {
       return visivel;
    }

	void setXY( float x, float y )
    {
	   p.set( x, y );
    }

    void setXY( GLpoint2f xy )
    {
	   p.set( xy );
    }        

	GLpoint2f getXY()
    {
	   return p;
    }

	void setColor( int cor )
    {
       if ( cor == BLUE )
	   {
		  c.set( 0.0, 0.0, 1.0 );
		  color = cor;
	   }
       if ( cor == RED )
	   {
		  c.set( 1.0, 0.0, 0.0 );
		  color = cor;
       }
	   if ( cor == WHITE )
	   {
		 c.set( 1.0, 1.0, 1.0 );
		 color = cor;
       }
       if ( cor == GREEN )
       {
         c.set( 0.0, 1.0, 0.0 );
         color = cor;
       }
    }

    int getColor()
    {
        return color;
    }

    void setPlayer( int pl )
    {
         jogador = pl;
    }

    int getPlayer()
    {
        return jogador;
    }

	void drawHex()
 	{
      if (visivel)
      {
		glColor3f( c.r, c.g, c.b );
		glBegin(GL_POLYGON);
		  glVertex2f( p.x+RAIO,   p.y );
		  glVertex2f( p.x+RAIO/2, p.y-VERTICE );
		  glVertex2f( p.x-RAIO/2, p.y-VERTICE );
		  glVertex2f( p.x-RAIO  , p.y );
		  glVertex2f( p.x-RAIO/2, p.y+VERTICE );
		  glVertex2f( p.x+RAIO/2, p.y+VERTICE );
		glEnd();

		glColor3f( 0.0, 0.0, 0.0 );
		glBegin(GL_LINE_LOOP);
		  glVertex2f( p.x+RAIO,   p.y );
		  glVertex2f( p.x+RAIO/2, p.y-VERTICE );
		  glVertex2f( p.x-RAIO/2, p.y-VERTICE );
		  glVertex2f( p.x-RAIO  , p.y );
		  glVertex2f( p.x-RAIO/2, p.y+VERTICE );
		  glVertex2f( p.x+RAIO/2, p.y+VERTICE );
		glEnd();
       }
	}

	void drawHexRed()
    {
		glColor3f( 1.0, 0.0, 0.0 );
		glBegin(GL_LINE_LOOP);
		 glVertex2f( p.x+RAIO,   p.y );
	 	 glVertex2f( p.x+RAIO/2, p.y-VERTICE );
	 	 glVertex2f( p.x-RAIO/2, p.y-VERTICE );
	 	 glVertex2f( p.x-RAIO  , p.y );
	 	 glVertex2f( p.x-RAIO/2, p.y+VERTICE );
	 	 glVertex2f( p.x+RAIO/2, p.y+VERTICE );
		glEnd();
	}

	void drawHexBlue()
	{
		glColor3f( 0.0, 0.0, 1.0 );
		glBegin(GL_LINE_LOOP);
		 glVertex2f( p.x+RAIO,   p.y );
		 glVertex2f( p.x+RAIO/2, p.y-VERTICE );
		 glVertex2f( p.x-RAIO/2, p.y-VERTICE );
		 glVertex2f( p.x-RAIO  , p.y );
		 glVertex2f( p.x-RAIO/2, p.y+VERTICE );
		 glVertex2f( p.x+RAIO/2, p.y+VERTICE );
		glEnd();
	}

	void drawCorners( int corner )
	{
		switch( corner )
		{
			case CORNER_UP:	
			case CORNER_LEFT: glColor3f( 0.0, 0.0, 1.0 );
					glBegin(GL_LINE_LOOP);
					glVertex2f( p.x+RAIO,   p.y );
					glVertex2f( p.x+RAIO/2, p.y-VERTICE );
					glVertex2f( p.x-RAIO/2, p.y-VERTICE );
					glColor3f( 1.0, 0.0, 0.0 );
					glVertex2f( p.x-RAIO  , p.y );
					glVertex2f( p.x-RAIO/2, p.y+VERTICE );
					glVertex2f( p.x+RAIO/2, p.y+VERTICE );
					glEnd();
					break;
			case CORNER_DOWN:
			case CORNER_RIGHT: glColor3f( 1.0, 0.0, 0.0 );
					glBegin(GL_LINE_LOOP);
					glVertex2f( p.x+RAIO,   p.y );
					glVertex2f( p.x+RAIO/2, p.y-VERTICE );
					glVertex2f( p.x-RAIO/2, p.y-VERTICE );
					glColor3f( 0.0, 0.0, 1.0 );
					glVertex2f( p.x-RAIO  , p.y );
					glVertex2f( p.x-RAIO/2, p.y+VERTICE );
					glVertex2f( p.x+RAIO/2, p.y+VERTICE );
					glEnd();
					break;
		}
	}

    void drawMarc()
    {
        glColor3f( 0.0, 1.0, 0.0 );
		glBegin(GL_POLYGON);
		  glVertex2f( p.x+RAIO/2,   p.y );
		  glVertex2f( p.x+RAIO/4, p.y-VERTICE/2 );
		  glVertex2f( p.x-RAIO/4, p.y-VERTICE/2 );
		  glVertex2f( p.x-RAIO/2  , p.y );
		  glVertex2f( p.x-RAIO/4, p.y+VERTICE/2 );
		  glVertex2f( p.x+RAIO/4, p.y+VERTICE/2 );
		glEnd();

		glColor3f( 0.0, 0.0, 0.0 );
		glBegin(GL_LINE_LOOP);
		  glVertex2f( p.x+RAIO,   p.y );
		  glVertex2f( p.x+RAIO/2, p.y-VERTICE );
		  glVertex2f( p.x-RAIO/2, p.y-VERTICE );
		  glVertex2f( p.x-RAIO  , p.y );
		  glVertex2f( p.x-RAIO/2, p.y+VERTICE );
		  glVertex2f( p.x+RAIO/2, p.y+VERTICE );
		glEnd();
    }

};

#endif
