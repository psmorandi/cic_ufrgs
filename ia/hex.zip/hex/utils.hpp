#ifndef UTILS_HPP
#define UTILS_HPP

#include "defines.h"
#include <GL/glut.h>
//#include <iostream>
#include <stdio.h>

class GLcolor3f{
public:
       float r, g, b;
       GLcolor3f(){r = 0.6; g = 0.6; b = 0.6;}
       GLcolor3f( float rr, float gg, float bb ){r = rr; g = gg; b = bb;}
       void set( float rr, float gg, float bb ){r = rr; g = gg; b = bb;}
       void set( GLcolor3f& c ){r = c.r; g = c.g; b = c.b;}
       void apply(){ glClearColor(r,g,b,1.0); }
};

class GLbackground3f{
private:
        GLcolor3f cor;
public:
       GLbackground3f( float rr, float gg, float bb ){ cor.r = rr; cor.g = gg; cor.b = bb; }
       void set(){ cor.apply(); }
       void clearScreen(){ glClear(GL_COLOR_BUFFER_BIT); }
};

class GLpoint2i {
public:
       int x, y;
       GLpoint2i(){ x = y = 0; }
       GLpoint2i( int xx, int yy ){ x = xx; y = yy; }
       void set( int xx, int yy ){ x = xx; y = yy; }
       void set( GLpoint2i& p ){ x = p.x; y = p.y; }
};

class GLpoint2f {
public:
       float x, y;
       GLpoint2f(){ x = y = 0; }
       GLpoint2f( float xx, float yy ){ x = xx; y = yy; }
       void set( float xx, float yy ){ x = xx; y = yy; }
       void set( GLpoint2f& p ){ x = p.x; y = p.y; }
       GLpoint2f distance( GLpoint2f& p )
       {
          GLpoint2f d;
          d.set( p.x - x, p.y - y );
          return d;
       }
};

class GLpoint3f {
public:
       float x, y, z;
       GLpoint3f(){x = y = z = 0;}
       GLpoint3f( float xx, float yy, float zz ){x = xx; y = yy; z = zz;}
       void set( float xx, float yy, float zz ){ x = xx; y = yy; z = zz;}
       void set( GLpoint3f& p ){ x = p.x; y = p.y; z = p.z;}
       GLpoint3f distance( GLpoint3f& p )
       {
          GLpoint3f d;
          d.set( p.x - x, p.y - y, p.z - z );
          return d;
       }
};
#endif
