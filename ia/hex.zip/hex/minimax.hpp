#ifndef MINIMAX_HPP
#define MINIMAX_HPP

#include "tabuleirohex.hpp"
#include "estatica.hpp"

typedef struct swain {
        int valor;
        GLpoint2i caminho;
} RetornoMinimax;

typedef struct swain2 {
        GLpoint2i pos;
        struct swain2* prox;
} Sucessor;

class Minimax{
private:
        int valor; //Melhor contagem
        GLpoint2i caminho; //Melhor caminho
        TabuleiroHex tab; //Tabuleiro
        int profundidadeMAX;
public:
       Minimax();
       void setTabuleiro( TabuleiroHex t );
       bool fimDeJogo( TabuleiroHex tab, int x, int y, int play );
       bool profundoSuficiente( BoardState posicao, int profundidade );
//       int estatica( GLpoint2i posicao, int jogador ); //funcao de avaliacao
       Sucessor* germov( BoardState posicao, int jogador );
       RetornoMinimax proximaJogada(BoardState &posicao, int profundidade, int jogador); //algoritmo do minimax
//       int melhorValor();
};

Minimax::Minimax( )
{ 
  caminho.set(-1,-1); 
  valor = 0; 
  profundidadeMAX = MAXHEIGHT;
}

void Minimax::setTabuleiro( TabuleiroHex t )
{
     tab = t;
}

bool Minimax::profundoSuficiente( BoardState posicao, int profundidade )
{
     if (profundidade == profundidadeMAX)
        return true;
     else
     {
        //if ( fimDeJogo() ) return true;
        //else
        //if (tempoRestante >= maxtime) return true
        /*else
        {
           
        }*/
     }
     return false; 
}

bool Minimax::fimDeJogo( TabuleiroHex tab, int x, int y, int play )
{
  HexPart t,a, b;
  int player1, player2, player3;
  bool over;
  
  t = tab.getHex( x, y );
  player1 = t.getPlayer(); y++;
  a = tab.getHex(x,y);
  player2 = a.getPlayer(); x++;
  b = tab.getHex(x+1,y);
  player3 = b.getPlayer();


  if ( player1 == player2 && player1 == player3 )
     over = fimDeJogo(tab,x-1,y,play) && fimDeJogo(tab,x,y-1,play);
  else
      over = false;

  return over;
}

Sucessor *Minimax::germov(BoardState posicao, int jogador )
{
   Sucessor *x;
   x=NULL;
   
   for(int i=0;i<TAM;i++ )
      for(int j=0;j<TAM;j++ )
      {
             if (posicao.board[i][j] == LIVRE || posicao.board[i][j] > 2)
             {
                Sucessor *y = new Sucessor;
                y->pos.set(i,j);
                y->prox = x;
                x = y;
             }
      }       
   return x;
}

RetornoMinimax Minimax::proximaJogada(BoardState &posicao, int profundidade, int jogador) //algoritmo do minimax
{  
  RetornoMinimax estrutura, resultado_suc;
  Sucessor *sucessores;
  int melhorValor, novoValor;
  int j1;
  GLpoint2i melhorCaminho;
  
  if (profundoSuficiente(posicao, profundidade) ) 
  {
    if (posicao.getPlayer() != jogador)
      posicao.switchPlayer();
    estrutura.valor = posicao.evaluateBagassa();
    estrutura.caminho.set(0,0);
    return estrutura;
  }
  else
  {
    sucessores = germov(posicao,jogador);
  }
  if ( sucessores == NULL )
  {
    if (posicao.getPlayer() != jogador)
      posicao.switchPlayer();
      
    estrutura.valor = posicao.evaluateBagassa();
    estrutura.caminho.set(0,0);
    return estrutura;
  }
  else
  {
    melhorValor = -WORST;
    while( sucessores != NULL )
    {
       if ( jogador == COMPUTADOR )
       {
            j1 = HOMEM;
       }
       else
           j1 = COMPUTADOR;          

       if ( posicao.getPlayer() != j1 )
         posicao.switchPlayer();
         
       posicao.putPiece(sucessores->pos.x, sucessores->pos.y);
       resultado_suc = proximaJogada( posicao, profundidade+1, j1 );
       //cout << "Jogada: (" << sucessores->pos.x << "," << sucessores->pos.y << ") -- minimax = " << resultado_suc.valor << endl;

       if (posicao.getPlayer() != j1)
         posicao.switchPlayer();
//       posicao.removePiece();
       posicao.removePiece(sucessores->pos.x, sucessores->pos.y);
       novoValor =  -resultado_suc.valor;
       if (novoValor < melhorValor)
       {
           melhorValor = novoValor;
           melhorCaminho.set( sucessores->pos );           
       }
       Sucessor *temp;
       temp=sucessores;
       sucessores = sucessores->prox;
       delete temp;
    } 
  }
  
  estrutura.valor = melhorValor;
  estrutura.caminho.set( melhorCaminho );
  return estrutura;
      
}

#endif

