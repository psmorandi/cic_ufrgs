#ifndef TABULEIROHEX_HPP
#define TABULEIROHEX_HPP

#include "hexpart.hpp"
#include "player.hpp"
#include "estatica.hpp"

class TabuleiroHex {
private:
    HexPart hex[TAM][TAM];    //Pe�as..
	void eixoXY();
	int livres; //numero de casas livres no tabuleiro
    BoardState board;
 
public:
	TabuleiroHex();
	void drawBoard();
	void jogada( int x, int y, int color, int player );
	GLpoint2i whatHex( float x, float y );
    bool ocupado( int x, int y );
    HexPart getHex( int x, int y );
    void resetTab();
    int getLivres();
    void configTab( Player p );
    BoardState getBoard();
	~TabuleiroHex();
};

BoardState TabuleiroHex::getBoard()
{
  return board; 
}

void TabuleiroHex::configTab( Player p )
{
        int jogador[2];
        int cor = p.getColor();
        
        jogador[cor] = p.getPlayer();
        jogador[1-cor] = (jogador[cor]==HOMEM)?COMPUTADOR:HOMEM;
        
        if (board.getPlayer() == jogador[RED]) board.switchPlayer();        
        
        for (int i=0; i<TAM;i++ )
        {
            hex[0][i].setColor( BLUE );
            hex[0][i].setPlayer( jogador[BLUE] );
            board.putPiece(0,i);
            hex[TAM-1][i].setPlayer( jogador[BLUE] );
            hex[TAM-1][i].setColor( BLUE );            
            board.putPiece(TAM-1,i);
        }

        board.switchPlayer();
        for (int i=1; i<TAM-1;i++ )        
        {
            hex[i][0].setColor( RED );
            hex[i][0].setPlayer( jogador[RED] );
            board.putPiece(i,0);
            hex[i][TAM-1].setColor( RED );            
            hex[i][TAM-1].setPlayer( jogador[RED] );
            board.putPiece(i,TAM-1);
        }
        hex[0][TAM-1].setVisible(false);
        hex[TAM-1][TAM-1].setVisible(false);
        hex[TAM-1][0].setVisible(false);
        hex[0][0].setVisible(false);

}

void TabuleiroHex::eixoXY()
{
		glColor3f(1.0,0.0,0.0);
		for(int i=0; i<TELAX; i+=int(3*RAIO)/2)
		{
			glBegin(GL_LINES);
			  glVertex2f(i,0);
			  glVertex2f(i,TELAY);
			glEnd();

			if ( (int)(i/(3*RAIO/2)) % 2 !=0)
			{
				for(int j=0;j<=TELAY/2; j+=int(2*VERTICE))
				{
					glBegin(GL_LINES);
					  glVertex2f(i,TELAY/2+j);
					  glVertex2f(i+3*RAIO/2,TELAY/2+j);
					  glVertex2f(i,TELAY/2-j);
					  glVertex2f(i+3*RAIO/2,TELAY/2-j);
					glEnd();
				}
			}
			else
			{
				for(int j=(int)VERTICE;j<=TELAY/2; j+=int(2*VERTICE))
				{
					glBegin(GL_LINES);
					  glVertex2f(i,TELAY/2+j);
					  glVertex2f(i+3*RAIO/2,TELAY/2+j);
					  glVertex2f(i,TELAY/2-j);
					  glVertex2f(i+3*RAIO/2,TELAY/2-j);
					glEnd();
				}
			}

		}

}

TabuleiroHex::TabuleiroHex( )
{
		for(int i=0;i<TAM;i++)
		{
			for(int j=0; j<TAM; j++)
			{
				hex[i][j].setXY( RAIO+(i+j)*(3*RAIO)/2, TELAY/2+(j-i)*VERTICE );
                hex[i][j].setPlayer(LIVRE);
                                
			}
		}

		livres = (TAM-2)*(TAM-2);
        if (board.getPlayer() == COMPUTADOR) board.switchPlayer();
        for (int i=0; i<TAM;i++ )
        {
            hex[0][i].setColor( BLUE );
            hex[0][i].setPlayer( HOMEM );
            board.putPiece(0,i);
            hex[TAM-1][i].setPlayer( HOMEM );
            hex[TAM-1][i].setColor( BLUE );            
            board.putPiece(TAM-1,i);
        }

        board.switchPlayer();
        for (int i=1; i<TAM-1;i++ )        
        {
            hex[i][0].setColor( RED );
            hex[i][0].setPlayer( COMPUTADOR );
            board.putPiece(i,0);
            hex[i][TAM-1].setColor( RED );            
            hex[i][TAM-1].setPlayer( COMPUTADOR );
            board.putPiece(i,TAM-1);
        }
        hex[0][TAM-1].setVisible(false);
        hex[TAM-1][TAM-1].setVisible(false);
        hex[TAM-1][0].setVisible(false);
        hex[0][0].setVisible(false);
        
}

void TabuleiroHex::drawBoard()
{
		for(int i=0;i<TAM;i++)
		{
			for(int j=0; j<TAM; j++)
			{
				hex[i][j].drawHex();
			}
		}
}

void TabuleiroHex::jogada( int x, int y, int color, int player )
{
	if ((x >= 0) && ( x <= TAM-1 ) && ( y >= 0 ) && ( y <= TAM-1 ) )
	{
		hex[x][y].setColor(color);
        hex[x][y].setPlayer( player );
		hex[x][y].drawHex();
		livres--;
        if ( player != board.getPlayer() )
           board.switchPlayer();
        board.putPiece(x,y);
	}
}

GLpoint2i TabuleiroHex::whatHex( float x, float y )
{
	GLpoint2i pi;
	int coluna = (int)(x/(3*RAIO/2));
	int linha;
	if ( coluna % 2 == 0 )
	{
		y = ((y - (TELAY/2)+VERTICE)/(2*VERTICE));
		if (y<0) y=y-1;
		linha = (int)y;
	}
	else
	{
		y = ((y - (TELAY/2)+2*VERTICE)/(2*VERTICE));
		if (y<0) y=y-1;
		linha = (int)y;
	}
	pi.set(coluna-((int)coluna/2)-linha,linha+(coluna/2));
	return pi;
}

bool TabuleiroHex::ocupado( int x, int y )
{
  if ((x >= 0) && ( x <= TAM-1 ) && ( y >= 0 ) && ( y <= TAM-1 ) )
  {
     if ( hex[x][y].getPlayer() == LIVRE )
        return false;
  }
  return true;
}

void TabuleiroHex::resetTab()
{
		for(int i=0;i<TAM;i++)
		{
			for(int j=0; j<TAM; j++)
			{
                hex[i][j].setPlayer(LIVRE);
                hex[i][j].setColor(WHITE);
			}
		}

		livres = (TAM-2)*(TAM-2);
        if (board.getPlayer() == COMPUTADOR) board.switchPlayer();
        for (int i=0; i<TAM;i++ )
        {
            hex[0][i].setColor( BLUE );
            hex[0][i].setPlayer( HOMEM );
            board.putPiece(0,i);
            hex[TAM-1][i].setPlayer( HOMEM );
            hex[TAM-1][i].setColor( BLUE );            
            board.putPiece(TAM-1,i);
        }

        board.switchPlayer();
        for (int i=1; i<TAM-1;i++ )        
        {
            hex[i][0].setColor( RED );
            hex[i][0].setPlayer( COMPUTADOR );
            board.putPiece(i,0);
            hex[i][TAM-1].setColor( RED );            
            hex[i][TAM-1].setPlayer( COMPUTADOR );
            board.putPiece(i,TAM-1);
        }
        hex[0][TAM-1].setVisible(false);
        hex[TAM-1][TAM-1].setVisible(false);
        hex[TAM-1][0].setVisible(false);
        hex[0][0].setVisible(false);
     drawBoard();
}

HexPart TabuleiroHex::getHex( int x, int y )
{
   return hex[x][y];
}

TabuleiroHex::~TabuleiroHex()
{
		delete hex;
}

int TabuleiroHex::getLivres()
{
    return livres;
}
#endif

