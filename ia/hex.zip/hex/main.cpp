//==============================================================================
// Jogo HEX 11x11 desenvolvido por:
//   Mairo Pedrini
//   Marcos Paulo Slomp
//   Paulo S�rgio Morandi J�nior
//
//   Trabalho de Intelig�ncia Artificial ver. Primeiro-Turno
//==============================================================================

//#include "tabuleirohex.hpp"
#include "minimax.hpp"
#include "estatica.hpp"

//====================================
// Vari�veis Globais
GLbackground3f defaultBack( 0.0, 0.0, 0.0 );
BoardState estado;
TabuleiroHex hexi; // Tabuleiro
GLpoint2f mouse;   // ponto onde o mouse clicou na tela...
Player players(HOMEM); //Jogadores...
GLpoint2i ultimaJogada; //Guess...
float viewLargura=TELAX, viewAltura=TELAY, wminX=0, wminY=0, wmaxX=TELAX, 
      wmaxY=TELAY, escalaX, escalaY; // Var. utilizadas na conversao SRT->SRU
Minimax fun;                             
bool inicio=true;
//=====================================

//======================================
// Aqui vem a fun��o que vai calcular 
// a jogada do computador...
//======================================
void computador()
{
    //Calcula a pr�xima jogada do computador
    int x, y, cor;

    estado = hexi.getBoard();
    RetornoMinimax teste = fun.proximaJogada(estado,0,COMPUTADOR);
    x = teste.caminho.x;
    y = teste.caminho.y;

    //=======================================

    if ( players.getColor() == RED )
        cor = BLUE;
    else cor = RED;
    hexi.jogada(x, y, cor, COMPUTADOR);
    ultimaJogada.set( x , y );
    players.setTurn(true);
    glutPostRedisplay();
    estado = hexi.getBoard();    
    estado.showBoard();    
    
}

//===========================================================
// Inicializa aspectos do rendering
//===========================================================
void SetupRC(void)
{
    defaultBack.set();  // PsMj Default Background
    glColor3f(0.0f,0.0f,0.0f);      // Cor de desenho
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0,float(TELAX),0.0,float(TELAY));
}

//===========================================================
// Fun��o de callback de desenho
// Executada sempre que � necessario re-exibir a imagem
//===========================================================
void RenderScene(void)
{
	glColor3f(1.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

    // Aqui devem ser inseridas chamadas de fun��es OpenGL para desenho
   hexi.drawBoard();

    // Flush dos comandos de desenho que estejam no "pipeline" da OpenGL
    // para conclusao da geracao da imagem
    glutSwapBuffers();
}

void SpecialKeys(int key, int x, int y)
{
 //int zx;
}

// Especifica callback comum de teclado
void KeyboardFunc ( unsigned char key, int x, int y )
{
 //int zx;
 switch( key )
 {
//    case 'p': case 'P': cout << "Livres = " << hexi.getLivres() << endl;    
//                        break;
    case '\033': case 'q': case 'Q': exit(0);
                                     break;
 }
}

//Converte do sistema de referencia da tela para universo do objeto
GLpoint2f SRTtoSRU (int x, int y)
{
     GLpoint2f pu;

     pu.set(x * escalaX + wminX, wmaxY - y * escalaY);
     //  y � relativo ao canto superior esquerdo da janela
     return pu; 
}               

void MouseFunc ( int button, int state, int x, int y )
{
	GLpoint2f pt;
	GLpoint2i pi;
 
    pt = SRTtoSRU(x,y);
    pi = hexi.whatHex(pt.x,pt.y);
    
    switch( state )
    {
	  case GLUT_DOWN: if (pi.x >= 0 && pi.y >= 0 && pi.x < TAM && pi.y < TAM)
                      {
                         if ( players.getTurn() )
                         {
                             if ( !hexi.ocupado( pi.x, pi.y ) )
                             {
                                 inicio = false;
                                 hexi.jogada(pi.x, pi.y, players.getColor(), HOMEM);
                                 players.setTurn(false);
                             }
                         }
                      }
                      break;     
    case GLUT_UP: if ( !players.getTurn() )
                  {
                     computador();
                     RetornoMinimax teste = fun.proximaJogada(estado,0,HOMEM);
//                     cout << "x = " << teste.caminho.x << ", y = " << teste.caminho.y << endl;
                  }
    }                        
	glutPostRedisplay();	
}

// callback para tratar redimensionamento da janela
// calcula a rela��o de aspecto e redefine a window no SRU
void ChangeSize (GLsizei w, GLsizei h)
{

    glMatrixMode (GL_PROJECTION);
    glLoadIdentity();

    if (h==0) h=1;
    glViewport (0,0,w,h);  // viewport ocupa toda a janela

    // calcula a propor��o de aumento na janela de sele��o em fun��o
    // do aumento na janela da tela

    float aumentoW = (float) w/ (float) viewLargura;
    viewLargura = w;
    float aumentoH = (float) h/ (float) viewAltura;
    viewAltura = h;


    // aumenta a window proporcionalmente � janela
    wminX=wminX*aumentoW;
    wmaxX= wmaxX*aumentoW;
    wminY=wminY*aumentoH;
    wmaxY=wmaxY*aumentoH;

    gluOrtho2D(wminX,wmaxX,wminY,wmaxY);  // redefine window para a OpenGL
    // recalcula a escala em x e em y para a entrada de pontos
    escalaX = (wmaxX - wminX) / w;
    escalaY = (wmaxY - wminY) / h;

}

void TrataMenu( int valor )
{
 switch( valor )
 {
   case HOMCOMP: if (inicio)
                 {
                    players.setTurn( true );
                 }   
                 break;
   case COMPHOM: if (inicio)
                 {
                    players.setTurn( false );
                    computador();
                    inicio=false;
                 }
                 break;
   case HOMREDCOMPBLUE: if (inicio)
                        {
                           players.setColor( RED );                        
                           hexi.configTab( players );
                        }   
                        break;
   case HOMBLUECOMPRED: if (inicio)
                        {
                           players.setColor( BLUE );                        
                           hexi.configTab( players );
                        }
                        break;
   case RESET:
              hexi.resetTab();
              inicio = true;
              break;
   case NIVEL1: 
   case NIVEL2:
   case NIVEL3: break;
   case EXIT: exit(0); break;
   case FULLSCREEN: glutFullScreen(); glutPostRedisplay(); break;
 }
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);                      //Inicia o ToolKit
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB); //Modo de visualiza��o
   glutInitWindowSize(TELAX,TELAY);                 //Tamanho da janela
   glutInitWindowPosition(100,100);             //Localiza��o na tela

   glutCreateWindow("HEX 11x11 Second Round Version");
        
   int menuCor;  // sub-menu para cores dos jogadores
   int menuOpt;    // sub-menu para saber quem come�a jogando
   int menuNivel;  // sub-menu para escolher o n�vel do MINMAX
   int mainMenu;
          
   menuCor = glutCreateMenu(TrataMenu);
   glutAddMenuEntry("Homem Vermelho x Computador Azul",HOMREDCOMPBLUE);
   glutAddMenuEntry("Homem Azul x Computador Vermelho",HOMBLUECOMPRED);
		
   menuOpt = glutCreateMenu(TrataMenu);
   glutAddMenuEntry("Homem x Computador",HOMCOMP);
   glutAddMenuEntry("Computador x Homem",COMPHOM);
   
   menuNivel = glutCreateMenu(TrataMenu);
   glutAddMenuEntry("F�cil (Profundidade =  1)",NIVEL1);
   glutAddMenuEntry("M�dio (Profundidade =  5)",NIVEL2);
   glutAddMenuEntry("Dif�cil (Profundidade =  10)",NIVEL3);   
   
   mainMenu = glutCreateMenu(TrataMenu);
   glutAddSubMenu("Cores dos Jogadores", menuCor);
   glutAddSubMenu("Jogadores", menuOpt);
   glutAddSubMenu("Dificulade", menuNivel);
   glutAddMenuEntry("Novo Jogo",RESET);
   glutAddMenuEntry("Tela Cheia",FULLSCREEN);
   glutAddMenuEntry("Sair",EXIT);
       
   glutAttachMenu(GLUT_RIGHT_BUTTON);
   
   // Especifica a funcao que vai tratar teclas comuns
   glutKeyboardFunc(KeyboardFunc);

   // Especifica a funcao que vai tratar teclas especiais
   glutSpecialFunc(SpecialKeys);

   // Especifica para a OpenGL que funcao deve ser chamada para geracao da imagem
   glutDisplayFunc(RenderScene);

   // Especifica para o OpenGL que funcao deve ser chamada para tratar as coisas Mousel�ticas...
   glutMouseFunc(MouseFunc);

    // Especifica que fun��o deve ser chamada quando se altera o tamanho da janela
    glutReshapeFunc(ChangeSize);

   // Executa a inicializacao de parametros de exibicao
   SetupRC();

   players.setTurn(true);   players.setColor(BLUE);
   // Dispara a "maquina de estados" de OpenGL
   glutMainLoop();
   return 0;
}
