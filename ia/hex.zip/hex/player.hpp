#include "defines.h"

class Player{
private:
	int jogador;
	bool vez;
	int cor;

public:
	Player( int who );
	void setPlayer( int pla );
	void setTurn( bool turn );
	void setColor( int color );
	int getPlayer();
	bool getTurn();
	int getColor();
};

	Player::Player( int who )
	{
		jogador = who;
		vez = false;
		cor = WHITE;
	}
	void Player::setPlayer( int pla )
	{
		jogador = pla;
	}
	void Player::setTurn( bool turn )
	{
		vez = turn;
	}
	void Player::setColor( int color )
	{
		cor = color;
	}
	int Player::getPlayer()
	{
		return jogador;
	}
	bool Player::getTurn()
	{
		return vez;
	}
	int Player::getColor()
	{
		return cor;
	}
