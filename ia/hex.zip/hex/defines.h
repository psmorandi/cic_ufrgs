#ifndef DEFINES_H
#define DEFINES_H

#include <math.h>
//#include <iostream>
#include <stdlib.h>
//#include <fstream>

//DIMENSION OF DISPLAY
#define TELAX 800
#define TELAY 600

//HEX DIMENSIONS
#define RAIO 20.0
#define VERTICE 17.3205
#define TAM 13

//PLAYERS AND HEX COLORS
#define BLUE 0
#define RED  1
#define WHITE 2
#define GREEN 3

//MENU OPTION
#define HOMCOMP 0
#define COMPHOM 1
#define RESET 2
#define HOMREDCOMPBLUE 3
#define HOMBLUECOMPRED 4
#define HOMHOM 5
#define NIVEL1 6
#define NIVEL2 7
#define NIVEL3 8
#define EXIT 9
#define FULLSCREEN 10

//PLAYERS
#define COMPUTADOR 1
#define HOMEM 2
#define LIVRE 0
#define NOTPLAY -1

//FOR TABULEIROHEX DRAWING
#define CORNER_LEFT 1
#define CORNER_RIGHT 2
#define CORNER_DOWN 3
#define CORNER_UP 4

//MINIMAX DEFS
#define WORST -11
#define MAXHEIGHT 1

#endif
