///////////////////////////////////////////////////////////////////
//
// Sistema Operacional Para Avaliacao - Marcelo Johann - 20/06/2002
//
// SOPA8BETA2 - All hardware components for the 2004 edition, BETA2
//
// TURMA, Acho que Implementei toda infra-estrutura de HW, ja testei
// com um kernel meu que carrega um processo do disco com a interface
// do disco, e corrigi alguns pequenos bugs que havia. Tambem alterei
// levemente o nome de alguns metodos e membros pra deixar mais claros.
// Por favor, ainda considerem codigo "Beta" no sentido de que pode
// haver pequenos ajustes. Quando houver, ja que agora esta mais bem
// definido, eu vou listo-los detalhadamente. Ou seja, voces podem
// partir desse codigo aqui para fazerem suas implementacoes.
// Em principio voces nao devem alterar nenhum componente de HW, a 
// nao ser depois para isolar a maquina e incluir a interface de rede.
// Mas o trabalho de voces comeca restrito ao kernel e descritor de
// processos. Qualquer altera-lo que sentirem necessidade (ou tenta-lo)
// de fazerem no HW me comuniquem antes, pois ou e um bug no que eu 
// escrevi ou algo de errado que voces estao tentando fazer.
//
// Good Luck!
//
///////////////////////////////////////////////////////////////////

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Sopa
  { 
  public static void closeWindow(Vector allMaq)
  {
 	for(Iterator it = allMaq.iterator(); it.hasNext(); )
	{
		MaquinaInterface maq = (MaquinaInterface) it.next();
		try { 
			maq.getDisk().save(maq.getIpAddress());
		}
		catch(IOException e){ }
	}

	System.exit(0);	  
  }
	  
  public static void main(String args[])
    {
    // The program models a complete computer with most HW components
    // The kernel, which is the software component, might have been
    // created here also, but Processor has a refernce to it and it
    // has a reference to the processor, so I decided that all software
    // is under the processor environment: kernel inside processor.
 
    //Initialinzing the switch...Switch its a slave componente responsable for route the 
    //messages...
    int portCounter = 0;
    Switch swit = new Switch();
    final Vector maq = new Vector(); //Here we have all MA-QUINAs...
    int x = 0, y = 0, ip = 19216822;

    for(int i=0; i<3; i++)
    {
	    // Create window console
	    MaquinaInterface m1 = new MaquinaInterface(ip,swit,x,y);
	    ip++;
	    maq.addElement(m1);
	    m1.addWindowListener
		    (
		     new WindowAdapter()
		     {
			     public void windowClosing (WindowEvent e)
		             {
				     closeWindow(maq); 
			     }
		     }
		    );
	    m1.booting();
	    swit.setRouter(m1.getNetworkInterface().getMAC(),m1.getIpAddress(),m1.getNetworkInterface());
	    x+=100; y+=100;
    }

    //Just for debug...
    swit.printRouterTable();

    }
  }

class BootTheMaquina extends Thread 
{
	private JTextArea output;
	private int ipNumber;
	
	private Disk d;
	private Timer t;
	private Processor p;
	private Netface n;
	
	public BootTheMaquina(JTextArea text, int ip, Processor pr, Timer ti, Disk di, Netface ne )
	{
		output = text;
		ipNumber = ip;
		d = di;
		t = ti;
		p = pr;
		n = ne;
	}	

   public void run()
   {
	output.append("Starting HardDrive");
	delay(); d.start();
	output.append("[OK]\n");
	output.append("Starting Timer");
	delay(); t.start(); p.start(); n.start();
	output.append("[OK]\n");
	output.append("Starting Network");
	delay();
	output.append("[OK]\n");
	output.append("DHCP[d]");
	delay();
	output.append("[OK]\n");
	output.append("Your IP is "+ipNumber+"\n");	
	output.append("DefaultGateway is 191.168.1.1\n");	
	output.append("SOPA is Ready...\n");
   }

   public void delay()
   {
	   int j,k,l;
	   for (j=0;j<18;++j)
	   {
		   for (k=0;k<1000;++k)
		   for (l=0;l<100;++l)
		   {
			   j = j + 10;
			   j = j - 10;
		   }
		   output.append(".");
	   }
  }

}

class MaquinaInterface extends JFrame { 
   private Container container;
   private GridBagLayout layout;
   private GridBagConstraints constraints; 
   private JTextArea screen;
   private BootTheMaquina boot;
   private int ipAddress;
   private ConsoleListener ml;

   private Memory memory;
   private Timer timer;
   private Disk disco;
   private Processor proc;
   private Netface net;
   private IntController i;
   private Switch swi;

    
   //number --> Number of the Maq-quina
   public MaquinaInterface(int IP, Switch swi, int x, int y)
   {
      super( "MISFS -- Ma-quina Interface For SOPA" );

      ipAddress = IP;

      container = getContentPane();
      layout = new GridBagLayout();
      container.setLayout( layout );   

      constraints = new GridBagConstraints();

      JLabel maquina = new JLabel("Ma-quina "+ipAddress);
      screen = new JTextArea( "Wait while booting....\n", 10, 20 );
      screen.setEditable(false);
      JLabel keyboard = new JLabel("Terminal");
      JLabel prompt = new JLabel("# ");
      JTextField inputKeyboard = new JTextField();
      
      ml = new ConsoleListener();
      inputKeyboard.addActionListener(ml);
     
      constraints.fill = GridBagConstraints.CENTER;
      addComponent( maquina, 0,0,3,1);			   //row,col,width e height
      addComponent( keyboard, 4,0,3,1);
      addComponent( prompt, 5,0,1,1);
 
      constraints.fill = GridBagConstraints.BOTH;
      addComponent( new JScrollPane(screen), 1,0, 3, 3 );
      addComponent( inputKeyboard, 5,1,2,1); 

      String mac = new String("MAQ:PSNETWORK:");
      mac = mac.concat(String.valueOf(ipAddress) );
      

      i		= new IntController();
      memory 	= new Memory(i,1024);
      timer	= new Timer(i);
      disco	= new Disk(i,memory,1024,"disk.txt");
      net	= new Netface(i,mac,swi,memory);
      proc 	= new Processor(i,memory,ml,timer,disco,net,screen);

      ml.setInterruptController(i);

      setSize( 400, 300 );
      setResizable(false);
      setLocation(x,y);
      setVisible( true );
   }

   private void addComponent( Component component,int row, int column, int width, int height )
   {
      constraints.gridx = column;
      constraints.gridy = row;
      constraints.gridwidth = width;   
      constraints.gridheight = height;
      layout.setConstraints( component, constraints );  
      container.add( component );      
   }

   public void setLocationOfWindow( int x, int y )
   {
	   setLocation(x,y);
   }

   public void booting()
   {
	   boot = new BootTheMaquina(screen,ipAddress,proc,timer,disco,net);
	   boot.start();
   }

   public int getIpAddress()
   {
	   return ipAddress;
   }

   public Netface getNetworkInterface()
   {
	   return net;
   }

   public Disk getDisk()
   {
	   return disco;
   }

}

class ConsoleListener implements ActionListener
  {
  // Console is an intelligent terminal that reads an entire command
  // line and then generates an interrupt. It should provide a method
  // for the kernel to read the command line.

  private IntController hint;
  private String l;
  public void setInterruptController(IntController i)
    {
    hint = i;
    }
  public void actionPerformed(ActionEvent e)
    {
	    JTextField limpaTela = (JTextField)e.getSource();
	    l = e.getActionCommand(); limpaTela.setText("");
    // Here goes the code that generates an interrupt    
    hint.set(15);
    }
  public String getLine()
    {
    return l;
    } 
  }

class Semaphore 
  {
  // This class was found on the Internet and had some bugs fixed.
  // It implements a semaphore using the Java built in monitors.
  // Note how the primitives wait and notify are used inside the
  // monitor, and make the process executing on it leave the
  // monitor until another event happens.
  int value;
  public  Semaphore(int initialValue)
    {
    value = initialValue;
    }
  public synchronized void P() 
    {
    while (value <= 0 ) 
      {
      try { wait(); }
      catch(InterruptedException e){}
      }
    value--;
    }
  public synchronized void V() 
    {
    value++;
    notify();
    }
  }

class IntController
  {
  // The interrupt controler component has a private semaphore to maintain 
  // interrupt requests coming from all other components. 
	// Interruptions from memory are exceptions that need to be handled right
	// now, and have priority over other ints. So, memory interrupt has its
	// own indicator, and the others compete among them using the Semaphore.

  private Semaphore semhi;
  private int number[] = new int[2];
	private final int memoryInterruptNumber = 3;
  public IntController()		
	  {
		semhi = new Semaphore(1);
		}
		
  public void set(int n)
	  { 
		if (n == memoryInterruptNumber)
		  number[0] = n;
		else
		  {
      semhi.P();
			number[1] = n;
			}
		}
		
  public int get()
	  { 
		if (number[0]>0)
		  return number[0];
		else
		  return number[1];
		}
		
  public void reset(int n)
	  {
		if (n == memoryInterruptNumber)
		  number[0] = 0;
		else
		  {
			number[1] = 0;
		  semhi.V();
			}
		}
  }

class Memory
  {
	  // This is the memory system component. 
	  private IntController hint;
	  private int[] memoryWord;
	  private int memorySize;
	  // MMU: base and limit registers
	  private int limitRegister;				// specified in logical addresses
  private int baseRegister;					// add base to get physical address
	// constructor
  public Memory(IntController i,int s)
    {
    // remember size and create memory
		hint = i;
    memorySize = s;
    memoryWord = new int[s];
    // Initialize with the dummy program
    init(0,'J','P','A',0);
    }
  // Access methods for the MMU: these are accessed by the kernel.
	// They do not check memory limits. It is interpreted as kernel's
	// fault to set these registers with values out of range. The result
	// is that the JVM will terminate with an 'out of range' exception
	// if a process uses a memory space that the kernel set wrongly.
	// This is correct: the memory interruption must be set in our
	// simulated machine only if the kernel was right and the process itself
	// tries to access an address which is out of its logical space.
	public void setLimitRegister(int val) { limitRegister = val; };
	public void setBaseRegister(int val) { baseRegister = val; };
	// Here goes some specifi methods for the kernel to access memory
	// bypassing the MMU (do not add base register or test limits)
	public int superRead(int address) { return memoryWord[address]; }
	public void superWrite(int address, int data) { memoryWord[address] = data; }
  // Access methods for the Memory itself
  public synchronized void init(int add, int a, int b, int c, int d)
    {
    memoryWord[add] = (a << 24)+(b<<16)+(c<<8)+d;
    }
  public synchronized int read(int address)
    {
		if (address >= limitRegister)
		  {
		  hint.set(3);
			return 0;
			}
    else
      return memoryWord[baseRegister + address];
    }
  public synchronized void write(int address, int data)
    {
		if (address >= limitRegister)
		  hint.set(3);
    else
      memoryWord[baseRegister + address] = data;
    }
  }

class Timer extends Thread
  {

  // Our programable timer. It has two small bugs, but works most of the time!
  // In this version we are not going to pay attention to fixing it.
  // But it is part of the work in 2004 to find and explain them.
  private IntController hint;
  private int counter = 0;
  private int slice = 5;
  
  public Timer(IntController i)
  {
    hint = i; 
  }
	// For the services below, time is expressed in tenths of seconds
	public void setSlice(int t) { slice = t; } 
	public void setTime(int t) { counter = t; } 
	public int getTime() { return counter; }
	// This is the thread that keeps track of time and generates the
	// interrupt when a slice has ended, but can be reset any time
	// with any "time-to-alarm"
	public void run()
	{
		while (true)
		{
			counter = slice;
			while (counter > 0)
			{
				try { sleep(100); } // tenth of a second 
				catch (InterruptedException e){}
				--counter;
				System.err.println("tick "+counter);
			}
			System.err.println("timer INT");
			hint.set(2);
		}//while(true)
	}//run
  }

class Disk extends Thread
  {

  // Our disc component has a semaphore to implemente its dependency on
  // a call from the processor. The semaphore is private, and we offer 
  // a method roda that unlocks it. Does it need to be synchronized???
  // It needs a semaphore to avoid busy waiting, but...
  private IntController hint;
  private Memory mem;
  private Semaphore sem;
  private String fileName;
  private int[] diskImage;
  private int diskSize;
	// Here go the disk interface registers
	private int address;
	private int writeData;
	private int[] readData;
	private int readSize;
	private int operation;
	private int errorCode;
	// and some codes to get the meaning of the intterface
	// you can use the codes inside the kernel, like: dis.OPERATION_READ
	public final int OPERATION_READ = 0;
	public final int OPERATION_WRITE = 1;
	public final int OPERATION_LOAD = 2;
	public final int ERRORCODE_SUCCESS = 0;
	public final int ERRORCODE_SOMETHING_WRONG = 1;
	public final int ERRORCODE_ADDRESS_OUT_OF_RANGE = 2;
	public final int ERRORCODE_MISSING_EOF = 3;
	public final int BUFFER_SIZE = 128;
	public final int END_OF_FILE = 0xFFFFFFFF;
	
  // Constructor
  public Disk(IntController i,Memory m, int s, String name)
    {
    hint = i;
    mem = m;
    sem = new Semaphore(0);
    // remember size and create disk memory
    diskSize = s;
		fileName = name;
    diskImage = new int[s];
		readData = new int[BUFFER_SIZE];
		readSize = 0;
    }
		
	// Methods that the kernel (in CPU) should call: "roda" activates the disk
	// The last parameter, data, is only for the 'write' operation
  public void roda(int op, int add, int data)
    {
    address = add;
    writeData = data;
    readSize = 0;
    operation = op;
    errorCode = ERRORCODE_SUCCESS;
		sem.V();
    }
	// After disk traps an interruption, kernel retrieve its results
	public int getError() { return errorCode; }
	public int getSize() { return readSize; }
	public int getData(int buffer_position) { return readData[buffer_position]; }
		
  // The thread that is the disk itself
  public void run()
    {
    try { load(fileName); } catch (IOException e){}
    while (true)
    {
      // wait for some request comming from the processor
      sem.P();
      // Processor requested: now I have something to do...
      for (int i=0; i < 20; ++i)
        {
        // sleep just 50 ms which is one disc turn here
        try {sleep(50);} catch (InterruptedException e){}
        System.err.println("disk made a turn");
        }
	
      // After so many turns the disk should do its task!!!
      if (address < 0 || address >= diskSize)
		  errorCode = ERRORCODE_ADDRESS_OUT_OF_RANGE;
      else
      {
	      errorCode = ERRORCODE_SUCCESS;				
	switch(operation)
        {
		case OPERATION_READ: System.err.println("OPERATION_READ");
				     readSize = 1;
				     readData[0] = diskImage[address];
				     System.out.println("DATA READ = "+readData[0]);
				     break;
		case OPERATION_WRITE:
				     System.err.println("OPERATION_WRITE");
				     diskImage[address] = writeData;
				     System.out.println("DATA WRITE = "+writeData);
				     break;
		case OPERATION_LOAD:
				     System.err.println("OPERATION_LOAD");
				     int diskIndex = address;
				     int bufferIndex = 0;
				     while ( diskImage[diskIndex] != END_OF_FILE )
				     {
					     System.err.println(".");
					     if( bufferIndex < BUFFER_SIZE )
					     {
						     readData[bufferIndex] = diskImage[diskIndex];
					     }
					     ++diskIndex;
					     ++bufferIndex;
					     if (diskIndex >= diskSize)
						     errorCode = ERRORCODE_MISSING_EOF;
				     }
				     readSize = bufferIndex;
				     break;
	}//switch
      }//else
			
      // Here goes the code that generates an interrupt
      hint.set(5);
    }
   }
		
  // this is to read disk initial image from a hosted text file
  private void load(String filename) throws IOException
    {
    FileReader f = new FileReader(filename);
    StreamTokenizer tokemon = new StreamTokenizer(f);
    int bytes[] = new int[4];
    int tok = tokemon.nextToken();
    for (int i=0; tok != StreamTokenizer.TT_EOF && (i < diskSize); ++i)
      {
      for (int j=0; tok != StreamTokenizer.TT_EOF && j<4; ++j)
        {
        if (tokemon.ttype == StreamTokenizer.TT_NUMBER )
          bytes[j] = (int) tokemon.nval;
        else
        if (tokemon.ttype == StreamTokenizer.TT_WORD )
          bytes[j] = (int) tokemon.sval.charAt(0); 
        else
          System.err.println("Unexpected token at disk image!"); 
        tok = tokemon.nextToken();      
        }
      diskImage[i] = ((bytes[0]&255)<<24) | ((bytes[1]&255)<<16) | 
								 ((bytes[2]&255)<<8) | (bytes[3]&255);
      System.err.println("Parsed "+bytes[0]+" "+bytes[1]+" "
                                +bytes[2]+" "+bytes[3]+" = "+diskImage[i]);
      }
    }

  //This was added by Paulo Sergio....
  public void save(int maquina) throws IOException
  {
	  String fileName = "imageMaq"+String.valueOf(maquina)+".txt";
	  FileWriter file = new FileWriter(fileName);
	  //BufferedWriter saveLine = new BufferedWriter(file);
	  int[] bytes = new int[4];
	  for(int i=0; i<diskImage.length; i++)
	  {
		  bytes[0] = diskImage[i]>>>24;
		  bytes[1] = (diskImage[i]>>>16) & 255;
		  bytes[2] = (diskImage[i]>>>8) & 255;
		  bytes[3] = diskImage[i] & 255;

	       file.write(bytes[0]+" "+bytes[1]+" "+bytes[2]+" "+bytes[3]+" "+"\n");
	  }
	  file.close();
  }
}

class Processor extends Thread
  {
  // Access to hardware components
  private IntController hint;
  private Memory mem;
  private ConsoleListener con;
  private Timer tim;
  private Disk dis;
  private Netface net;
  // CPU internal components
  private int PC;			// Program Counter
  private int[] IR;			// Instruction Register
  private int[] reg;	// general purpose registers
	private int[] flag; // flags Z E L
	private final int Z = 0;
	private final int E = 1;
	private final int L = 2;
  // Access methods
  public int getPC() { return PC; }
  public void setPC(int i) { PC = i; }
  public int[] getReg() { return reg; }
  public void setReg(int[] r) { reg = r; }
  public int[] getFlag() { return flag; }
  public void setFlag(int[] f) { flag = f; }
  // Kernel is like a software in ROM
  private Kernel kernel;
  public Processor(IntController i, Memory m, ConsoleListener c, Timer t, Disk d, Netface n, JTextArea sc )
    {
    hint = i;
    mem = m;
    con = c;
    tim = t;
	tim.setSlice(8);
    dis = d;
    net = n;
    PC = 0;
    IR = new int[4];
    reg = new int[16];
    flag = new int[3];
    kernel = new Kernel(i,m,c,t,d,this,net,sc);
    }
  public void run()
  {
    while (true)
    {
      // sleep a tenth of a second
      try {sleep(100);} catch (InterruptedException e){}
      // read from memory in the address indicated by PC
      int RD = mem.read(PC);
      // break the 32bit word into 4 separate bytes
      IR[0] = RD>>>24;
      IR[1] = (RD>>>16) & 255;
      IR[2] = (RD>>>8) & 255;
      IR[3] = RD & 255;
      // print CPU status to check if it is ok
      System.err.print("processor: PC=" +PC);
      PC++;
      System.err.print(" IR="+IR[0]+" "+IR[1]+" "+IR[2]+" "+IR[3]+" ");
			
			// Execute basic instructions of the architecture
			
			execute_basic_instructions();
			
      // Check for Hardware Interrupt and if so call the kernel
      if (hint.get() != 0)
      {
        // Call the kernel passing the interrupt number
        kernel.run(hint.get());
        // Kernel handled the last interrupt
        hint.reset(hint.get());
        // This goes here because only HW interrupts are reset in the controller
        // But reseting the interrupt controller might be a task for the Kernel 
        // in a real system.
				// Another point is that I can reset using another call to 
				// hint.get() just because the memory interruption is the only
				// interruption that has priority, and it cannot be called by
				// anyone except the processor itself, which is running the
				// kernel here in supervisor mode (and so it won't do this).
				// If anyone else needs to set an interruption related to the
				// memory (DMA access error for example) it should use another number.
      }//If
    }//while
  }//run
		
	public void execute_basic_instructions()
	{
			if ((IR[0]=='L') && (IR[1]=='M'))
			{
				System.err.println(" [L M r m] ");
				reg[IR[2]] = mem.read(IR[3]);
			}
			else if ((IR[0]=='L') && (IR[1]=='C'))
			{
				System.err.println(" [L C r c] ");
				reg[IR[2]] = IR[3];
			}
			else if ((IR[0]=='W') && (IR[1]=='M'))
			{
				System.err.println(" [W M r m] ");
				mem.write(IR[2], IR[3]);
			}
			else if ((IR[0]=='S') && (IR[1]=='U'))
			{
				System.err.println(" [S U r1 r2] ");
				reg[IR[2]] = reg[IR[2]] - reg[IR[3]];
			}
			else if ((IR[0]=='A') && (IR[1]=='D'))
			{
				System.err.println(" [A D r1 r2] ");
				reg[IR[2]] = reg[IR[2]] + reg[IR[3]];
			}
			else if ((IR[0]=='D') && (IR[1]=='E') && (IR[2]=='C'))
			{
				System.err.println(" [D E C r1] ");
				reg[IR[3]] = reg[IR[3]] - 1;
			}
			else if ((IR[0]=='I') && (IR[1]=='N') && (IR[2]=='C'))
			{
				System.err.println(" [I N C r1] ");
				reg[IR[3]] = reg[IR[3]] + 1;
			}
			else if ((IR[0]=='C') && (IR[1]=='P'))
			{
				System.err.println(" [C P r1 r2] ");
				if (reg[IR[2]] == 0) 
					flag[Z] = 1; 
				else flag[Z] = 0;
				if (reg[IR[2]] == reg[IR[3]]) 
					flag[E] = 1; 
				else flag[E] = 0;
				if (reg[IR[2]] < reg[IR[3]]) 
					flag[L] = 1; 
				else flag[L] = 0;
			}
			else if ((IR[0]=='J') && (IR[1]=='P') && (IR[2]=='A'))
			{
				System.err.println(" [J P A m] "+IR[3]);
				PC = IR[3];
			}
			else if ((IR[0]=='J') && (IR[1]=='P') && (IR[2]=='Z'))
			{
				System.err.println(" [J P Z m] ");
				if (flag[Z] == 1)
					PC = IR[3];
			}
			else if ((IR[0]=='J') && (IR[1]=='P') && (IR[2]=='E'))
			{
				System.err.println(" [J P E m] ");
				if (flag[E] == 1)
					PC = IR[3];
			}
			else if ((IR[0]=='J') && (IR[1]=='P') && (IR[2]=='L'))
			{
				System.err.println(" [J P L m] ");
				if (flag[L] == 1)
					PC = IR[3];
			}
			else if (IR[0]=='I'&&IR[1]=='N'&&IR[2]=='T')
			{
				System.err.println(" [I N T n] ");
				kernel.run(IR[3]);
			}
			else System.err.println(" [? ? ? ?] ");
	}//execute_basic_op..
}

//Network interface, the physical component....
class Netface extends Thread
{
	private IntController hint;
	private Semaphore sem;
	private String MAC;
	private Switch swi;
	private Memory mem;

	//Interface of the Netface
	private int[] recvBuffer;
	private int recvSize;
	
	private int addressRecv;

	public final int ERRORCODE_SEND_SUCCESS = 1;
	public final int ERRORCODE_RECV_PACKAGE = 2;
	public final int ERRORCODE_UNKWON_IP= 3;
	public final int ERRORCODE_RECV_BUFFER_FULL = 4;
	public final int BUFFER_SIZE = 128;
		
	
	public Netface(IntController i, String mac, Switch s, Memory m)
	{
		hint = i;
		MAC = mac; 
		mem = m;
		sem = new Semaphore(0);
		recvBuffer = new int[BUFFER_SIZE];
		swi = s;
		addressRecv = 0;		
		recvSize = 0;
	}

	public void run()
	{
		while(true)
		{
			//Sleeping until someone wake me up...
			sem.P();

			//Oh... I think someone sends me something...
			try {sleep(25);}  //..but I'm so tyred to go on....
			catch (InterruptedException e){}
			//ok... lets do the dirty work...
			hint.set(10);
		}
	}

	public int send(String destMAC, int bufferAdd, int dataSize)
	{
		int sended = 0;
		int size = dataSize;
		int data;
		int status = 0;
		int addr = addressRecv;

		swi.lockSend();
		while( size > 0 )
		{
			data = mem.superRead(bufferAdd++);
			size--;
			status = swi.sendData(destMAC,addr++,data);
			if( status == ERRORCODE_RECV_BUFFER_FULL )
			{
				swi.unlockSend();
				return status;
			}
		}
		addressRecv += dataSize;
		swi.unlockSend();
		swi.wakeupDest(destMAC);
		return ERRORCODE_SEND_SUCCESS;
	}

	public int putRecvBuffer(int addr, int data)
	{
		if (addr > BUFFER_SIZE)
		{
			return -1;
		}
		else
		{
			recvBuffer[addr] = data;
			recvSize++;
		}
		
		return 0;
	}

	public void wakeUp(){ sem.V(); }
	public int getRecvSize() { return recvSize; } 
	public int getRecvBufferAddr(){ return addressRecv; }
	public int getRecvData(int addrBuffer) { return recvBuffer[addrBuffer]; } 
	public void setRecvSize(int size){ recvSize = size; }
	public int getBufferSize(){ return BUFFER_SIZE; }
	public String getMAC(){ return MAC; }
	public Vector getRouterTable(){	return swi.getRouterTable(); }	
	public void resetRegs(){ addressRecv = 0; recvSize = 0; }
}

class MacNetTable
{
	public String MAC;
	public Netface netFace;
}

class MacIpTable
{
	public String MAC;
	public int IP;

	public String toString()
	{
		return "MAC: "+MAC+" ---> IP: "+IP+"\n";
	}
}

//Responsable to route the "packages" towards the "net"....
class Switch
{
	private int sendedSize;
	private Vector routerTable;
	private Vector ipTable;
	private Semaphore mutex;

	public Switch()
	{
		routerTable = new Vector();
		ipTable = new Vector();
		sendedSize = 0;
		mutex = new Semaphore(1);
	}

	//This should be called at the boot time. With this the switch start
	//to construct its router table..
	public void setRouter(String MAC, int IP, Netface net )
	{
		MacNetTable aux = new MacNetTable();
		aux.MAC = MAC;
		aux.netFace = net;
		routerTable.addElement(aux);

		MacIpTable aux2 = new MacIpTable();
		aux2.MAC = MAC;
		aux2.IP = IP;
		ipTable.addElement(aux2);		
	}

	private Netface searchNetface(String mac)
	{
		for(Iterator it = routerTable.iterator(); it.hasNext(); )
		{
			MacNetTable r = (MacNetTable)it.next();
			if (r.MAC.equals(mac))
			{
				return r.netFace;
			}
		}
		return null;
	}

	public int sendData(String destMAC, int addr, int data)
	{
		Netface dest = searchNetface( destMAC );
		
		if ( dest == null )
		{
			return dest.ERRORCODE_UNKWON_IP;
		}
		else
		{
			// status == 0 --> OK, status == -1 --> BUFFER FULL
			int status = dest.putRecvBuffer(addr, data);
			if ( status == -1)
			{
				return dest.ERRORCODE_RECV_BUFFER_FULL;
			}
			sendedSize++;
		}
		return dest.ERRORCODE_SEND_SUCCESS;
	}

	public void wakeupDest(String destMAC)
	{
		Netface dest = searchNetface( destMAC );
		dest.setRecvSize( sendedSize );
		dest.wakeUp();
		sendedSize = 0;
	}

	public void lockSend(){ mutex.P(); }
	public void unlockSend(){ mutex.V(); }

	//This is called for the Netface to return to kernel in the boot time..
	public Vector getRouterTable() { return ipTable; }

	public void printRouterTable()
	{
		System.err.println(ipTable);
	}
}

class Kernel
  {
  // Access to hardware components, including the processor
  private IntController hint;
  private Memory mem;
  private ConsoleListener con;
  private Timer tim;
  private Disk dis;
  private Processor pro;
  private Netface net;
  private JTextArea scr;
  
  // Data used by the kernel
  private ProcessList readyList;
  private ProcessList diskList;  
  private ProcessList netfaceList;
  private OpenFileTable openFile;
  private int processCounter;  //Just to facilitate de creatiation of the PID..
  private int diskState;
  private boolean[] freePartitionTable;
  private int remainingTime;
  private Vector ipTable;
  private int numberMsg;
  private int[] receiveMsgBuffer;

  private final int DISK_READY = 0;
  private final int DISK_BUSY = 1;  
  private final int MAX_TIME_SLICE = 8;
  private final int MEMORY_SIZE = 128;

  public void setDiskState( int state ) { diskState = state; }
  public int getDiskState(){ return diskState; }

  // In the constructor goes initialization code
  public Kernel(IntController i, Memory m, ConsoleListener c, Timer t, Disk d, Processor p, Netface ne, JTextArea sc )
    {
    hint = i;
    mem = m;
    con = c;
    tim = t;
    tim.setSlice( MAX_TIME_SLICE );
    dis = d;
    pro = p;
    net = ne;
    scr = sc;
    ipTable = net.getRouterTable();
    readyList = new ProcessList ();
    diskList = new ProcessList ();
    netfaceList = new ProcessList ();
    readyList.pushBack( new ProcessDescriptor(0) );
    readyList.getBack().setPC(0);
    readyList.getBack().setMemLimit( 1 );
    readyList.getBack().setMemBase( 0 );
    readyList.getBack().setTime( MAX_TIME_SLICE );
    mem.setLimitRegister(1);
    mem.setBaseRegister(0);
    diskState = DISK_READY;
    processCounter = 1;
    freePartitionTable = new boolean[6];
    freePartitionTable[0] = false; //The first two partition is reserved for kernel stuffs...
    freePartitionTable[1] = false;
    for(int k=2; k<6; k++)
    	freePartitionTable[k] = true;
    remainingTime = MAX_TIME_SLICE;
    numberMsg = 0;
    receiveMsgBuffer = new int[net.getBufferSize()];
    }
  private void consoleStringParser( String inputLine, OpenFileTable arq )
  {
     StringTokenizer st = new StringTokenizer(inputLine);

     if (st.countTokens() != 4)
     {
	     System.err.println("CONSOLE PARSER ERROR.... TO FEW OR TO MANY TOKENS...");
     }
     else
     {
	     String p = new String (st.nextToken());
	     String a1 = new String (st.nextToken());
	     String a2 = new String (st.nextToken());
	     String o = new String (st.nextToken());
	     openFile = new OpenFileTable();
	     openFile.setAllInitPos(Integer.parseInt(p),Integer.parseInt(a1),Integer.parseInt(a2),Integer.parseInt(o));
	     
     }

  }

  //This is a function that finds the first free space in memory...
  //and return a pointer to the partition... or -1 if it didn't find one...
  private int findFirstFreePartition()
  {
	for(int i=0; i<6; i++)
	{
		if ( freePartitionTable[i] )
			return i;
	}
	return -1;
  }

  //Final version reminder: don't forget to check out if 'i' is outside of the range...
  private void setOcupedPartition(int i){ freePartitionTable[i] = false;  }
  private void setFreePartition(int i)
  { 
	  freePartitionTable[i] = true; 
	  while( i < MEMORY_SIZE )
		  mem.superWrite(i++,0);
  }
	  
  private String findMAC( int IP )
  {
	for(Iterator it = ipTable.iterator(); it.hasNext(); )
	{
		MacIpTable r = (MacIpTable)it.next();
		if (r.IP == IP)
		{
			return r.MAC;
		}
	}
	return null;
  }
  private int[] parseINT( int i )
  {
	  int[] t = new int[4];
	  
	  t[0] = i>>>24;
	  t[1] = (i>>>16) & 255;
	  t[2] = (i>>>8) & 255;
	  t[3] = i & 255;

	  return t;
  }
	  
  
  // Each time the kernel runs it have access to all hardware components
  public void run(int interruptNumber)
    {  
    int address,whatFile,data;
    ProcessDescriptor aux = null;
    // This is the entry point: must check what happened
    System.err.println("Kernel called for int "+interruptNumber);
    // save context
    readyList.getFront().setPC(pro.getPC());
    readyList.getFront().setReg(pro.getReg());
    readyList.getFront().setTime(tim.getTime());
    switch(interruptNumber)
      {
    //Hardware INTs:
    case 2: // HW INT timer
        
	aux = readyList.popFront();
	aux.setState(aux.PROC_READY);
        readyList.pushBack(aux);
	
	readyList.getFront().setState(aux.PROC_RUNNING);
	mem.setLimitRegister(readyList.getFront().getMemLimit());
	mem.setBaseRegister(readyList.getFront().getMemBase());

        System.err.println("CPU runs: "+readyList.getFront());
        break;
    case 3: //Illegal memory access...
	    aux = readyList.popFront();
	    System.err.println("Illegal Memory Access of PROC #"+aux.getPID()+"\nThe PROC was trying to access MEM["+aux.getPC()+"]\n"); 	    
	    scr.append("PROC #"+aux.getPID()+": SEGMENTATION FAULT!\n");
	    setFreePartition(aux.getMemBase()/MEMORY_SIZE);
	    readyList.getFront().setState(aux.PROC_RUNNING);
	    break;
    case 5: // HW INT disk 
//	    System.err.println("THE DISK FINISHED WHAT IT WAS DOING...");
	    aux = diskList.popFront();
	    if( (dis.getError() == dis.ERRORCODE_SOMETHING_WRONG) || 
		(dis.getError() == dis.ERRORCODE_ADDRESS_OUT_OF_RANGE) ||
		(dis.getError() == dis.ERRORCODE_MISSING_EOF) )
	    {
		    //So we got an error.....Put 1 in R1..
		    (aux.getReg())[1] = 1;
		    (aux.getReg())[0] = 0; //...Missing the end of the file..or address out of range...
		    			   // note that in both case we can say that we already reach the end of file
		    
		    System.err.println("Kernel Say: Disk Load Unsuccefull. Reason: "+
				    ((dis.getError() == dis.ERRORCODE_SOMETHING_WRONG)? "SOMETHING WRONG": ( 
					(dis.getError() == dis.ERRORCODE_ADDRESS_OUT_OF_RANGE)? "ADDRESS OUT OF RANGE": 
					"MISSING END OF FILE") )
				    );
		    setDiskState( DISK_READY );
	    }
	    else
	    { 
//		    System.err.println("NO ERROR WHILE READING THE DISK......");
		    if( aux.getDiskState() == aux.DISK_LOAD )
		    {
//			    System.err.println("THE DISK WAS REQUEST FOR A LOAD.....");
			    int sizeOfProgram = dis.getSize();
			    int initDiskBuffer = 0;
			    int initMemProgram = aux.getMemBase();

			    while( sizeOfProgram != 0 )
			    {
				    mem.superWrite(initMemProgram++,dis.getData(initDiskBuffer++));
				    sizeOfProgram--;
			    }
			    scr.append("PROC #"+aux.getPID()+": CREATED\n");
		    }
		    else if( aux.getDiskState() == aux.DISK_READ )
		    {
//			    System.err.println("THE DISK WAS REQUESTED FOR A READ....");
			    (aux.getReg())[0] = dis.getData(0);
			    (aux.getReg())[1] = 0;
//			    System.err.println("KERNEL READ 1 BYTE FROM DISK....");
		    }
		    else
		    {
			    //WRITE
//			    System.err.println("THE DISK WAS REQUESTED FOR A WRITE.....");
			    (aux.getReg())[1] = 0;
//    			    System.err.println("KERNEL WROTE 1 BYTE IN DISK.....");
		    }

		    aux.setState(aux.PROC_READY);
		    readyList.pushBack(aux);		    

		    if ( diskList.getFront() != null )
		    {
//			    System.err.println("KERNEL FOUND DISK LIST NOT FULL......");
			    ProcessDescriptor next = diskList.getFront();
			    int[] regs = next.getReg();
			    address = next.getOpenFile().getCurrentPos(regs[0]);
			    int operation = (next.getDiskState() == next.DISK_LOAD)? dis.OPERATION_LOAD
				    			: ( (next.getDiskState() == next.DISK_READ)? dis.OPERATION_READ :
							  dis.OPERATION_WRITE );
			    dis.roda(operation,address,regs[1]); 
			    if (regs[0] != 0)
			    {
				    address++;
				    next.getOpenFile().setCurrentPos(regs[0],address);
			    }
			    setDiskState(DISK_BUSY);
		    }
		    else
		    {
//			    System.err.println("KERNEL DIDN'T FIND ANY PROC IN THE DISK LIST.....");			    
			    setDiskState(DISK_READY);
		    }
	    }
	   break;
    case 10: //HW INT netface
	     System.err.println("KERNEL: MESSAGE RECEIVED!!THE NETFACE CALLED...."); 
	     scr.append("KERNEL: Message received!\n");
	     numberMsg++;
	     int dataSize = net.getRecvSize();
	     int j = net.getRecvBufferAddr();
	     aux = netfaceList.popFront();

	     //There is someone waiting for this???
	     if ( aux != null )
	     {
		     //...then we can write directly to memory....
		     numberMsg--;
		     int memAdr = (aux.getReg())[0] + aux.getMemBase();
		     while( dataSize > 0 )
		     {
			     mem.superWrite(memAdr++,net.getRecvData(j++));
			     dataSize--;			     
		     }
		     (aux.getReg())[1] = net.getRecvSize();
		     net.resetRegs();
		     readyList.pushBack(aux);
	     }
	     else
	     {//..put into a buffer...
		     int k = 0;
		     while( dataSize > 0 )
		     {
			     receiveMsgBuffer[k++] = net.getRecvData(j++);
			     dataSize--;
		     }		     
	     }
	     break;	     
    case 15: // HW INT console
        
	int partition = findFirstFreePartition();

	//Here I consider that the person who is typing somethings is a gentleman and
	//he/she are going to digit exactly 4 numbres in the terminal... but to the final
	//version of SOPA we need to verify if the openFile is a valid one...
	consoleStringParser( con.getLine() , openFile );

        if ( partition != -1 )
	{
		int initMemProgram = partition*MEMORY_SIZE;

		//Creating Processor Descriptor
		setOcupedPartition(partition); //The memory ocupped for the proc
		aux = new ProcessDescriptor(processCounter++);
		aux.setDiskState(aux.DISK_LOAD); //What he wants next...
		aux.setState(aux.PROC_CREATION); //its state...
		aux.setMemBase(initMemProgram);  //the base register for mem. address resolution...
    		aux.setMemLimit( MEMORY_SIZE );  //the max address "alcancavel" by a proc...
		aux.setTime( MAX_TIME_SLICE );   //the max slice of time that a proc "merece"
		aux.setOpenFile( openFile );     //the open file table....
		aux.setPC(0);

		(aux.getReg())[0] = 0; //This is just for the case that the disk is busy...
	
		//Process load:
		//Here we have some confusing functions: If a proc makes "proc.getDiskState" this 
		//means what the PROC wants to do with the disk... if you see only "getDiskState" this
		//means the disk's state for KERNEL.... "Alles klar?"....dammit.. I need to stop this 
		//german's things...
		//Is the disk free to receive some request...???
		if (getDiskState() == DISK_READY)
		{
			//...yes! Greate... Go get it tiger...
//			System.err.println("THE DISK WAS READY AND I'LL START THE LOAD....");			
			setDiskState(DISK_BUSY);
			dis.roda(dis.OPERATION_LOAD,aux.getOpenFile().getInitPos(aux.getOpenFile().PROGRAM_ARQ),0);
		}
/*		else
			System.err.println("THE DISK WAS NOT READY, SO I'LL GO TO AND OF THE QUEUE....");*/
		//Now block this process....
		diskList.pushBack(aux);
	}
	else
	{//Bad Memory....No donut for you... No free space...
		scr.append("KERNEL: The System is dangerous out of resorces... No free Memory to allocate a new PROC!\n");
	}
        break;
	
    //Software INTs:
    case 32: System.err.println("SW INT EXIT"); 
	     aux = readyList.popFront();
	     setFreePartition(aux.getMemBase()/MEMORY_SIZE);
	     processCounter--;
	     readyList.getFront().setState(aux.PROC_RUNNING);//Putting the next proc running...
	     scr.append("PROC #"+aux.getPID()+": EXIT\n");
	     break;
    case 36: System.err.println("SW INT GET"); 
	     aux = readyList.popFront();
	     aux.setState(aux.PROC_BLOCKED);
	     aux.setDiskState( aux.DISK_READ );
	     whatFile = (aux.getReg())[0];
	     address = aux.getOpenFile().getCurrentPos(whatFile);
	     if (address == -1)
	     {
		     (aux.getReg())[1] = 1;
		     (aux.getReg())[0] = 1;
		     aux.setState(aux.PROC_READY);
		     readyList.pushBack(aux);
	     }
	     else
	     {
//		     System.err.println("KERNEL WAS CALLING FOR A SW GET....");
		     if ( getDiskState() == DISK_READY )
		     {
//			     System.err.println("THE DISK WAS READY AND I'LL START THE READ....");
			     setDiskState( DISK_BUSY );
			     dis.roda(dis.OPERATION_READ,address,0);
			     address++;
			     aux.getOpenFile().setCurrentPos(whatFile,address);
		     }
/*		     else
			     System.err.println("THE DISK WAS NOT READY, SO I NEED TO ENTER THE QUEUE....");*/
		     diskList.pushBack(aux);
	     }
	     break;
    case 37: System.err.println("SW INT PUT"); 
	     aux = readyList.popFront();
	     aux.setState(aux.PROC_BLOCKED);
	     aux.setDiskState( aux.DISK_WRITE );
	     whatFile = (aux.getReg())[0];
	     data = (aux.getReg())[1];
	     if ( (whatFile != aux.getOpenFile().PROGRAM_ARQ) &&
	          (whatFile != aux.getOpenFile().OUTPUT_ARQ) )
	     {
		     (aux.getReg())[1] = 1;
		     (aux.getReg())[0] = 1;
		     aux.setState(aux.PROC_READY);
		     readyList.pushBack(aux);
	     }
	     else
	     {
//		     System.err.println("KERNEL WAS CALLED FOR A PUT AND I'LL TRY IF DISK IS FREE....");
	     	     address = aux.getOpenFile().getCurrentPos(whatFile);
		     if ( getDiskState() == DISK_READY )
		     {
//			     System.err.println("THE DISK WAS READY AND I'LL START THE WRITE....");
			     setDiskState( DISK_BUSY );
			     dis.roda(dis.OPERATION_WRITE,address,data);
			     address++;
			     aux.getOpenFile().setCurrentPos(whatFile,address);
		     }
/*		     else
    			     System.err.println("THE DISK WAS NOT READY, SO I NEED TO ENTER THE QUEUE...");*/
		     diskList.pushBack(aux);
	     }
	     break;
    case 38: System.err.println("SW INT READ"); break;
    case 39: System.err.println("SW INT WRITE"); break;
    case 42: System.err.println("SW INT RECV"); 
	     aux = readyList.popFront();
	     aux.setState(aux.PROC_BLOCKED);
	     if( numberMsg > 0 )
	     {
		     numberMsg--;
		     int memAdr = (aux.getReg())[0]+aux.getMemBase();
		     int msgSize = net.getRecvSize();
		     int l = net.getRecvBufferAddr();
		     while( msgSize > 0 )
		     {
			     mem.superWrite(memAdr++,net.getRecvData(l++));
			     msgSize--;
		     }
		     (aux.getReg())[1] = net.getRecvSize();
		     aux.setState(aux.PROC_READY);
		     readyList.pushBack(aux);
	     }
	     else
		     netfaceList.pushBack(aux);
	     break;
    case 43: //SW INT send -- calling the netface....
	     System.err.println("SW INT SEND");
	     aux = readyList.getFront();
	     int temp = (aux.getReg())[2];
	     int[] b = parseINT(temp);
	     int ip = b[0]*100000+b[1]*100+b[2]*10+b[3];
	     String destino = findMAC( ip );
	     if (destino != null)
	     {
		     int addrBuffer = (aux.getReg())[0] + aux.getMemBase();
		     int msgSize = (aux.getReg())[1];
		     int status = net.send(destino,addrBuffer,msgSize);
		     if (status == net.ERRORCODE_SEND_SUCCESS)  
			     (aux.getReg())[0] = 0;
		     else
		     {
			     scr.append("KERNEL: Destiny buffer is FULL!\n");
			     (aux.getReg())[1] = 1;
			     (aux.getReg())[0] = 2;
		     }
	     }
	     else//Unknown IP
	     {
		     (aux.getReg())[1] = 1;
		     (aux.getReg())[0] = 1;
		     scr.append("KERNEL: The host "+ip+" does not exist!\n");

	     }
	     scr.append("PROC #"+aux.getPID()+": SENDED A MSG TO "+ip+"\n");
	     break;
    case 46: System.err.println("SW INT PRINT"); 
	     aux = readyList.getFront();
      	     int[] bytes = parseINT((aux.getReg())[0]);
	     scr.append( "Proc #"+aux.getPID()+" Say: "+
			     bytes[0]+" "+
			     bytes[1]+" "+
			     bytes[2]+" "+
			     bytes[3]+"\n");
	     break;
    default:
        System.err.println("Unknown INT...");
      	}
    // restore context
    pro.setPC(readyList.getFront().getPC());
    pro.setReg(readyList.getFront().getReg());
    mem.setLimitRegister(readyList.getFront().getMemLimit());
    mem.setBaseRegister(readyList.getFront().getMemBase());
    tim.setTime(readyList.getFront().getTime());
		}

}

class FileDescriptor
{
	public int initPos;     //Initial position inside the file
	public int currentPos;  //Current position inside the file
}

class OpenFileTable
{
	private FileDescriptor[] openFile;

	public final int PROGRAM_ARQ = 0;
	public final int INPUT_ARQ1 = 1;
	public final int INPUT_ARQ2 = 2;
	public final int OUTPUT_ARQ = 3;
	
	public OpenFileTable()
	{
		openFile = new FileDescriptor[4];

		for(int i=0;i<4;i++)
		{
			openFile[i] = new FileDescriptor();
			openFile[i].initPos = 0;
			openFile[i].currentPos = 0;
		}
	}

	public void setAllInitPos(int program, int in1, int in2, int out)
	{
		openFile[PROGRAM_ARQ].initPos = program;
		openFile[INPUT_ARQ1].initPos = in1;
		openFile[INPUT_ARQ2].initPos = in2;
		openFile[OUTPUT_ARQ].initPos = out;
		openFile[PROGRAM_ARQ].currentPos = program;
		openFile[INPUT_ARQ1].currentPos = in1;
		openFile[INPUT_ARQ2].currentPos = in2;
		openFile[OUTPUT_ARQ].currentPos = out;

	}

	public void setInitPos(int arq, int pos) //throws ArrayOutOfBoundsException
	{
		openFile[arq].initPos = pos;
	}
	public void setCurrentPos(int arq, int pos) //throws ArrayOutOfBoundsException)
	{
		openFile[arq].currentPos = pos;		
	}
	public int getCurrentPos(int arq)
	{
		if ( (arq < 0) || (arq > 3) )
			return -1;
		return openFile[arq].currentPos;	
	}
	public int getInitPos(int arq)
	{
		return openFile[arq].initPos;	
	}
}

class ProcessDescriptor
  {
  private int PID;
  private int PC;
  private int[] reg;
  
  //This was added by PAULO..........
  //
  //Some usefull(less) constants...
  public final int PROC_RUNNING = 0;
  public final int PROC_BLOCKED = 1;
  public final int PROC_READY = 2;
  public final int PROC_CREATION = 3;
  
  //diskWanted states, to remind kernel what it should do after int 5..
  public static final int DISK_READ = 0;
  public static final int DISK_LOAD = 1;
  public static final int DISK_WRITE = 2;
  public static final int DISK_SPECIAL_LOAD = 3;
  
  private int processState;
  private int diskWanted; //The process could load or write from the disk, this is the state used in
  			  //the blocked disk queue
  private OpenFileTable openFile;
  private int baseMemory;
  private int limitMemory;
  private int remainingTime;
  
  private ProcessDescriptor next;
  public int getPID() { return PID; }
  public int getPC() { return PC; }
  public void setPC(int i) { PC = i; }
  public int[] getReg() { return reg; }
  public void setReg(int[] r) { reg = r; }
  public ProcessDescriptor getNext() { return next; }
  public void setNext(ProcessDescriptor n) { next = n; }
  public void setState(int state){ processState = state; }
  public int getState(){ return processState; }
  public void setDiskState(int state){ diskWanted = state; }
  public int getDiskState(){ return diskWanted; }
  public void setOpenFile(OpenFileTable arq ){ openFile = arq; }
  public OpenFileTable getOpenFile(){ return openFile; }
  public void setMemBase(int base) { baseMemory = base; }
  public int getMemBase(){ return baseMemory; }
  public void setMemLimit(int limit){ limitMemory = limit; }
  public int getMemLimit(){ return limitMemory; }
  public void setTime(int time){ remainingTime = time; }
  public int getTime(){ return remainingTime; }
  public ProcessDescriptor(int pid) 
    {
    PID = pid;
    PC = 0;
    reg = new int[16];
    openFile = new OpenFileTable();
    remainingTime = 3;
    }
  
  public String toString()
  {
	  return "PROC--#"+PID+": \n\tPC = "+PC+"\n\tProcess STATE = "+
		  ((getState() == 0)? "RUNNING" : ( (getState() == 1)? "BLOCKED" : 
						    ( (getState() == 2)? "READY" : "CREATION")))+"\n"+
		  "\tMemory Base Register = "+baseMemory+"\n"+
		  "\tMemory Limit Register = "+limitMemory+"\n"+
	  	  "\tCPU time = "+remainingTime;
  }
  
  }
	
// This list implementation (and the 'next filed' in ProcessDescriptor) was
// programmed in a class to be faster than searching Java's standard lists,
// and it matches the names of the C++ STL. It is all we need now...

class ProcessList
  {
  private ProcessDescriptor first = null;
  private ProcessDescriptor last = null;
  public ProcessDescriptor getFront() { return first; }
  public ProcessDescriptor getBack() { return last; }
  public ProcessDescriptor popFront() 
    { 
    ProcessDescriptor n;
    if(first!=null)
      {
      n = first;
      first=first.getNext();
      if (last == n)
        last = null;
      n.setNext(null);
      return n;
      }
   return null;
    }
  public void pushBack(ProcessDescriptor n) 
    { 
    n.setNext(null);
    if (last!=null)
      last.setNext(n);
    else
      first = n; 
    last = n;
    }
  }
