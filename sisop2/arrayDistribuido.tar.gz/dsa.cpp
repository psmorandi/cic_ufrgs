#include "dsa.hpp"

//Contrutor:
DSA::DSA( int id )
{

#ifdef DEBUG
	cout << "Constructor in...." << endl;
#endif
	int i;
	macID = id;
	pageQueue = id*4;

	setupRecvSocket();  //Inicializa socket de recebimento
	setupSendSocket();  //Inicializa socket de envio
	
	pthread_mutex_init(&mutex,NULL);  //Mutex, para garantir exclus�o m�tua na hora de setar a var de condi��o  wait
	pthread_cond_init(&wait,NULL);    //Vari�vel de condi��o que far� o processo dormir ateh que seja acordado

#ifdef DEBUG
	cout << "Initializing control Vector....";
#endif
	//Inicializa vetor de controle
	for(i=0;i<64;i++)
	{
		controlVector[i] = i+id*4;
	}
	//Exemplo:
	//Se meu id � 3, ent�o as p�ginas pelas quais eu sou 
	//respons�vel s�o: 12, 13, 14 e 15. 
#ifdef DEBUG
	cout << "DONE!!" << endl;
	cout << "Initializing local Vector....";
#endif
	for(i=0;i<256;i++)
	{
		localVector[i] = i+id*256;
	}
	//A posi�ao i do vetor tem valor i. Exemplo: o valor de 
	//localVector[555] � 555...

#ifdef DEBUG
	cout << "DONE!!" << endl;
	cout << "Constructor out...." << endl;
#endif

}

//Essa fun�ao inicializa a thread de recebimento de requisi�oes
void *startRecvThread(void *dsaClass)
{
	DSA *temp = (DSA *)dsaClass;

	while (1)
	{
		temp->waitForRequest();
	}
}

void DSA::run()
{
	pthread_create(&recv_thread,NULL,startRecvThread,(void *)this);
	//pthread_create(&send_thread,NULL,sendPageRequest,....);
}

DSA::~DSA() //Destrutor da classe
{
	pthread_join(recv_thread,NULL);
	//pthread_join(send_thread,NULL);
}

//Vide coment�rio no construtor da classe
void DSA::setupRecvSocket()
{
	struct protoent *protocol;

	if ( (protocol = getprotobyname("udp")) == NULL )
	{
		cerr << "Protocolo UDP n�o suportado!!" << endl;
		exit(-1);
	}

	if ( (sock = socket( PF_INET, SOCK_DGRAM, protocol->p_proto)) < 0 )
	{
		cerr << "N�o foi poss�vel criar o socket!!" << endl;
		exit(-1);
	}

	memset(&recv,0,sizeof(recv));

	recv.sin_family = AF_INET;
	recv.sin_port = htons( PORT );

	int i = bind(sock,(struct sockaddr *)&recv,sizeof(recv));
	
	if( i < 0)
	{
		cout << "N�O POSSO ME ASSOCIAR A PORTA "<< PORT << "# " << i << endl;
		exit(-1);
	}

}

//Idem setupRecvSocket, s� que para envio...
void DSA::setupSendSocket()
{
	int b=1;
	struct protoent *protocol;
	
	if ( (protocol = getprotobyname("udp")) == NULL )
	{
		cerr << "Protocolo UDP n�o suportado!!" << endl;
		exit(-1);
	}


	if ( (sendSocket = socket( PF_INET, SOCK_DGRAM, protocol->p_proto)) < 0 )
	{
		cerr << "N�o foi poss�vel criar o socket!!" << endl;
		exit(-1);
	}
	
	setsockopt(sendSocket,SOL_SOCKET,SO_BROADCAST,&b,sizeof(b));

	memset(&dest,0,sizeof(dest));
	
	dest.sin_family = AF_INET;
	dest.sin_addr.s_addr = INADDR_BROADCAST;
	dest.sin_port = htons( PORT );
}

//Devolve o elemento de �ndice "index", dentro do localVector
//Exemplo: quero acessar o elemento 433 que est� na p�gina
//6. Dentro do controlVector a p�gina 6 responde pelo �ndice
//2. Logo, index = 433, start = 2 e page = 6. Logo, sua posi�ao 
//relativa dentro do vetor localVector � start*64 (2*64 = 128) + 
//seu deslocamento relativo (index - page*64, 433 - 384 = 49)
//Portanto a p�gina 6 come�a na posi�ao 128 do localVector e o que
//queremos � o 49o. elemento.
int DSA::elementAt(int index, int start, int page)
{
	int localpos = start*64 + (index - page*64);

	return localVector[localpos];
}

//Procedimento de leitura dos elementos do localVector:
int DSA::read(int index)
{
	if( (index >= MAX_DIM) || (index<0) )
	//Index out of bound!!!
	{
		return -2;
	}
	else
	{
	
		int page = index / 64; //De qual p�gina estamos falando??
		int found = searchForPage( page ); //Ela est� aqui???

		if (found != -1 )
		//Acertou... a p�gina est� aqui...
		{
			return elementAt(index,found, page);
		}
		else
		//Temos que busc�-la em outra m�quina...
		{
#ifdef DEBUG
			cout << "Initializing page struct...." << endl;
#endif
			page_protocol pageR;
			pageR.id_page_request = page;
			setupPageProtocol(&pageR);
#ifdef DEBUG
			cout << "Initializing done!...." << endl;
			cout << "Preparing to send request...." << endl;
#endif
			sendPageRequest(pageR); //Envia a requisi��o
//============================================
//Aqui tem um problema.... como o sendPageRequest n�o se bloqueia
//O programa passa direto quando na verdade ele deveria esperar
//pela resposta de um dos computadores..... n�o adianta colocar
//um recvfrom aqui... tem uma thread que tem que ficar escutando
//por requisi��es.... o que se quer ent�o?? Que o programa fique aqui 
//bloqueado at� que uma mensagem chegue e a thread libere o programa para
//continuar
//============================================

			//Isso eh uma tentativa de solucionar o problema
			//acima. Parece que funciona:
			pthread_mutex_lock(&mutex);
			pthread_cond_wait(&wait,&mutex);
			pthread_mutex_unlock(&mutex);
			//============================
			//
			int found2 = searchForPage(page); //Como alguem respondeu n�o vai dar page fault...
			return elementAt(index,found2,page); 
		}

	}
	return -1; //S� para n�o d� warning...
}

//Procedimento que busca dentro do controlVector
//a p�gina "page" e retorna o �ndice do controlVector
//Maiores explica�oes do porque disso est� em dsa.hpp
int DSA::searchForPage(int page)
{
	for(int i=0;i<PAGES_PER_MAC;i++)
	{
		if ( controlVector[i] == page )
			return i;
	}

	return -1;
}

//Disparada por uma thread, essa procedure � respons�vel
//por ficar escutando as mensagens da rede enviadas por broadcast
//nesse caso estamos supondo que nenhuma mensagem que n�o seja vinda
//deste programa pode chegar...
int DSA::waitForRequest( )
{
	char buffer[274]; //256 pra guardar os 64 int do array e mais 8 pra guardar os dois ints da estrutura
	page_protocol pageRecv;


#ifdef DEBUG
		cout << "Waiting for Pages Request...." << sock << endl;
#endif
		recvfrom(sock,buffer,274,0,(struct sockaddr *)&recv,(socklen_t *)sizeof(recv));
#ifdef DEBUG
		cout << "Someone Sended something.. checking for response...." << endl;
#endif
		pageRecv.id_page_request = buffer[0]; //Que p�gina ele necessita???
#ifdef DEBUG
		cout << "Page Requested = " << pageRecv.id_page_request << endl;
#endif 
		if( pageRecv.id_page_request == REQUEST_RESPONSE ) //Essa mensagem j� eh a resposta com a p�gina????
		{
			pthread_mutex_lock(&mutex);
//			substitui a p�gina:
			controlVector[pageQueue-1] = pageRecv.id_page_request; //Aqui deveria vir uma zona 
								     //de exclus�o m�tua...
			
			for(int i=0;i<64;i++)
			{
				localVector[(pageQueue-1)*64+i] = pageRecv.page[i];
			}
			pthread_cond_signal(&wait);
			pthread_mutex_unlock(&mutex);
			printStatus();
			printLocalArray();
			return 0;
		}//if
		else//N�o, humm.. ent�o alguem precisa de uma ajuda....
		{
			for(int i=0;i<PAGES_PER_MAC;i++)
			{
				if ( controlVector[i] == pageRecv.id_page_request ) //Eu possuo essa p�gina???
				{//Sim...
					pageRecv.id_page_sended = buffer[4]; //Qual p�gina ele est� enviando para troca??
#ifdef DEBUG
					cout << "Page Sended = " << pageRecv.id_page_sended << endl;
#endif	
					for(int i=0;i<256;i+=4)
					{
						pageRecv.page[i/4] = buffer[i+8];
					}
					for(int i=0;i<64;i++)
					{
						localVector[(pageQueue-1)*64+i] = pageRecv.page[i]; //Trocando a p�gina...
					}
					sendPageResponse(recv,pageRecv.id_page_request); //Enviando  a p�gina necessitada...
					break;
				}//if
			}//for
		}//else

		return -1;
}

//Apenas apronta a estrutura que controla as requisi�oes de p�gina
void DSA::setupPageProtocol(page_protocol *pageR)
{
	//Esquema de escolha da p�gina a ser enviada:
	//Lista Circular!
	pageR->id_page_sended = pageQueue++; 
	if( pageQueue > 4+4*macID )
		pageQueue = macID;
	
	for(int i=0;i<TAM_PAGE;i++)
	{
		pageR->page[i] = localVector[pageR->id_page_sended*64+i];
	}
}

//Procedure respons�vel por enviar o pedido de uma p�gina via broadcast
void DSA::sendPageRequest( page_protocol sendMSG )
{
	char sendbuffer[274]; //Buffer de envio...

#ifdef DEBUG
	cout << "Setting up message for request a page...." << endl;
#endif

	sendbuffer[0] = sendMSG.id_page_request;
	sendbuffer[4] = sendMSG.id_page_sended;

#ifdef DEBUG
	cout << "REQUESTING PAGE = " << sendMSG.id_page_request << endl; 
	cout << "SENDING PAGE #" << sendMSG.id_page_sended << endl;
#endif
	
	for(int i=0;i<256;i+=4)
	{
		sendbuffer[i+8] = sendMSG.page[i/4]; //Lembrando que cada inteiro ocupa 4 pos do array de char...
	}

#ifdef DEBUG
	cout << "Message setup done!" << endl;
	cout << "Sending request...." << endl;
#endif

	while( ( sendto(sendSocket,sendbuffer,274,0,(struct sockaddr *)&dest,sizeof(dest)) ) != 274 )
			;
	close(sock);
}

//Procedure respons�vel por enviar a resposta com a p�gina requisitada
void DSA::sendPageResponse(struct sockaddr_in s, int page)
{
	char sendbuffer[274];

	sendbuffer[0] = REQUEST_RESPONSE; //Controle especial para avisar a thread de recebimento que isso n�o � uma nova requisi��o e sim uma resposta a uma..
	sendbuffer[4] = page;

	for(int i=0;i<256;i+=4)
	{
		sendbuffer[i+8] = localVector[(page*64)+(i/4)];
	}

	sendto(sock,sendbuffer,274,0,(struct sockaddr *)&s,sizeof(s));
			
	close(sock);
}


//Imprime quais s�o as p�ginas est�o nessa m�quina..
void DSA::printStatus()
{
	cout << "MAQ#" << macID << ", P�ginas locais = ";
	
	for(int i=0;i<PAGES_PER_MAC;i++)
	{ 
		cout << controlVector[i] << " ";
	}
	cout << endl;
}

//Imprime o array propriamente dito:
void DSA::printLocalArray()
{
	int l = 0;
	
	cout << "MAQ#" << macID << ", Vetor local: " << endl << "\t";
	
	for(int i=0;i<PAGES_PER_MAC*TAM_PAGE;i++)
	{ 
		cout << localVector[i] << " ";
		if( l > 15)
		{
			l = 0;
			cout << endl << "\t";
		}
		l++;
	}
	cout << endl;
}
