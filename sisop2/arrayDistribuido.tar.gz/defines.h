#ifndef _DEFINES_H
#define _DEFINES_H

#include <sys/socket.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netdb.h>
#include <errno.h>
#include <time.h>

#define PORT 5100 
#define TAM_PAGE 64
#define N_PAGE 16
#define MAX_DIM 1024
#define PAGES_PER_MAC 4
#define REQUEST_RESPONSE -1

#define DEBUG

//Pelo protocolo proposto pelo professor, quando requisitamos uma p�gina tamb�m enviamos a nossa
//para a troca. Id�ia do protocolo proposto : 
//Para Requisi��o:
// 1) Requisita uma p�gina via broadcast enviando a pr�pria p�gina e a requisi��o de outra;
// 2) Aguarda resposta; (!!!chegada de uma mensagem!!!!);
// 3)Pega a p�gina recebida e troca;
//
// =========================================================================================================
typedef struct _page_header_protocol {
	int id_page_request; //Identifica qual a p�gina que deseja; 
	int id_page_sended;  //Identifica qual a p�gina enviada;
	int page[TAM_PAGE];
} page_protocol;


#endif
