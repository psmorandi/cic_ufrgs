#ifndef DSA_HPP 
#define DSA_HPP

#include <iostream>
#include "defines.h"
#include <pthread.h>

using namespace std;

void *startRecvThread(void *dsaClass);

class DSA {
	private:
		int searchForPage(int page);
		int elementAt(int index, int start, int page);
		void setupPageProtocol(page_protocol *page);
		void sendPageRequest( page_protocol sendMSG);
		void sendPageResponse(struct sockaddr_in dest, int page);
		void setupRecvSocket();
		void setupSendSocket();

		int localVector[256]; //As p�ginas propriamente ditas;
		int controlVector[64];
		//========================================================
		// Funcionamento do controlVector:
		// - controlVector: 
		// 	- �ndice * 64 = onde come�a as p�ginas locais;
		// 	- conte�do = qual a p�gina;
		//========================================================
		
		pthread_t recv_thread; //Essa thread ficara escutando por pedidos da rede
//		pthread_t send_thread;
		pthread_mutex_t mutex;
		pthread_cond_t wait;
		int macID; //Indentificador da m�quina
		int pageQueue;
		int remoteData;
		int sock;
		int sendSocket;
		struct sockaddr_in recv,dest;

		
	public:
		DSA(int id);
		~DSA();
		void run();
		int read(int index);
	//	void write(int index, int data);
		int waitForRequest();
		void printStatus(); // Imprime quais as p�ginas est�o na mem�ria;


		void printLocalArray(); // Just for DEBUG
};

//
//DUVIDAS:
//
//- INICIALIZACAO SOCKETS
//- Inicializo 1 socket por m�quina, ou toda vez que eu for requisitar uma p�gina crio o socket,
//  comunico e destruo..
//
//  R.: pede via broadcast
//
//- PAGINAS: O que transferir na requisi��o?? A p�gina inteira ou somente o elemento a ser acessado;
//- R.: Trocar sua p�gina com ele


#endif
