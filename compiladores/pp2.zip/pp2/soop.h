/*****************************************************************************
  
  soop.h
  
  Do not modify this file.
  It provides constants and type definitions that will be used for the
  soop compiler.
  
  ****************************************************************************/

#ifndef _H_soop
#define _H_soop

#include "utility.h"
#include "declaration.h"


/*
 * These are defined in lex.yy.c
 */
void Inityylex(void);

int yylex(void);

extern int yylineno;
extern char yytext[];
extern int yy_flex_debug;


void Inityyparse(void);

/*
 * This is from y.tab.c
 */
int yyparse(void);
#endif



