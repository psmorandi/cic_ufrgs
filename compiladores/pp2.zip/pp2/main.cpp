/*********************************************************************

  main.cc
  
*********************************************************************/

#include "soop.h"
#include "utility.h"
#include <stdio.h>

static void ParseCommandLine(int argc, string argv[]);



main (int argc, string argv[]) {

  ParseCommandLine(argc, argv);
  Inityylex();
  Inityyparse();

  if (yyparse() != 0) {
    printf("\n*** Rejected\n");
  }
}


/*
 * Turn on the debugging flags from the command line.  Just
 * make sure that arg[1] is -d, and then interpret the rest
 * of the arguments as being flags to turn on.
 */
static void ParseCommandLine(int argc, string argv[]) {
  int i;
  
  if (argc == 1) {
    return;
  }
  
  if (!StringEqual(argv[1], "-d")) {
    printf("Usage:   -d <debug-key-1> <debug-key-2> ... \n");
    exit(2);
  }

  for (i = 2; i < argc; i++) {
    DebugOn(argv[i]);
  }
}




