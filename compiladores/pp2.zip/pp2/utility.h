/*****************************************************************************

  utility.h

  These are some helper functions to be used by the assignments.  
  They include functions for string manipulation, memory allocation,
  and error handling.

 *****************************************************************************/

#ifndef _H_utility
#define _H_utility

#include <stdlib.h>
#include <stdio.h>

/*** bool constants ***/

/*
 * Constants that can be used with type bool.
 */
#define TRUE  1
#define FALSE 0


/*** allocation ***/

/*  
 * Does the same thing as malloc, except that it will
 * fail if memory is not allocated.  So, if you use this, 
 * you do not have to check the return value to see if it
 * is non NULL.
 */
void *SafeAlloc(size_t nbytes);


/*** string operations ***/

/* 
 * string is just another name for a char *.  These functions just
 * give a fairly easy way to manipulate them.
 */
typedef char *string;


/*  
 * return TRUE if the two strings contain the same
 * sequence of characters.
 */
bool StringEqual(string s1, string s2);


/* 
 * Return a copy of the string allocated in the heap.
 */
string CopyString(string s);


/*** Error detection and handling ***/

/* 
 * Report an error to the user.  This is called yyerror for historical
 * reasons (lex and yacc expect the error reporting routine to be called
 * this).  Call this function to report any errors to the user.
 * yyerror takes printf arguments.
 */
void yyerror(string msg, ...);


/*
 * Reports and error and exits from the program.  You should not need to
 * call this since you should always try to continue parsing, even after
 * an error is encounted.  Some of the provided code calls this in the
 * case that your program will crash (ie, SafeAlloc cannot allocate memory,
 * CopyString is passed NULL, etc.).
 */
void Failure(string msg, ...);


/*** Debugging ***/

/* 
 * This tests the given expression.  If the expression is TRUE,
 * nothing happens.  If it is FALSE, it calls Failure to print
 * a message and abort the program.
 *
 * For example,
 *   Assert(ptr != NULL)
 * will print something similar to the following if ptr is NULL:
 *   *** Failure: Assertion Failed: hashtable.cc, line 55:
 *       ptr != NULL
 */ 
#define Assert(X)     _Assert(X, #X, __LINE__, __FILE__);

/*
 * this is a helper function for implementing Assert.  Do
 * not use this- use the macro above.
 */
void _Assert(bool test, string expr, int line, string file);

/* 
 * Print a message if we have turned debugging messages on for the given
 * key.  For example, 
 *
 *   PrintDebug("parser", "found ident %s\n", ident);
 * 
 * will only print a message if the call is preceded by a call to 
 * DebugOn("parser").  The function takes printf arguments.  The provided
 * main.cc parses the command line to turn on debug flags.  See
 * main.cc for more information.
 */
void PrintDebug(string key, string format, ...);

/*
 * Turn on debugging messages for the given name.  see PrintDebug
 * for an example.
 */
void DebugOn(string name);


#endif




