/*****************************************************************************

  utility.cc

  Some of this code is based on code from Eric Roberts' cslib libraries.


 *****************************************************************************/

#include "utility.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/*
 * from lex.yy.c
 */
extern char yytext[];
extern int yylineno;

#define BufferSize   1024
#define MaxDebugKeys  256

static bool KeyInList(string key);


void *SafeAlloc(size_t nbytes) {
  void *ptr = malloc(nbytes);
  Assert(ptr != NULL);
  return ptr;
}


bool StringEqual(string s1, string s2) {
  Assert(s1 != NULL && s2 != NULL);
  return strcmp(s1, s2) == 0;
}


string CopyString(string s) {
  string s2;
  
  Assert(s != NULL);

  s2 = (string)SafeAlloc(strlen(s) + 1);
  strcpy(s2, s);
  return s2;
}



void yyerror(string msg, ...) {
  va_list args;
  char errbuf[BufferSize];
  int errlen;
  
  va_start(args, msg);
  vsprintf(errbuf, msg, args);
  va_end(args);
  errlen = strlen(errbuf);
  if (errlen > BufferSize) {
    Failure("yyerror Message too long\n");
  } else {
    printf("\n*** Error on line %d (last token was '%s'):\n", 
	   yylineno, yytext);
    printf("*** %s\n\n", errbuf);
  }
}


void Failure(string msg, ...)
{
  va_list args;
  char errbuf[BufferSize];
  int errlen;
  
  va_start(args, msg);
  vsprintf(errbuf, msg, args);
  va_end(args);
  errlen = strlen(errbuf);
  if (errlen > BufferSize) {
    printf("\n*** Failure: Failure Message too long\n\n");
  } else {
    printf("\n*** Failure: %s\n\n", errbuf);
  }
  exit(1);
}


void _Assert(bool test, string expr, int line, string file) {
  if (!test) {
    Failure("Assertion Failed: %s, line %d:\n    %s",
	    file, line, expr);
  }
}


static string gDebugKeys[MaxDebugKeys];
static int gNumDebugKeys = 0;

void DebugOn(string key) {
#ifndef SOLUTION
  Assert(gNumDebugKeys < MaxDebugKeys - 1);
  gDebugKeys[gNumDebugKeys++] = CopyString(key);
#endif
}


void PrintDebug(string key, string msg, ...) {
  va_list args;
  char buf[BufferSize];
  int len;

  if (!KeyInList(key)) {
    return;
  }
  
  va_start(args, msg);
  vsprintf(buf, msg, args);
  va_end(args);
  len = strlen(buf);
  if (len > BufferSize) {
    Failure("PrintDebug Message too long\n");
  } else {
    printf("+++ Debug(%s): %s\n", key, buf);
  }  
}


static bool KeyInList(string key) {
  int i;
  for (i = 0; i < gNumDebugKeys; i++) {
    if (StringEqual(key, gDebugKeys[i])) {
      return TRUE;
    }
  }
  return FALSE;
}







