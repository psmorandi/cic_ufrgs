/*****************************************************************************

  declaration.cc

 *****************************************************************************/

#include "declaration.h"


/*
 * pp1: This is the simple declaration class for pp1/pp2. 
 * Just fill in the blanks.
 */

Declaration::Declaration(string ident, int firstOccurrence) {
  name = CopyString(ident);
  firstLine = firstOccurrence;
  numOccurrences = 1;
}

void Declaration::IncrementOccurrences(void) {
  numOccurrences++;
}

void Declaration::Print(void) {
  printf("(%s seen %d times, first on %d)\n", name, numOccurrences, firstLine);
}






