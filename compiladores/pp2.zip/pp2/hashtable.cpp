/*****************************************************************************

  hashtable.cc

  Implementation of the hashtable interface.  This is based on a 
  hashtable module distributed with Eric Roberts' cslib library.

 *****************************************************************************/

#include "hashtable.h"
#include "utility.h"
#include "limits.h"
#include "declaration.h"
#include <string.h>

#define Multiplier -1664117991

/* 
 * Set all buckets to NULL
 */
Hashtable::Hashtable(void) {
  int i;
  numItems = 0;
  for (i=0;i<TableSize;i++) {
    elems[i] = NULL;
  }
}

/*
 * Return some bucket assignment from 0 .. TableSize for a string.
 */
int Hashtable::Hash(string s) {
  string cp;
  long hashcode;

  hashcode = 0;
  for (cp = s; *cp; cp++) hashcode = hashcode * Multiplier + *cp;
  return ((int) ((hashcode & INT_MAX) % TableSize));
}

/* 
 * Return the element for the given string, or NULL if the key
 * is not found.
 */
HashtableElem *Hashtable::Find(string key) {
  int index = Hash(key);
  HashtableElem *elem;
  for (elem = elems[index]; elem != NULL; elem = elem -> next) {
    if (StringEqual(elem -> key, key)) {
      break;
    }
  }
  return elem;
}


/* 
 * Add the new value under the given key.  If the key is already
 * used, just replace the value with the new one.  Otherwise, add
 * a new element to the table.
 */
void Hashtable::Enter(string key, Declaration *value) {
  HashtableElem *elem = Find(key);
  if (elem == NULL) {
    int loc = Hash(key);
    elems[loc] = new HashtableElem(key, value, elems[loc]);
    numItems++;
  } else {
    elem -> value = value;
  }
}


/* 
 * Return the value or NULL for a given key
 */
Declaration *Hashtable::Lookup(string key) {
  HashtableElem *elem = Find(key);
  if (elem != NULL) {
    return elem -> value;
  }
  return NULL;
}

/*
 * Copy uses iterators to duplicate the hashtable.
 */
Hashtable *Hashtable::Copy(void) {
  Hashtable *newTable = new Hashtable;
  int currentBucket = 0;
  HashtableElem *currentElem = elems[currentBucket];

  PrintDebug("hashtable", "Copying hashtable");

  while (TRUE) {
    while (currentElem != NULL) {
	newTable -> Enter(currentElem -> key, currentElem -> value);
     
      currentElem = currentElem -> next;
    } 
    currentBucket++;
    if (currentBucket >= TableSize) {
      break;
    }
    currentElem = elems[currentBucket];
  }
  return newTable;
}



/*
 * Prints the hashtable in alphabetical order.  We just fill up an array,
 * bubble sort it, and then print each Declaration.  
 */
void Hashtable::Print(void) {
  int i, j;
  HashtableElem **temp = new HashtableElem*[numItems];
  HashtableIterator iter(this);
  HashtableElem *item;
  i = 0;
  while ((item = iter.Next()) != NULL) {
    temp[i++] = item;
  }
  for (i = 0; i < numItems; i++) {
    for (j = 0; j < numItems - 1; j++) {
      if (strcmp(temp[j+1]->key, temp[j]->key) < 0) {
	item = temp[j];
	temp[j] = temp[j+1];
	temp[j+1] = item;
      }
    }
  }
  for (i = 0; i < numItems; i++) {
    temp[i] -> Value() -> Print();
  }
  delete temp;
}


/*
 * HashtableIterators start with the first element of the first bucket.
 */
HashtableIterator::HashtableIterator(Hashtable *t) {
  currentElem = t -> elems[0];
  currentBucket = 0;
  table = t;
}


/*
 * If the element is NULL, then we are at the end so return NULL.
 * If it is not, then to increment, we must move down the linked list. 
 * If there is no next, then we must moved to the next bucket until
 * we find an element or reach the end of the table.
 */
HashtableElem *HashtableIterator::Next(void) {
  while (TRUE) {
    if (currentElem != NULL) {
      HashtableElem *temp = currentElem;
      currentElem = currentElem -> next;
      return temp;
    } 
    currentBucket++;
    if (currentBucket >= TableSize) {
      break;
    }
    currentElem = table -> elems[currentBucket];
  }
  return NULL;
}
  

/* 
 * HashtableElems are just containers for a <key,value> pair.  The only
 * methods provided are a constructor and accessors.
 */
HashtableElem::HashtableElem(string k, Declaration *v, HashtableElem *n) {
  key = CopyString(k);
  value = v;
  next = n;
}

string HashtableElem::Key(void) {
  return key;
}

Declaration *HashtableElem::Value(void) {
  return value;
}








