/*****************************************************************************

  hashtable.h

  Hashtable holding declarations.  This is a simple hashtable for
  storing Declarations indexed by a string.  It uses an array of linked
  lists to store the hashtable.  In addition to the usual 
  hashtable functions, there are 3 special features of this hashtable:

    1. Hashtable::Copy() will provide a complete copy of the table.  Note
       that this does not copy the Declarations stored in the table,
       so changing a Declaration will change something shared by both
       the original and the copy.

    2. HashtableIterators are provided for iterating over all the elements
       stored in a hashtable.  When you wish to perform an operations on
       all entires in a table, you should use iterators.  The following
       shows their use (this function prints the names of all variable
       declarations stored in the table):

         void PrintVariables(Hashtable *table) {
	   HashtableIterator iter(table);
	   HashtableElem *elem;
	   while ((elem = iter.Next()) != NULL) {
	     Declaration *decl = elem -> Value();
	     if (decl -> IsVariableDeclaration()) {
	       printf("%s\n", elem -> Key());
	     }
	   }
	 }

    3. A Hashtable::Print() method is provided.  Always use this method
       to print out hashtables.  It sorts the entries before printing them,
       making it easier to both debug and grade the assignments since the
       output will match the output of the sample solutions.


 *****************************************************************************/

#ifndef _H_hashtable
#define _H_hashtable

#include "utility.h"

class Declaration;
class HashtableElem;

#define TableSize  101

class Hashtable {
  protected:
    int numItems;
    HashtableElem *elems[TableSize];
    int Hash(string key);
    HashtableElem *Find(string key);

  public:
    Hashtable(void);

    void Enter(string key, Declaration *value);
    Declaration *Lookup(string key);
    void Print(void);
    Hashtable *Copy(void);
    
    friend class HashtableIterator;
};


class HashtableIterator {
  private:
    HashtableElem *currentElem;
    int currentBucket;
    Hashtable *table;
  public:

    HashtableIterator(Hashtable *table);

    /*
     * Return on Element and move cursor to the next one.
     * Returns NULL when there are no more elems to return
     */
    HashtableElem *Next(void);
};



class HashtableElem {
  private:
    string key;
    Declaration *value;
    HashtableElem *next;
  public:
    HashtableElem(string k, Declaration *e, HashtableElem *n);

    /*
     * Accessors to return the Key and Value for an Element.  Use
     * these in conjunctions with the Iterator above.
     */
    string Key(void);
    Declaration *Value(void);

    friend class Hashtable;
    friend class HashtableIterator;
};



#endif


