/*****************************************************************************

  declaration.h



 *****************************************************************************/

#ifndef _H_declaration
#define _H_declaration

#include "utility.h"

/*
 * pp1: pp2: Declarations are just little structures that allow us
 * to make sure your scanner is working correctly.  You should
 * not have to modify this interface until pp3.
 */
class Declaration {
  private:
    int firstLine;
    int numOccurrences;
    string name;
  public:
    /* Pass in the identifier's name and the line where it
       first occurs */
    Declaration(string name, int firstOccurrence);

    /* call this whenever the same identifier is seen */
    void IncrementOccurrences(void);

    /* we call this from the test main. */
    void Print(void);
};


#endif






