/*****************************************************************************
  INF01147 - Compiladores N
  Prof.: Jo�o Comba
  Author: Paulo S�rgio Morandi J�nior (PsMj)
  Num.: 2767/01-1
  http://www.inf.ufrgs.br/~sergio/trabalhos/trabalhos.html
   
  PsMj(TM) Corp. (R) 1981
  PsMj(TM) FreeSoftware (C) 2001-2004, ver. MAR2004
     
  hash.cpp
  
  It implements a hash table class filled with declarations that will be used for the
  soop compiler. 
  
  ****************************************************************************/

#include "hash.h"

/*Hash function of P. J. Weinberger, from :
* Compiladores: Princ�pios, T�cnicas e Ferramentas
* Aho, Senthi e Ulman
* LTC, 1995
* page: 188. Section: 7.6
*/
int HashTable::hashpjw ( string name )
{   
    char *p;
    unsigned h = 0, g;
    
    for ( p=name; *p != EOS; p++ )
    {
        h = (h<<4)+(*p);
        if ( g=h&0xf0000000)
        {
             h = h ^ ( g>>24 );
             h = h ^ g;
        }
    } 
    return h % PRIME;
}


HashTable::HashTable ()
{
    for(int i=0; i<PRIME; i++)
        table[i].key = "\0";
}

Declaration *HashTable::insert ( string name, int line )
{
    int k = hashpjw( name );
    
    if ( table[k].key == "\0" ) /*...then is empty...*/
    {/*..so just put it on...*/
        table[k].key = name;
        table[k].d = new Declaration(name,line);
        table[k].next = NULL;
        return table[k].d; /*...and return the declaration*/
    }
    else /*...well, we alredy have this declaration...*/
    {
        if ( StringEqual(table[k].key,name) ) /*..is what I'm looking for??..*/
        {
                table[k].d->IncrementOccurrences();  /*...yes! I found It..*/
                return table[k].d;
        }
        else /*...no, so, we have the same key with diferent ids...*/
        {       
                bool found = false;
                Node *p = table[k].next;
                Node *before = &table[k]; /*just to control who is before the next*/
                while ( (p != NULL) )
                {
                  if ( p != NULL )
                     if ( StringEqual(p->key,name) )
                     {
                        p->d->IncrementOccurrences(); /*...yes! I found It..*/
                        return p->d;
                     }
                  before = p;
                  p = p->next;
                }
                /*...so this must be another entry with the 
                  * same key but diferent ids...
                 */
                  Node *n = new Node;
                  n->key = name;
                  n->next = NULL;
                  n->d = new Declaration(name,line);
                  before->next = n; /*...it's always add at the end of list...*/ 
                  return n->d;                 
        }
    }
}    
