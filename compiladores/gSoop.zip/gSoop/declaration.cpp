/*****************************************************************************
  INF01147 - Compiladores N
  Prof.: Jo�o Comba
  Modified by <<Paulo S�rgio Morandi J�nior (PsMj)>>
  Num.: 2767/01-1
  http://www.inf.ufrgs.br/~sergio/trabalhos/trabalhos.html
   
  PsMj(TM) Corp. (R) 1981
  PsMj(TM) FreeSoftware (C) 2001-2004, ver. MAR2004
     
  declaration.cpp
  
  ****************************************************************************/


#include "declaration.h"


/*
 * pp1: This is the simple declaration class for pp1/pp2. 
 * Just fill in the blanks.
 */

Declaration::Declaration(string ident, int firstOccurrence) {
    name = ident;
    firstLine = firstOccurrence;
    numOccurrences = 1;
}

void Declaration::IncrementOccurrences(void) {
    numOccurrences++;
}

void Declaration::Print(void) {
printf("(%s seen %d %s, first on line %d )\n",
            name,numOccurrences,numOccurrences==1?"time":"times",firstLine);
}






