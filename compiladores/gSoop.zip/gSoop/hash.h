/*****************************************************************************
  INF01147 - Compiladores N
  Prof.: Jo�o Comba
  Author: Paulo S�rgio Morandi J�nior (PsMj)
  Num.: 2767/01-1
  http://www.inf.ufrgs.br/~sergio/trabalhos/trabalhos.html
   
  PsMj(TM) Corp. (R) 1981
  PsMj(TM) FreeSoftware (C) 2001-2004, ver. MAR2004
     
  hash.h
  
  It provides a hash table class filled with declarations that will be used for the
  soop compiler.
  
  ****************************************************************************/
#ifndef _HASH_H
#define _HASH_H

#include <stdio.h>
#include <stdlib.h>
#include "utility.h"
#include "declaration.h"

#define PRIME 211
#define EOS '\0'

typedef struct _Node {
    string key;
    Declaration *d;
    struct _Node *next;
}Node;

class HashTable {
    private:
        Node table[PRIME];        
        int hashpjw ( string name );

    public:
        HashTable (); /*Constructor... just initialize some things..*/
        /*Insert and Return the declaration created after the insertion..*/
        Declaration *insert ( string name, int occur ); 
        
};

#endif



