CONTENTS of gSoop.zip:

readme.txt 	- This file...
declaration.cpp - Modified
hash.*	 	- Implements the hash table class to store the Declarations
soop.l		- Modified

Author: PAULO SERGIO MORANDI JUNIOR
Mat: 2767/01-1

INF01147 - COMPILADORES 
Prof.: Jo�o Comba

