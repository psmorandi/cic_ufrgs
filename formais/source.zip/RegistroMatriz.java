/*
 * Created on 24/06/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author Marcelo
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

import java.util.*;

public class RegistroMatriz {
 
	public boolean ocupado;
	Vector listPares; // lista de pares na fila	
	
	RegistroMatriz ()   {
		listPares = new Vector ();
		ocupado=false;		
	}	
			
	public void  setToUsed  ()   {
		ocupado=true;
	}
	
	public String toString ()  {
		super.toString ();	
		if (ocupado)
			return ("YES");
		else return ("NOT");	
	}
	
	public void insertList (String s1, String s2)  {
		UmPar umPar = new UmPar (s1,s2);
		
		listPares.add (umPar);
	}	

	public String retornaUm (int index)  {
		UmPar volta = new UmPar();
				
		volta= (UmPar)listPares.get(index);
		
		return (volta.retornaUm());
		//(listPares.get (index)).retornaUm();
		//return ((String) ((listPares.get(index)).retornaUm()));
	}
	
	public String retornaOutro (int index)  {
		UmPar volta = new UmPar();
		volta= (UmPar)listPares.get(index);
		
		return (volta.retornaOutro());
		//(listPares.get (index)).retornaUm();
		//return ((String) ((listPares.get(index)).retornaUm()));
	}	
}	
