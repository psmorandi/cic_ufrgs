import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main extends JFrame implements ActionListener
{
	private static String programName = new String("Automata Minimum(R)");
	JDesktopPane desktop;
	GraphDraw graphDraw = null;
	GraphDraw graphMin = null;

	public Main()
	{
		super(programName);

		getContentPane().setLayout( new BorderLayout() );

		//Menu Arquivo, editar, view, ajuda...
		JMenuBar menu = new JMenuBar();
		
		//Menus Suspensos:
		JMenu file = MainWindowEvent.makeMenu(MainWindowEvent.criaMenu("File",KeyEvent.VK_F),
	new Object[] {
		MainWindowEvent.criaItem("New",KeyEvent.VK_N,KeyStroke.getKeyStroke('N',InputEvent.CTRL_MASK) ),
		MainWindowEvent.criaItem("Open",KeyEvent.VK_O,KeyStroke.getKeyStroke('O',InputEvent.CTRL_MASK) ),
		MainWindowEvent.criaItem("Save",KeyEvent.VK_S,KeyStroke.getKeyStroke('S',InputEvent.CTRL_MASK) ),
		null,
		MainWindowEvent.criaItem("Exit",KeyEvent.VK_X,KeyStroke.getKeyStroke('X',InputEvent.CTRL_MASK) ),
	}, this);
		
		JMenu minimiza = MainWindowEvent.makeMenu( MainWindowEvent.criaMenu("Edit Automaton",KeyEvent.VK_E),
						new Object[] {MainWindowEvent.criaItem("Minimize",KeyEvent.VK_M,KeyStroke.getKeyStroke('M',InputEvent.CTRL_MASK) ),
						}, this);
		
		menu.add(file);
		menu.add(minimiza);
				
		JToolBar editToolbar = new JToolBar();

		JButton o = new JButton( new ImageIcon("figura/open.gif") );
		JButton s = new JButton( new ImageIcon("figura/save.gif") );

	        s.setRequestFocusEnabled(false);
	        s.setMargin(new Insets(1,1,1,1));
		s.setToolTipText("Save the Automato");
		s.setActionCommand("Save");
		s.addActionListener(this);

	        o.setRequestFocusEnabled(false);
	        o.setMargin(new Insets(1,1,1,1));
		o.setToolTipText("Open an Automato File");
		o.setActionCommand("Open");
		o.addActionListener(this);

		editToolbar.add(Box.createHorizontalStrut(2));
		editToolbar.add(o);
		editToolbar.add(s);
		editToolbar.add(Box.createHorizontalGlue());

		setJMenuBar(menu);
		getContentPane().add(editToolbar, BorderLayout.NORTH);

		desktop = new JDesktopPane();
		getContentPane().add(desktop, BorderLayout.CENTER);

	}

	public JDesktopPane getDesktop()
	{
		return desktop;
	}

	public static void main ( String args[] )
	{
		Main frame = new Main();
		frame.addWindowListener(new MainWindowEvent());
		frame.setSize(800, 600);
		frame.show();

		//WelcomeNote.welcome(programName);

	}

	public void actionPerformed( ActionEvent e )
        {
                if (e.getSource() instanceof JMenuItem)
                {
			JMenuItem mi = (JMenuItem) e.getSource();

			//Preparando as Opcoes:
			JPanel frame = new JPanel();

			if (mi.getText().equals("Exit"))
			{
				System.exit(0);
			}
			if (mi.getText().equals("New"))
			{
				if (graphDraw != null)
				{
					graphDraw.setVisible(false);
					getDesktop().remove(graphDraw);
				}
				graphDraw = new GraphDraw();
				getDesktop().add(graphDraw);
				graphDraw.setVisible(true);
			}

			if (mi.getText().equals("Index"))
			{HelpWindow hw = new HelpWindow(Main.programName);}

			if (mi.getText().equals("Open") )
				openSaveAction(mi.getText());

			if ( mi.getText().equals("Save") )
				openSaveAction(mi.getText());
			if ( mi.getText().equals("..") )
				if (graphDraw != null)
				{
					Automato a;
					a = graphDraw.getAutomaton();
				}
			if (mi.getText().equals("Minimize"))
			{ 
				if (graphDraw != null)
				{
					Automato a;
					a = graphDraw.getAutomaton();
					a.processaAutomato();
					graphMin = new GraphDraw();
					getDesktop().add(graphMin);	
					graphMin.toFront();
					graphMin.setVisible(true);
					graphMin.drawAutomaton(a);
					graphMin.setTitle("Automaton Minimum");
				}
				else 
					JOptionPane.showMessageDialog(null,"Error. You haven't open or edited a automaton yet!","ERROR IN MINIMIZATION",
								JOptionPane.ERROR_MESSAGE); 
			}

		}//if of event
		else
			if( e.getSource() instanceof JButton )
			{
				JButton b = (JButton)e.getSource();
				String source = b.getActionCommand();
				if( source.equals("Open") )
				{
					openSaveAction(source);
				}
				else if ( source.equals("Save") )
				{
					openSaveAction(source);
				}
			}
	}//actionPerformed


	public void openSaveAction( String what )
	{
		JPanel frame = new JPanel();

		//Abrir ou Salvar Arquivo:
		JFileChooser chooser = new JFileChooser();
		AutomatoFileFilter autFilter = new AutomatoFileFilter("aut", "AUT Automato Files");

		chooser.setApproveButtonText(what);
		chooser.addChoosableFileFilter(autFilter);
		chooser.setSelectedFile(null);
		autFilter.setExtensionListInDescription(true);

		frame.add("Center", chooser);

		if ( what.equals("Open") )
		{
			chooser.setDialogType(JFileChooser.OPEN_DIALOG);

			int retval = chooser.showDialog(frame, null);
			if (retval == JFileChooser.APPROVE_OPTION)
			{
				File theFile = chooser.getSelectedFile();
				if (theFile != null)
					openFile(theFile.getPath());
			}
			else
				if (retval == JFileChooser.ERROR_OPTION)
					JOptionPane.showMessageDialog(frame, "An error occured. No file was OPEN.");
		}
		else
		{
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);

			int retval = chooser.showDialog(frame, null);
			if (retval == JFileChooser.APPROVE_OPTION)
			{
				File theFile = chooser.getSelectedFile();
				if (theFile != null)
					saveFile(theFile.getPath());
			}
			else
				if (retval == JFileChooser.ERROR_OPTION)
					JOptionPane.showMessageDialog(frame, "An error occured. No file was SAVE.");
		}
	}

	public void openFile( String fileName )
	{
		try
		{
			BufferedReader file = new BufferedReader( new FileReader(fileName));
			try
			{
				Automato aut = Automato.leAutomato(file);
				//the next two lines is for debug
				if (aut != null) 
				{
					if (graphDraw != null)
						getDesktop().remove(graphDraw);
					graphDraw = new GraphDraw();
					getDesktop().add(graphDraw);
					graphDraw.setVisible(true);
					graphDraw.show();
					
					Graphics g = getDesktop().getGraphics();
					graphDraw.drawAutomaton(aut);
				}
			}
			catch(AutomatoException e)
			{
				JOptionPane.showMessageDialog(null,e.getMessage(),"Invalid Automatum",
					JOptionPane.ERROR_MESSAGE);
			}
			//MANIPULAR AUTOMATO
		}
		catch(IOException excp)
		{
			System.out.println("IO ERROR or File not Found");
			excp.printStackTrace();
		}
	}//openFile

	public void saveFile( String fileName )
	{
		try
		{
			BufferedWriter file = new BufferedWriter( new FileWriter(fileName));
			Automato a;
		
			GraphDraw graph = (GraphDraw)getDesktop().getSelectedFrame();

			//SALVAR AUTOMATO....
			if (graph != null)
			{
				a = graph.getAutomaton();
				a.storeAutomaton(file);
			}
			
		}
		catch(IOException excp)
		{
			System.out.println("IO ERROR");
			excp.printStackTrace();
		}


	}//saveFile

	
}
