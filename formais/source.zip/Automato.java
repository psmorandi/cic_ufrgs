import java.util.*;
import java.io.*;
import javax.swing.*;
/**
 

*/
public class Automato
{
	private Hashtable alfabeto;
	private Hashtable estados;
	private Vector estadosFinais;
	private Vector transicoes;
	private int numSyms, numStates;
	    
	//  <marcelo�s Code>
    
	private Vector todosEstados;
	private RegistroMatriz matriz[][];
	
	private Vector todosEstadosMinimizado;
	private Vector estadosFinaisMinimizado;
	private Vector transicoesMinimizado; 
	private Vector estadosEquivalentes;	
	private boolean vaiProResultado [];
		
	//  </marcelo�s Code>

	public Automato()
	{
		alfabeto = new Hashtable();
		estados = new Hashtable();
		estadosFinais = new Vector();
		transicoes = new Vector();
		numSyms = 0;
		numStates = 0;

		//  <marcelo�s Code>
		todosEstados= new Vector ();
		// </marcelo�s Code>

	}

	public void addSymbol(String s)
	{
		s = s.trim();
		if (!alfabeto.containsKey(s))
		alfabeto.put(s, new Integer(numSyms++));
	}

	// ok.. those get??? will be `slow', but then... they'll 
	// not be used THIS much ^^
	// and also, this IS java anyway!
	public String getStateName(int ind)
	{
		Enumeration en = estados.keys();
		while (en.hasMoreElements())
		{
				String es = (String)en.nextElement();
				if (getStateIndex(es) == ind)
					return es;
		}
		return null;
	}
	
	public String getSymbol(int ind)
	{
		int i;	
		Enumeration en = alfabeto.keys();
		while (en.hasMoreElements())
		{
				String es = (String)en.nextElement();
				if (getSymbolIndex(es) == ind)
					return es;
		}
		return null;
	}
	
	public int addState(String s)
	{	
		s = s.trim();
		if (s.charAt(0) == '*')
		{// state `s' is a final state
			s = s.substring(1,s.length());
			if (!estadosFinais.contains(s))
				estadosFinais.add(s);
		}

		if (estados.containsKey(s))
		{ /* state `s' is already in the list of known states */
			Integer i = (Integer)estados.get(s);
			return i.intValue();
		}
		else
		{
			// <marcelo�s Code>
			Integer nn= new Integer (0);
			// </marcelo�s Code>
			
			estados.put(s, new Integer(numStates));
			transicoes.add(new Vector());
			
			// <marcelo�s Code>
			nn=(Integer)estados.get (s);
			todosEstados.add(nn.intValue(),s);
			// </marcelo�s Code>

			return numStates++;
		}
	}

	public int getSymbolIndex(String s)
	{
		s = s.trim();
		if (alfabeto.containsKey(s))
		{
			Integer i = (Integer)alfabeto.get(s);
			return i.intValue();
		}
		else
			return -1;
	}
	
	public int getStateIndex(String s)
	{
		s = s.trim();
		if (estados.containsKey(s))
		{
			Integer i = (Integer)estados.get(s);
			return i.intValue();
		}
		else
			return -1;
	}

	public void addTransition(String sr, String ds, int symI)
	{
		int srI, dsI;

		srI = addState(sr);
		dsI = addState(ds);
		
		while (srI >= transicoes.size())
			transicoes.add(new Vector());
		
		Vector src = (Vector)transicoes.elementAt(srI);
		
		while (symI >= src.size())
			src.add(new Integer(-1));

		src.setElementAt(new Integer(dsI), symI);
	}

	public void addTransition(String sr, String ds, String sym)
	{
		int symI;

		symI = getSymbolIndex(sym);
		if (symI == -1)
                {
                        symI = alfabeto.size();
                        addSymbol(sym);
                }
		addTransition(sr, ds, symI);
	}

	public int applyTransition(int st, int sym)
	{ // -1 means undefined transition
		if (st >= transicoes.size())
			return -1;
		
		Vector v = (Vector)transicoes.elementAt(st);
		
		if (sym >= v.size())
			return -1;

		Integer i = (Integer)v.elementAt(sym);
		return i.intValue();
	}
	
	// this four is useful at GraphDraw...
	// It seens a little "redundante" but....
	// - Paulo, 05/07
	//
	// gives num of symbols plus 1
	public int getNumSyms()
	{
		return numSyms;
	}
	//gives num of states plus 1
	public int getNumStates()
	{
		return numStates;
	}
	//guess....
	public Vector getTransitions()
	{
		return transicoes;
	}
	
	//Return's a Vector of OBJECT 
	public Vector getStates()
	{
		Collection temp = estados.keySet();
		Vector est = new Vector(temp);
		return est;
	}
	public Vector getFinalStates()
	{
		return estadosFinais;
	}

	public static Automato leAutomato( BufferedReader arq ) throws AutomatoException
	{
		StringTokenizer estadotok, alfatok;
		String line,estadoProximo, estadoAtual;
		Automato at = new Automato();

		line = null;	
		do 
		{
			try
			{
				line = arq.readLine();
			} 
			catch (IOException e )
			{
				
				JOptionPane.showMessageDialog(null,"Erro: "+e.getMessage(),"ERROR UNDER READING",
					JOptionPane.ERROR_MESSAGE);
			}
			
			if ( line == null )
				throw new AutomatoException("unknow");

		} while (line.trim().equals(""));

		alfatok = new StringTokenizer(line,";");
		
		int j = -1;
		
		while( alfatok.hasMoreTokens() )
		{
			String tok = alfatok.nextToken();
			tok = tok.trim();
			if (tok.equals("#"))
				throw new AutomatoException("FNE");
			if (!tok.equals("|") && !tok.equals(""))
				at.addSymbol(tok);
		}

		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: "+e.getMessage(),"ERROR UNDER READING",
					JOptionPane.ERROR_MESSAGE);
		}
		
		estadoAtual = "";
		while ( line != null )
		{
			estadotok = new StringTokenizer(line,";");
			
			while (estadotok.hasMoreTokens() )
			{
				String estado = estadotok.nextToken();
				estado = estado.trim();
				
				//Elimina as '{'
				if ( estado.charAt(0) == '{')
				{
						estado = estado.substring(1,estado.length()-1);
				}
					
				//Verifica se � deterministico
				if ( !at.deterministico(estado) )
				{
					throw new AutomatoException("not Deterministic");
				}
				else if (estado.equals("|"))
					{
						j = -1;
					}
					else if (j == -1)
					{
						estadoAtual = estado;
						j = 0;
					}
					else 
					{
						if (estado.equals("-"))
						{
							for(int i=0;i<at.getNumSyms();i++)
							{
								at.addTransition(estado,estado,i);
							}
						}
						at.addTransition(estadoAtual, 
								estado, j);
						j++;
					}
			}

			try
			{
				line = arq.readLine();
			}
 			catch (IOException e )
			{
				JOptionPane.showMessageDialog(null,"Erro: "+e.getMessage(),"ERROR UNDER READING",
					JOptionPane.ERROR_MESSAGE);			
			}
		}
		for (int i = 0; i<at.getTransitions().size(); i++)
		{
			Vector trans = (Vector)at.getTransitions().elementAt(i);
			if (trans.size() == 0) 
			{
				for (j = 0; j<at.getNumSyms(); j++)
				{
					String estado = at.getStateName(i);
					at.addTransition(estado,new String("-"),j);
				}				
			
			}
		}
		return at;
	}

	public void print()
	{
		int i;
		System.out.println(alfabeto);
		System.out.println(estados);

		for (i=0;i<estados.size();i++)
		{
			Vector v = (Vector)transicoes.elementAt(i);
			System.out.println(v);
		}
				
	}
	
	//Verifica se eh deterministico...se a ',' for encontrada,
	//significa q possue mais de um estado
	public boolean deterministico( String estado )
	{
		if ( estado.indexOf(",") == -1 )
			return true;
		else return false;
	}
	
	
	public void automatoTotal()
	{
		Vector trans = (Vector)getTransitions();
		
		for (int i = 0; i < getNumStates(); i++)
		{
			Vector t = (Vector)trans.elementAt(i);
			for (int j=0; j < t.size(); j++)
			{
				Integer x = (Integer)t.elementAt(j);
				if (x.intValue() == -1) 
				{
					x = new Integer( addState("-") );
					t.set(j,x);
				}
			}
			for (int j=t.size(); j<getNumSyms(); j++)
			{
				t.add(j,new Integer( addState("-") ));
			}
		}
	}
	
	
	/*
	 * *********************************************************
	 *                Marcelo�s Code!!! 
	 * Caro cidad�o que algum dia venha a querer ler esse c�digo...
	 * por favor, n�o o fa�a... est� horr�vel! 
	 * 			Obrigado pela colabora��o!!!
	 * Mas, mesmo assim, se tu te arriscares, essa parte do c�digo serve
	 * pra minimizar o automato!
	 *
	 ***********************************************************
	 */
	 
	
	/**
	 *   Processamento do Aut�mato, minimiza��o do aut�mato propriamente dita.
	 *   
	 *   Utiliza-se uma matriz bidimensional de objetos da classe RegistroMatriz.
	 *   Objetos dessa classe cont�m um campo informando se essa posi��o (dupla de estados)
	 *   est� marcada (indicando que n�o s�o equivalentes) e uma refer�ncia para um vector
	 *   que indica os elementos que est�o na 'lista de espera' para serem marcados corres-
	 *   pondentes a essa posicao.
	 * 
	 *    A matriz ser� sim�trica. Poder-se-ia utilizar somente a metade dela 
	 *    sem a diagonal, mas n�o fiz isso por vagabundagem.
	 * 
	 */
	
	public void processaAutomato ()   {
		
	  	automatoTotal();


		
		/*
		 * ELIMNAR ESTADOS INACESSIVEIS
		 */
		 
	  
	  	boolean verificado[] = new boolean[estados.size()];
	  	boolean acessivel[]  = new boolean[estados.size()];
	  	Vector verificaTransicao = new Vector();
	  	Integer indiceDoEstado = new Integer(0);
	  	int indiceDoEstadoInt;
	  	
	  	
	  	//inicializa��o
	  	for (int i=0;i<estados.size();i++)  {
	  		verificado[i]=false;
	  		acessivel[i]=false;
	  	}
	  	acessivel[0]=true; // estado inicial sempre eh acessivel
	  	
	  	// marca quais estados s�o inacess�veis
		 for (int i=0;i<estados.size();i++)   {		 		
		    for (int j=0;j<estados.size();j++)   {
		    	if ((verificado[j]==false)&&(acessivel[j]))   {
		    		verificado[j]=true;
					verificaTransicao =(Vector) transicoes.get(j);
					for (int k=0;k<alfabeto.size();k++)   {
						
						indiceDoEstado=(Integer) (verificaTransicao.get(k)); // vai pro estado k 
						indiceDoEstadoInt=indiceDoEstado.intValue();
						acessivel[indiceDoEstadoInt]=true;					
					}				
		    	}	  			   	
		   }
		 }
		
		/*
		 * vari�veis auxiliares que indicam 
		 *  	estado sem estados inacessiveis
		 * 		transicoes sem as transicoes dos estados inacessiveis
		 * 		estados finasi sem esatdos inacessvies
		 * 		todosEstados sem estados inacesseis  (SI - Sem Inacessivel)
		 */
		
		 
		Hashtable alfabetoSI = new Hashtable();
		Hashtable estadosSI = new Hashtable();
		Vector todosEstadosSI = new Vector();
		Vector estadosFinaisSI = new Vector();
		Vector transicoesSI =new Vector();
		int numEstadosSI=0;
		Vector temp;
		Vector tempTransicoesSI;
		Integer auxInteger= new Integer(0);
		int auxInt;
		String auxStr;
		int acessiveis=0;

		
		for (int i=0;i<estados.size();i++) {
			if (acessivel[i]) transicoesSI.add (new Vector());
		}
		 
		// insere na lista de estados (sem estados inacess�veis) os esatdos que s�o acess�veis!
		// j� marca quais acess�veis s�o finais
		for (int i=0;i<estados.size();i++)   { // pra todos estados
			if (acessivel[i])   { // se ele eh acessivel
				estadosSI.put((String)todosEstados.get(i),new Integer (numEstadosSI++));
				todosEstadosSI.add((String)todosEstados.get(i));
				if (estadosFinais.contains((String)todosEstados.get(i)))
					estadosFinaisSI.add ((String) todosEstados.get(i));				
			}	
		}		

		// pra todos os estados e todo o alfabeto, v� pra que estado transiciona o esquema de estados
		// com estados equivalentes e insere essa transi��o no esquema sem estados equivalentes.		
		for (int i=0;i<estados.size();i++)   { // pra todos estados
			if (acessivel[i])   { // se ele eh acessivel
				
				temp = (Vector) transicoes.get(i);
				tempTransicoesSI = (Vector) transicoesSI.get(acessiveis++);
				
				for (int j=0;j<temp.size();j++)   {
					auxInteger=(Integer) temp.get(j);
					auxInt=auxInteger.intValue();
					auxStr=(String) todosEstados.get(auxInt);
					
					// pra onde vai no novo esquema de estados
					auxInteger= (Integer) estadosSI.get(auxStr); // no novo esquema vai pra auxInteger					
					auxInt=auxInteger.intValue(); 					
					
					tempTransicoesSI.add(j,new Integer(auxInt));			
				}	
			}	
		}
		
		 
		 // a referencia ao automato com estados inacessiveis agora aponta pro automato sem estados
		 // inacessiveis
		 
	 	estados=estadosSI;
		todosEstados=todosEstadosSI;
		transicoes=transicoesSI;
		estadosFinais=estadosFinaisSI;

		// come�a a segunda parte da minimiza��o... montar uma tabela com todas as duplas de estados.
		// no final, estados n�o ocupados (marcados) s�o equivalentes.
		
		// aloca a matriz que indicar� estados equivalenetes.		
		matriz = new RegistroMatriz[estados.size()][estados.size()];		
		
		for (int i=0;i<estados.size();i++) 
		   for (int j=0;j<estados.size();j++)		   
		   			matriz[i][j]= new RegistroMatriz();		
		

		/**
		 *  Marca pares de estados do tipo final-n�oFinal na matriz de pares
		 *  A diagonal dessa matriz n�o ser� utilizada, porque um estado n�o pode
		 *  ser e n�o ser estado final ao mesmo tempo. 
		 * 
		 *  Para cada estado, se ele � final, ent�o ele � comparado com todos os outros
		 *  estados.  Se esse outro estado for n�o final, ent�o essa posicao da matriz
		 *  � marcada como ocupada.
		 */
		
		
		// se dupla de estados for do tipo final-n�o final, ent�o eh marcado
		for (int i=0;i<estados.size();i++)   {
			// se estado eh final, marca com todos que nao sao
			for (int k=0;k<estados.size();k++)   {			
				//matriz[i][k]= new RegistroMatriz();
							
				if (estadosFinais.contains((String)todosEstados.get(i)))   {
					// marca com quem nao eh
		
					if (!estadosFinais.contains((String)todosEstados.get(k)))  { //tirei i!=k						
						
						// vai ser sim�trico
						matriz[i][k].setToUsed();	
						matriz[k][i].setToUsed();					
					}
				}
			}			
		} // end of final-nonFinalState
		
		
		
		/**
		 *   Aqui verifica-se se duplas de pares n�o marcados s�o equivalentes ou n�o.
		 *   Para cada par n�o marcado, verifica-se o novo estado que o aut�mato 
		 *   transicionaria caso lesse um determinado s�mbolo do alfabeto.  Faz-se essa 
		 *   verifica��o para todos os s�mbolos do alfabeto.  
		 *   Como cada posi��o da matriz � um par de estados, deve-se fazer a verifica��o
		 *   para esses dois pares.  Logo, obtem-se um par de estados para onde o aut�mato
		 *   transicionaria.  Se esse par lido estiver marcado, ent�o marca-se o par de
		 *   estados (posi��o da tabela) e todos os elementos que est�o na lista dessa 
		 *   posi��o (lembre-se que h� um apontador para um vector que indica os elementos
		 *   que est�o na fila).
		 *   Se o par lido n�o estiver marcado, na 'lista de espera' desse par lido, marca-se
		 *   a posi��o da tabela que estava sendo analisada.  
		 *   E o processo continua para todos os outros estados n�o marcados da tabela.
		 * 
		 *   No final, as posi��es n�o marcadas s�o estados equivalentes.
		 *   
		 *   Como a matriz � sim�trica, todas as opera��es na matriz sobre a matriz
		 *   devem ser sim�tricas. 
		 *      
		 */
		

		/*
		 * mais umas variaveizinhas...
		 */

		Vector n; 	// refer�ncia auxiliar pq eu n�o consegui botar direto.
		int ww, xx;		
		Integer w = new Integer(0);
		Integer x = new Integer(0);
		
		for (int i=0;i<estados.size();i++)   {
			for (int j=0;j<estados.size();j++)   {
				if ((!matriz[i][j].ocupado) && (i!=j))   {
					// para todos os simbolos do alfabeto, ver pra onde levam
					// esses dois estados
					for (int k=0;k<(alfabeto.size());k++)   {  


						// n eh o vetor de transicoes do estado i
						n=(Vector)transicoes.get (i);
						// w  eh a estado alcancado pelo estado i lendo o k-esimo simbolo
						w=(Integer)(n.get (k));

						// n eh o vetor de transicoes do estado j
						n=(Vector)transicoes.get (j);			
						// x eh o estado alcancado pelo estado j lendo o k-esimo simbolo			
						x=(Integer)(n.get (k));
						
						xx=x.intValue();  // mesmo que x, mas xx eh tipo primitivo inteiro e x eh classe
						ww=w.intValue();  //  mesmo que w, mas w eh tipo primitivo inteiro e w eh classe
						
						if (!matriz[ww][xx].ocupado)   { 							 
							 // se o a dupla de estados obtidos lendo com i,j lendo o k-esimo simbolo
							 // n�o t� ocupado,en~tao coloca i,j na lista do estado que foi obtido
							 // a partir dessa transicao 							 	 
							matriz[ww][xx].insertList((String)todosEstados.get(i),(String)todosEstados.get(j));
							matriz[xx][ww].insertList((String)todosEstados.get(i),(String)todosEstados.get(j));
						}
						else {  // t� marcado, marca ij e todos que tao na lista dele
							matriz[i][j].setToUsed();
							matriz[j][i].setToUsed();

							
							Integer inti = new Integer (0);
							Integer intj = new Integer (0);
							int intinum, intjnum;
							String um;
							String outro;
							
							for (int all=0;all<(matriz[i][j].listPares.size());all++) {
								um=matriz[i][j].retornaUm(all);  // string do estados
								outro=matriz[i][j].retornaOutro(all);
								
								inti=(Integer)estados.get(um);
								intj=(Integer)estados.get(outro);
								
								intinum=inti.intValue();
								intjnum=intj.intValue();
								
								matriz[intinum][intjnum].ocupado=true;
								matriz[intjnum][intinum].ocupado=true;			
																								
							}
						}				
					}														   
				}			
			}
		}
		

		
		// os n�o marcados s�o equivalentes

		// declaracao de variable		
			String estadoComposto="";	
 
		estadosEquivalentes = new Vector ();
		vaiProResultado = new boolean [estados.size()];
		Integer classeInteiroAuxiliar = new Integer (0);
		int inteiroAuxiliar;
		String str; 
		
		//	cada estado aponta pros seus equivalentes.
		for (int i=0;i<estados.size();i++) estadosEquivalentes.add (new Vector());


		// inicializacao
		for (int i=0;i<estados.size();i++) 
			vaiProResultado[i]=true;		 
		
		
		for (int i=0;i<estados.size();i++)   {

			for (int j=0;j<estados.size();j++)   {
				if (i>j)  {
					if (!matriz[i][j].ocupado)   { 
									// se n�o t� marcado "i" eh equivalente a "j"
									// insere j na lista do i e i na lista do j
									
						str = (String)todosEstados.get(i);// string do estado i
						temp =(Vector) estadosEquivalentes.get(j); //						
						temp.add(str);
						
						
						classeInteiroAuxiliar=(Integer) estados.get(str);
						inteiroAuxiliar= classeInteiroAuxiliar.intValue();
						// inteiroAuxiliar representa i, que ser� dado como n�o pertencente a resposta,
						// uma vez que ser� representado por estado q[j]q[i].
						vaiProResultado[inteiroAuxiliar]=false;			
					}
				}
			}			
		}
		

		/*
		 * essas variaveis vao conter o automato minimizado
		 */
		 
		todosEstadosMinimizado = new Vector ();
		estadosFinaisMinimizado= new Vector ();
		
		String primeiroElementoDoEstadoComposto;

		// concatena string de estados compostos!!! Indica quais sao finais				
		for (int i=0;i<estados.size();i++)   {
			
			str=(String)todosEstados.get(i);
			classeInteiroAuxiliar=(Integer) estados.get(str);
			inteiroAuxiliar= classeInteiroAuxiliar.intValue();
			
			if (vaiProResultado[inteiroAuxiliar])  {
				temp = (Vector) estadosEquivalentes.get (i);
				estadoComposto=(String) todosEstados.get(i);  // come�a com o string de i
				
				primeiroElementoDoEstadoComposto=estadoComposto;
		
				
				for (int j=0;j<temp.size();j++)  {
					estadoComposto+= (String)temp.get(j);				
				}
					todosEstadosMinimizado.add (estadoComposto);
					
				// se um dos compostos eh final, entao o composto eh final				
				for (int m=0;m<estadosFinais.size();m++)   {
					if (primeiroElementoDoEstadoComposto.equals((String)estadosFinais.get(m)))  {
						// esse estado eh final						
						estadosFinaisMinimizado.add(estadoComposto);				
					}
				}
			}		
		}

		 /*
		  *  VARIAVEIS DO PROXIMO TRECHO DE CODIGO 
		  */
		  
		 Vector transicoesDeUmEstado;		 
		 int vaiParaEstado;
		 String vaiParaEstadoStr;
		 String estadoQueEsta;
		 Vector temp2;
		 Vector transicaoDeUmEstado;
		 Integer inteiro;
		 String duh;
		 Vector temp3;
		 		 		 

		 transicoesMinimizado= new Vector();
		 
		/*
		 *  TRANSICOES no automato minimizado 
		 */		 
		 	 
		 	 
		 for (int i=0;i<estados.size();i++)  { // para todos os estados resultantes
		 			 	
			transicaoDeUmEstado= new Vector();   // 9$*$()%*()$#*%*#(%$)&&�(&)%(*#()$*#()$*#()@$&#$
					 	
			str=(String)todosEstados.get(i);
			classeInteiroAuxiliar=(Integer) estados.get(str);
			inteiroAuxiliar= classeInteiroAuxiliar.intValue();
			
			temp=(Vector) estadosEquivalentes.get(i);
			estadoQueEsta=(String) todosEstados.get(i);
			
			for (int k=0;k<temp.size();k++)  {
				estadoQueEsta+= (String)temp.get(k);				
			}  	// estado (talvez) composto que est� sendo analizado!									
			
		 			
		if (vaiProResultado[inteiroAuxiliar])  {
				// se esse estado faz parte da resposta,

		 	
		 	// temp tem as transicoes do estado i
			temp=(Vector)transicoes.get (i);  // transicoes do estado i
			
		 	for (int j=0;j<alfabeto.size();j++)  {		 	
		 		/*	
					v� qual o estado i vai lendo o simbolo j.
				 	esse estado estar� armazenado em vaiParaEstadoStr
				 	verifica se esse estado foi ou n�o simplificado(juntado) 
				 */
				
				classeInteiroAuxiliar=(Integer)(temp.get (j)); //estado lido lendo simbolo j		
				vaiParaEstado=classeInteiroAuxiliar.intValue();
				
				vaiParaEstadoStr=(String) todosEstados.get(vaiParaEstado); // string do estado q vai
				
				duh=vaiParaEstadoStr;
				
				// ver se esse s�mbolo n�o foi compactado (juntado)				
				temp2= (Vector) estadosEquivalentes.get(vaiParaEstado);	 // lista de estados equivalentes
				
				if (temp2.size()==0)  {
					// ainda pode ser que seja composto!!! Verifica.				
					
					boolean foiSimplificado=true;
								
					for (int m=0;m<todosEstadosMinimizado.size();m++)  {
						if ((String)todosEstadosMinimizado.get(m)==duh)   {
							// eh um estado sozinho n�o composto mesmo
							foiSimplificado=false;					
						}
					}
					boolean meuFlag=false;
					
					if (foiSimplificado)   {
						// sim, foi simplificado
						// achar o outro cara que t� com ele
						for (int m=0;m<estadosEquivalentes.size();m++)   
						{
							temp3=(Vector)estadosEquivalentes.get(m);
							for (int k=0;k<temp3.size();k++)   
							{
								if ((String) temp3.get(k) == duh) 
								{
									// esse cara eh equivalente a duh!!!
									vaiParaEstadoStr=(String) todosEstados.get(m);
//									System.out.println ("\nPassaAqui\n");
									meuFlag=true;
									break;									
								}
							
							}
							if (meuFlag) break;
							
								
						}
																		
						classeInteiroAuxiliar=(Integer) estados.get(vaiParaEstadoStr); 
						vaiParaEstado=classeInteiroAuxiliar.intValue();
						temp2 = (Vector) estadosEquivalentes.get(vaiParaEstado);
						for (int k=0;k<temp2.size();k++)  {
								vaiParaEstadoStr+= (String)temp2.get(k);				
						}																		
					} 
				}
				else  {
					// estado foi simplificado					
					//vaiParaEstadoStr=(String) todosEstados.get();  // come�a com o string de i

					Integer x1=(Integer)estados.get(duh);
					Integer x2=(Integer)estados.get((String)temp2.get(0));
					int xxx=x1.intValue();
					int yyy=x2.intValue();				
					for (int k=0;k<temp2.size();k++)  {
						if (xxx<yyy)
							vaiParaEstadoStr+= (String)temp2.get(k);				
					}					 
				}	

				// adiciona transicao				
				inteiro = new Integer (todosEstadosMinimizado.indexOf(vaiParaEstadoStr));
				transicaoDeUmEstado.add(inteiro);
 													  
		 	} // for indice j
			transicoesMinimizado.add(transicaoDeUmEstado);
		} // do if		
	} 	// do for indice i
	
	estados = new Hashtable();
	for (int i = 0; i<todosEstadosMinimizado.size(); i++)
	{
			estados.put(todosEstadosMinimizado.elementAt(i),new Integer(i));
			
	}
	
	numStates = estados.size();
	
	transicoes = transicoesMinimizado;
	estadosFinais = estadosFinaisMinimizado;
		
	} // processaAutomato	
	


	// 
	//Store the given Automaton in the givem file
	//  	Paulo, 11/07
	//  	
	public void storeAutomaton( BufferedWriter file )
	{
		String alfa =  "	";
		boolean ehFinal = false;
		Vector finais = getFinalStates();
		Vector trans = (Vector)getTransitions();
		
		for(int i=0; i<getNumSyms(); i++)
		{
			alfa += ";"+getSymbol(i)+"	";
		}
		alfa +=";|\n";
		try {
			file.write(alfa);
				
			for(int i=0; i < getNumStates(); i++)
			{
				String estadoTemp = getStateName(i);
				
				//seek for final state
				if (finais.contains(estadoTemp))
					alfa = "*"+estadoTemp;
				else
					alfa = estadoTemp;
				alfa += "	";
				Vector tr = (Vector)trans.elementAt(i);
				for(int j=0; j < tr.size(); j++)
				{
					Integer x = (Integer)tr.elementAt(j);
					if (x.intValue() == -1) 
						alfa += "; -	";
					else
						alfa += ";{"+getStateName(x.intValue())+"}	";
				}
				
				for (int j = tr.size();j < getNumSyms(); j++)
					alfa += "; -	";
					
				alfa += ";|\n";
				file.write(alfa);
			}
			file.close();
		}
		catch( IOException e )
		{
			System.out.println("IO ERROR");
			e.printStackTrace();						
		}
	}
}