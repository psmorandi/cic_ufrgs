public class AutomatoException extends Exception
{
		public AutomatoException( String excp )
		{
			super("Error!! This automatum is "+excp);
		}
}