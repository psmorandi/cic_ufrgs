import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GraphDraw extends JInternalFrame 
{
	MoveArea ma = new MoveArea();
		
	public GraphDraw()
	{
		super("Graph Drawing",true,true,true,true);
		JToolBar t = new JToolBar("Drawing Tools", 
				JToolBar.VERTICAL);
		ButtonGroup bg = new ButtonGroup();
		
		ImageIcon i = new ImageIcon("figura/normal.gif");
		JToggleButton b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("");
		b.setActionCommand("defaultAction");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);
		
		t.addSeparator();

		i = new ImageIcon("figura/novoEstado.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Add new State");
		b.setActionCommand("addState");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);

		i = new ImageIcon("figura/setaInici.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Toggle Initial State");
		b.setActionCommand("toggleInit");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);
		
		i = new ImageIcon("figura/setaFinal.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Toggle Final State");
		b.setActionCommand("toggleFinal");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);

		t.addSeparator();
		
		i = new ImageIcon("figura/novaTransRet.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Add new multi-segment Transition");
		b.setActionCommand("addTransRet");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);

		i = new ImageIcon("figura/novaTrans.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Add new straight Transition");
		b.setActionCommand("addTrans");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);

		t.addSeparator();

		i = new ImageIcon("figura/exclEstado.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Deletes a state (and all related transitions)");
		b.setActionCommand("delState");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);
		
		i = new ImageIcon("figura/exclTrans.gif");
		b = new JToggleButton("", i);
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setToolTipText("Deletes a transition");
		b.setActionCommand("delTrans");
		b.addActionListener(ma.listener());
		bg.add(b);
		t.add(b);

		setSize(640, 480);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(t, BorderLayout.WEST);
		getContentPane().add(ma, BorderLayout.CENTER);
		setVisible(true);
	}

	public Automato getAutomaton()
	{
		Automato a = ma.getAutomaton();
		return a;
	}
	
	public void drawAutomaton(Automato a)
	{
		ma.drawAutomaton(a);
		ma.repaint();
	}
}
