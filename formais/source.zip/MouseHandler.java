import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;

// Ok, the MouseHandler class was getting WAY too big to be in the same
// file as the MoveArea (yet to be renamed...), so I've put it in it's own 
// .java now...
// btw... I forgot when I did this ^^U

class MouseHandler implements MouseListener, MouseMotionListener, 
		ActionListener
{

	// stores wich operation is to be performed when responding to mouse
	// actions... I still need to implement some constants ^_^" 
	private int acaoClick = 0;
		
	// tempX, tempY - position, relative to state's upper-left corner
	// where user has pressed mouse button
	// CHANGED! (Mairo, 22/06) 
	//   Now they act like the old xDst and yDst.. they're quite 
	// redundant anyway =^_^=
	private double tempX, tempY;
	
	// indicates if the user is moving a state
	// I might consider using it for other purposes too.. it's only
	// meaningful if the operation is `create state'
	private boolean moving;

	
	private boolean movingTr;
	
	// state the user is moving (null if none)
	// CHANGED! (Mairo, 22/06)
	//   Now, it also does the honors of `origem' - 
	// transition's starting point... again, it was only meaningful 
	// when moving a state  and this means, when in `create state' mode
	private Estado tempSt = null;


	private Transicao tempTrans = null;

	// origin of transition, if creating one
	// REMOVED! (Mairo, 22/06) -- see above
	// private Estado origem = null;
	
	// current position of mouse, when creating transition
	// REMOVED! (Mairo, 22/06) -- see tempX, tempY
	// private double xDst, yDst;

	// when creating transitions, this holds the direction we're
	// currently allowed to follow, either horizontal or vertical
	private int direction = 0;      //1 = horizontal, 2 = vertical

	// is used to decide the above... 
	private double refX, refY;
	
	// points dividing the transition - EXCLUDING the endpoints
	// used when creating multi-segment transitions
	private Vector midpoints;
		
	// true if drawing a new transition
	private boolean criaTrans;
	
	// cursors, indicating various things 
	private Cursor handCursor = null;
	private Cursor defaultCursor = null;
	private Cursor crossCursor = null;

	// the currently selected cursor, just for a bit of performance -_^ 
	private Cursor currentCursor = null;

	// added because of the `emancipation' of this class...
	MoveArea mvArea = null;

	public MouseHandler(MoveArea ma)
	{
		mvArea = ma;
		defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);
		handCursor = new Cursor(Cursor.HAND_CURSOR);
		
		mvArea.setCursor(defaultCursor);
		currentCursor = defaultCursor;
	}


	// MouseListener implementation
	// ----------------------------
	
	public void mouseEntered(MouseEvent ev) {}
	public void mouseExited(MouseEvent ev) {}
	public void mouseClicked(MouseEvent ev) {}
	public void mousePressed(MouseEvent ev)
	{
		if (ev.getButton() == MouseEvent.BUTTON1)
		{
			// almost all of the commands are handled upon button RELEASE,
			// but we still've gotta check for state movement... so...
			if (acaoClick == 0)
			{
				tempSt = mvArea.underCursor(ev.getX(), ev.getY());

				if (tempSt != null)
				{
					moving = true;
					tempX = ev.getX() - tempSt.getX();
					tempY = ev.getY() - tempSt.getY();
				}
				else
				{
					tempTrans = mvArea.trUnderCursor(
									ev.getX(),
									ev.getY());
					if (tempTrans != null)
					{
						movingTr = true;
						tempX = ev.getX();
						tempY = ev.getY();
						tempTrans.selectByPoint((int)tempX,
										(int)tempY);
						mvArea.repaint();
					}
				}
			}
		}
		else
		{ 
			// something other than mouse button 1 has been pressed. 
			// To us, here, this means CANCEL
			if (criaTrans)
			{ // but only transition creation can be canceled
				criaTrans = false;
				midpoints = null;
				mvArea.repaint();
			}
		}
	}
	
	public void mouseReleased(MouseEvent ev)
	{		
		if (ev.getButton() == MouseEvent.BUTTON1)
		{
			int acao = acaoClick;
			
			switch (acao)
			{
				case 0:
				{
					// Modified commands, so now there is a 
					// special command for moving things around
					//   - Mairo, 23/06
					// Modified to support Transition movement... first steps!
					// wow! it was easier than I thought! Altough I changed
					//   the main idea ^^"... movement is ready!
					//   - Mairo, 26/06
					if (moving)
					{
						moving = false;
						tempSt.move(ev.getX() - tempX,
										ev.getY() - tempY);
						mvArea.repaint();
					}
					if (movingTr)
					{
						movingTr = false;
						tempTrans.deselect();
						mvArea.repaint();
					}
					break;
				}
				case 1:
				{
					Estado es;
					mvArea.newState((int)ev.getX(), 
									(int)ev.getY());
/*
 * State creation is handled by MoveArea, not by the mouse listening 
 * class.. =^_^=
					es = new Estado("xx",false, false);
					es.move(ev.getX(), ev.getY());
					estados.add(es);
					repaint();
 */
					break;
				}
				case 2:
				{
					// ok, this is the huge one... we are creating
					// transitions, and there are (planned to be) several
					// ways of doing so. 
					// - Straight line connecting the two states
					//       (tested, but removed)
					// - Horizontal-and-vertical path connecting the two
					//     states
					// - Arcway connection? (not yet tested)
					// Yet... different kinds of connections will probably
					// mean diferent action commands
					//  -- Mairo, 24/06
					if (!criaTrans)
					{
						tempSt = mvArea.underCursor(ev.getX(), 
							ev.getY());
						criaTrans = (tempSt!=null);
						if (criaTrans)
						{
							tempX = tempSt.getCenterX();
							refX = tempX;
							tempY = tempSt.getCenterY();
							refY = tempY;
							direction = 0;
						}
					}
					else
					{
						Estado dest;
						dest = mvArea.underCursor((int)tempX,
										(int)tempY);
						
						if (midpoints == null)
							midpoints = new Vector();
						
						if (dest == null)
						{
							midpoints.add(new Point2D.Double(tempX,
										tempY));
							direction = 0;
							refX = tempX;
							refY = tempY;
						}
						else
						{
							mvArea.newTransition(tempSt, dest);
					
/* Same as with state creation... we just get the origin and destination,
 * and MoveArea handle's the rest ^_^
 * 
							Transicao t;
							t = new Transicao(origem,
									dest,
									midpoints,
									"a");
							transicoes.add(t);
 */
							midpoints = null;
							criaTrans = false;
						}
					}
					break;
				}
				case 3:
				{ 
					// this is easy one, but initial states aren't 
				 	//   being drawn yet :'(
					// Ok, changed things at Estado and Transition, and 
					// now I can (or so I think, at least...) mark
					// initial states. As I said, this is easy code... it's
					// just copy-n'-paste from case 4 below ^_^
					// ... hum.. small change to keep initial state unique...
					//   - Mairo, 26/06
					Estado es = mvArea.underCursor(
									ev.getX(),
									ev.getY());
					if (es != null)
						mvArea.toggleInic(es);

					// this one is needed... we aren changing this state
					// directly, and the MoveArea needs to know this!
					mvArea.repaint();
					break;
				}
				case 4:
				{
					Estado es = mvArea.underCursor(
									ev.getX(),
									ev.getY());
					if (es != null)
						es.toggleFinal();

					// this one is needed... we aren changing this state
					// directly, and the MoveArea needs to know this!
					mvArea.repaint();
					break;
				}
				// this is also transition creation, but it handles the 
				// creation of a straight line, just to make life easier ^^
				case 5:
				{
					if (!criaTrans)
					{
						tempSt = mvArea.underCursor(ev.getX(), ev.getY());
						criaTrans = (tempSt != null);
						if (criaTrans)
						{
							midpoints = new Vector();
							// like a professor used to say... "Gambiarra!"
							direction = 4;	
							tempX = tempSt.getCenterX();
							tempY = tempSt.getCenterY();
						}
					}
					else
					{
						Estado es = mvArea.underCursor(ev.getX(), ev.getY());
						if (es != null)
						{
							mvArea.newTransition(tempSt, es);
							tempSt = null;
							midpoints = null;
							criaTrans = false;
						}
					}
					break;
				}
				// State and transition removal - passed directly to
				// MoveArea, since it there's quite a lot of work to do,
				// and it'll be more required than us
				//   - Mairo, 26/06
				case 6:
				{
					mvArea.deleteStateAt(ev.getX(), ev.getY());
					break;
				}
				case 7:
				{
					mvArea.deleteTransitionAt(ev.getX(), ev.getY());
					break;
				} // case
			} // switch
		} // if
	} // method	

	// MouseMotionListener implementation
	// ----------------------------------

	public void mouseDragged(MouseEvent ev)
	{
		// is only called when moving a state around, so...
		if (moving)
		{
			tempSt.move(ev.getX() - tempX,
							ev.getY() - tempY);
			// same as w/ case 4 in mouseReleased, above
			mvArea.repaint();
		}
		// added code for moving transitions around
		//   - Mairo, 26/06
		if (movingTr)
		{
			tempTrans.tryMoving(ev.getX(), ev.getY());
			mvArea.repaint();
		}
	}
	
	public void mouseMoved(MouseEvent ev)
	{
		// ok, I lied... this piece of code is the biggest mess 
		// of all! it has to deal with many special cases -_-\/
		// and the worst... it's still going to grow! gah! >_<\/
		if (criaTrans)
		{
			double x, y;
			x = (double)ev.getX();
			y = (double)ev.getY();
			switch ( direction )
			{
				case 0:
				{ 
					// direction 0 means undecided... we've probably
					// just clicked de mouse, or brought it to the last
					// defined point... decide the new direction
					//   - Mairo, 22/06
					
					if (Math.abs(x-tempX) > Math.abs(y-tempY))
					{
						direction = 1;
						tempX = x;
					}
					else
					{
						direction = 2;
						tempY = y;
					}
					break;
				}
				case 1:
				{
					// this first if is to make sure we are STILL 
					// fulfilling case 1's requirements (see above ^_^")
					if (x != refX)
					{
						tempX = x;
						tempY = refY;
						break;
					}
					// fall through... if we've left case 1, then maybe we're
					// already at case 2... if not, the next case will
					// send us to case 'undecided' 0
				}
				case 2:
				{
					// So I said ^_^
					if (y == refY)
						direction = 0;
					else
					{
						direction = 2; // if we were in case 1...
						tempY = y;
						tempX = refX; // ensures we're walking a straight line
					}
					break;
				}
				// this is the freeline mode... just to save code, i made it
				// this way (like a "special direction")
				//   - Mairo, 26/06
				case 4:
				{
					tempX = (double)ev.getX();
					tempY = (double)ev.getY();
					break;
				}
			}
			// was almost forgetting this one! >_<"
			mvArea.repaint();
		}
		// updates the cursor, according to what's under it
		//  shall we use it to diferentiate actions too?
		if (mvArea.underCursor(ev.getX(), ev.getY()) != null)
		{
			if (currentCursor != handCursor)
			{
				mvArea.setCursor(handCursor);
				currentCursor = handCursor;
			}
		}
		else if (currentCursor != defaultCursor)
		{
			mvArea.setCursor(defaultCursor);
			currentCursor = defaultCursor;
		}
	}

	// ActionPerformed implementation...
	public void actionPerformed(ActionEvent e)
	{
		String action = e.getActionCommand();
		if (action.equals("defaultAction"))
			acaoClick = 0;
		else if (action.equals("addState"))
			acaoClick = 1;
		else if (action.equals("addTransRet"))
			acaoClick = 2;
		else if (action.equals("toggleInit"))
			acaoClick = 3;
		else if (action.equals("toggleFinal"))
			acaoClick = 4;
		else if (action.equals("addTrans"))
			acaoClick = 5;
		else if (action.equals("delState"))
			acaoClick = 6;
		else if (action.equals("delTrans"))
			acaoClick = 7;
		else
			acaoClick = -1; // o.O how in the hell?!?
	}
	
	// interface the MoveArea's paintComponent will call...
	public boolean isCreatingTrans()
	{
		return criaTrans;
	}

	public Vector getMidPoints()
	{
			return midpoints;
	}

	public Estado getOrigin()
	{
			return tempSt;
	}

	public Point2D.Double curEndPoint()
	{
			return new Point2D.Double((double)tempX, 
							(double)tempY);
	}
}
