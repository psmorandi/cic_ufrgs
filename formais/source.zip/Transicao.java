import java.awt.geom.*;
import java.awt.*;
import java.util.*;

public class Transicao
{
	Estado origem, destino;
	Vector simbolos;
	Vector pontos;

	private final double LOOPRAD = 20.0;
	// best location -- nearly between origem and destino...
	private double simsX, simsY;    

	boolean isLoop;
	Area loopArea;
	Point2D.Double loopMover;	// point to let user move the loop

	int seleciona;		// 0 = none, 1 = single line, 2 = corner
	Point2D.Double selectPt;


	Transicao(Estado o, Estado d, String s)
	{
		origem = o;
		destino = d;
		simbolos = new Vector();
		if (!origem.equals(destino))
		{
			d.addTransic(this);
			isLoop = false;
		}
		else
		{
			isLoop = true;
		}
			
		o.addTransic(this);
		simbolos.add(s);
		seleciona = 0;
		pontos = new Vector();
		if (isLoop == false)
		{
			pontos.add(0, new Point2D.Double(o.getX(),
						o.getY()));
			pontos.add(pontos.size(), new Point2D.Double(d.getX(),
						d.getY()));

		}
		updateLocation();
	}

	Transicao(Estado o, Estado d, String s, Vector midpoints)
	{ // will have to change the calling of this function...
		origem = o;
		destino = d;
		simbolos = new Vector();
		simbolos.add(s);
		o.addTransic(this);
		if (o.equals(d))
			isLoop = true;
		else
		{
			d.addTransic(this);
			pontos = midpoints;
			pontos.add(0, new Point2D.Double(o.getX(),
						o.getY()));
			pontos.add(pontos.size(), new Point2D.Double(d.getX(),
						d.getY()));
		}
		updateLocation();
	}

	public void addSymbol(String s)
	{
		simbolos.add(s);
	}

	//ok.. destroy is quite too appealing, but hey! it's MY program! ^_^
	//this method just calls removeTransition in it's source and destination
	//states...
	public void destroy()
	{
		origem.removeTransition(this);
		destino.removeTransition(this);
	}

	
	// changed to static, so Estado can call it to draw the initial 
	// state's mark... 
	//   - Mairo, 26/06
	public static void seta(Graphics2D g, Point2D.Double or, 
					Point2D.Double ds)
	{
		double offx1=-7, offy1=-3, offx2=-7, offy2 = 3;
		/*
		Point2D.Double or, ds;
		or = (Point2D.Double)pontos.elementAt(pontos.size()-2);
		ds = (Point2D.Double)pontos.elementAt(pontos.size()-1);
		*/
		double xo = or.getX();
		double yo = or.getY();
		double xd = ds.getX();
		double yd = ds.getY();
		
		if (xd < xo)
		{
			offx1 = 9;
			offx2 = 9;
		}

		if (xd != xo)
		{
			double tan_alfa = (yd-yo)/(xd-xo);
			double alfa = Math.atan(tan_alfa);
			float cos_alfa = (float)Math.cos(alfa);
			float sen_alfa = (float)tan_alfa * cos_alfa;
		
			double tempx = offx1, tempy = offy1;
			offx1 = Math.round((float)tempx * cos_alfa - 
							(float)tempy * sen_alfa);
			offy1 = Math.round((float)tempx * sen_alfa + 
							(float)tempy * cos_alfa);
			
			tempx = offx2; 
			tempy = offy2;
		
			offx2 = Math.round((float)tempx * cos_alfa - 
							(float)tempy * sen_alfa);
			offy2 = Math.round((float)tempx * sen_alfa + 
							(float)tempy * cos_alfa);
		}
		else
		{
			double temp = offx1;
			offx1 = offy1;
			offy1 = temp;
			temp = offx2;
			offx2 = offy2;
			offy2 = temp;
			if (yo > yd)
			{
				offy1 = -offy1;
				offy2 = -offy2;
			}
		}

		g.drawLine((int)xd,
						(int)yd,
						(int)(xd+offx1), 
						(int)(yd+offy1));	
		g.drawLine((int)xd, 
						(int)yd, 
						(int)(xd+offx2), 
						(int)(yd+offy2));
		g.drawLine((int)(xd+offx1), 
						(int)(yd+offy1), 
						(int)(xd+offx2), 
						(int)(yd+offy2));
	}

	public void updateLocation()
	{
		if (!isLoop)
		{
			Point2D.Double or, ds;
			or = (Point2D.Double)pontos.elementAt(1);
			ds = (Point2D.Double)pontos.elementAt(pontos.size()-2);
			or = origem.distFromCenter(or);
			ds = destino.distFromCenter(ds);
			pontos.set(0, or);
			pontos.set(pontos.size()-1, ds);
			// calculates symbols' best location
			double xMed = (origem.getCenterX()+destino.getCenterX())/2;
			double yMed = (origem.getCenterY()+destino.getCenterY())/2;

			double bestDist=1e20;
			int i_or = 0;

			for (int i=0;i<pontos.size()-1;i++)
			{
				Point2D.Double p1, p2;
				p1 = (Point2D.Double)pontos.elementAt(i);
				p2 = (Point2D.Double)pontos.elementAt(i+1);
				Line2D.Double l = new Line2D.Double(p1, p2);
				double dist = l.ptLineDist(xMed, yMed);
				if (dist < bestDist)
				{
					bestDist = dist;
					i_or = i;
				}
			}
			Point2D.Double p1, p2;
			p1 = (Point2D.Double)pontos.elementAt(i_or);
			p2 = (Point2D.Double)pontos.elementAt(i_or+1);
			
			simsX = (p1.getX()+p2.getX())/2;
			simsY = (p1.getY()+p2.getY())/2;
		}
		else
		{
			Point2D.Double temp;
			temp = new Point2D.Double(origem.getX(), origem.getY());
			temp = origem.distFromCenter(temp);
			temp.setLocation(temp.getX()-LOOPRAD, 
							temp.getY()-LOOPRAD);
			Ellipse2D.Double e;
			e = new Ellipse2D.Double(temp.getX(), 
							temp.getY(),
							2*LOOPRAD, 
							2*LOOPRAD);
			loopArea = new Area(e);
			Area st = new Area(origem);
			loopArea.subtract(st);
			// calculates symbols' best location
			simsX = temp.getX()-9*simbolos.size()-1;
			simsY = temp.getY();
		}
	}

	public boolean contains(int x, int y)
	{

		if (isLoop)
			return false;
		
		Rectangle2D.Double pt = new Rectangle2D.Double(x-2.5, y-2.5,
							5.0, 5.0);
		int i;
		for (i=0;i<pontos.size()-1;i++)
		{
			Line2D.Double l;
			Point2D.Double o, d;
			o = (Point2D.Double)pontos.elementAt(i);	
			d = (Point2D.Double)pontos.elementAt(i+1);
			l = new Line2D.Double(o, d);
			if (l.intersects(pt))
				return true;
		}
		return false;
	}

	public boolean isCorner(int x, int y)
	{
		if (isLoop)
				return false;
		
		int i;
		boolean almost = false;
//		System.out.println("x = "+x+", y = "+y);
		Rectangle.Double ponto;
		ponto = new Rectangle2D.Double((double)x-2.5, 
				(double)y-2.5, 
				5.0, 5.0);	// a "point" considered like a circle of diameter=5
		for (i=0;i<pontos.size()-1;i++)
		{
			Line2D.Double l;
			Point2D.Double o, d;
			o = (Point2D.Double)pontos.elementAt(i);	
			d = (Point2D.Double)pontos.elementAt(i+1);
			l = new Line2D.Double(o, d);
			if (l.intersects(ponto.getBounds2D()))
			{
				if (!almost)
					almost = true;
				else
					return true;
			}
		}
		return false;
	}

	public void selectByPoint(int x, int y)
	{
		if (isLoop)
				return;
			
		int i;
		seleciona = 0;
		for (i=0;i<pontos.size()-1;i++)
		{
			Line2D.Double l;
			Point2D.Double o, d;
			o = (Point2D.Double)pontos.elementAt(i);	
			d = (Point2D.Double)pontos.elementAt(i+1);
			l = new Line2D.Double(o, d);
			if (l.intersects((double)x-2.5,
						(double)y-2.5,
						5.0,5.0))
			{
				if (seleciona == 0)
				{
					seleciona = 1;
				}
				else
				{
					selectPt = o;
					seleciona = 2;
					return;	// found everything we need ^_^
				}
			}
		}
		// here, seleciona == 0 or 1... but this isn't acceptable!
		seleciona = 0;
		selectPt = null;
	}

	public void tryMoving(int x, int y)
	{
		if (seleciona == 2)
			selectPt.setLocation((double)x, (double)y);
	}

	public void deselect()
	{
			seleciona = 0;
	}

	public Estado getDest()
	{
		return destino;
	}

	public Vector getSymbols()
	{
		return simbolos;
	}
	
	public Estado getSource()
	{
		return origem;
	}

	public void draw(Graphics2D g2)
	{
		
		double xc, yc;

		if (origem.equals(destino))
		{
			updateLocation();
			g2.draw(loopArea);
			// now to the painful part... draw the symbol AND the arrow -_-
			PathIterator pi = loopArea.getPathIterator(null);
			double[] coords = new double[10];
			int type;
			do {
				type = pi.currentSegment(coords);
				pi.next();
			} 
			while (!pi.isDone());
			//ok, tem os pontos finais do ultimo segmento
			Point2D.Double dest = new Point2D.Double(coords[0],
							coords[1]);
			Point2D.Double tmp = origem.distFromCenter(dest);
			Transicao.seta(g2, dest, tmp);
		}
		else
		{
			Point2D.Double or, ds;
			updateLocation();
			for (int i=0;i<pontos.size()-1;i++)
			{
				or = (Point2D.Double)pontos.elementAt(i);
				ds = (Point2D.Double)pontos.elementAt(i+1);
				if (!or.equals(pontos.elementAt(0)) &&
        			    !or.equals(pontos.elementAt(pontos.size()-1))
				   ) 
					g2.fillOval((int)or.getX()-3, 
						(int)or.getY()-3,
						6,6);

						
				g2.drawLine(
							(int)or.getX(), 
							(int)or.getY(), 
							(int)ds.getX(), 
							(int)ds.getY());
			}
			if (seleciona == 2)
			{
				g2.setColor(java.awt.Color.blue);
				g2.fillOval((int)selectPt.getX()-3,
						(int)selectPt.getY()-3,
						6, 6);
				g2.setColor(java.awt.Color.black);
			}

			or = (Point2D.Double)pontos.elementAt(pontos.size()-2);
			ds = (Point2D.Double)pontos.elementAt(pontos.size()-1);
			Transicao.seta(g2, or, ds); 
			or = (Point2D.Double)pontos.elementAt(0);
			ds = (Point2D.Double)pontos.elementAt(1);
			
			/*
			xc = (or.getX()+ds.getX())/2;
			yc = (or.getY()+ds.getY())/2;
			if (or.getX()>ds.getX())
				yc += 10;
			
			for (int i=0;i<simbolos.size();i++)
			{
				String simbolo = (String)simbolos.elementAt(i);
				if (i < simbolos.size()-1)
						simbolo = simbolo+",";
				g2.drawString(simbolo, (int)(xc-5), (int)yc);
				xc+=9;
			}*/
		}
		xc = simsX;
		yc = simsY;
		for (int i=0;i<simbolos.size();i++)
		{
			String simbolo = (String)simbolos.elementAt(i);
			if (i < simbolos.size()-1)
					simbolo = simbolo+",";
			g2.drawString(simbolo, (int)(xc-5), (int)yc);
			xc+=9;
		}
	}
}
