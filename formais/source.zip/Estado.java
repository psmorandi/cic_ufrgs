import java.awt.geom.*;
import java.awt.*;
import java.util.*;

public class Estado extends Ellipse2D.Double
{
	private final int MINWID = 36;
	private final int MINHEIG = 36;
	String nome;
	Vector transic;

	boolean inic, fin;

	private boolean destroying = false;

	public Estado(String nome, boolean i, boolean f)
	{
		super();
		this.nome = nome;
		transic = new Vector();

		int w = (nome.length()*10+6 > MINWID)?nome.length()*10+6:MINWID;
		setFrame(new Point2D.Double(0, 0),
			new Dimension(w, MINHEIG));
		inic = i;
		fin = f;
	}

	public void addTransic(Transicao t)
	{
		transic.add(t);
	}

	public void removeTransition(Transicao t)
	{
		if (!destroying)
			transic.remove(t);
	}
	
	public void removeTransitions()
	{
		int i;
		// so our transitions won't be removed by Transicao.destroy()
		destroying = true;
		for (i=0;i<transic.size();i++)
		{
			Transicao t;
			t = (Transicao)transic.elementAt(i);
			t.destroy();
		}
		transic = null;
	}


	public void toggleInic()
	{
		inic = !inic;
	}

	public Vector getTransitions()
	{
		return transic;
	}

	public void toggleFinal()
	{
		fin = !fin;
	}

	public String getName()
	{
		return nome;
	}
	
	public boolean isFinal()
	{
		return fin;
	}

	public boolean isInitial()
	{
		return inic;
	}

	private void updateTrans()
	{
		int i;
		Transicao t;
		for (i=0;i<transic.size();i++)
		{
			t = (Transicao)(transic.elementAt(i));
			t.updateLocation();
		}
	}

	public void move(double x, double y)
	{
		setFrame(new Point2D.Double(x, y),
		new Dimension((int)getWidth(), (int)getHeight()));
		updateTrans();
	}

	// helper function: calculates the distance from the center of 
	// this ellipse to it's border, using 'pt' as a reference point
	public Point2D.Double distFromCenter(Point2D.Double pt)
	{
		double oX, oY, dX, dY;
		oX = getCenterX();
		oY = getCenterY();
		dX = pt.getX();
		dY = pt.getY();
		if (oX == dX)
		{
			if (oY < dY)
				oY += getHeight()/2;
			else
				oY -= getHeight()/2;
		}
		else
		{
			double a = (dY-oY)/(dX-oX);
			double oRx = getWidth()/2;
			double oRy = getHeight()/2;
	
			double dx = Math.sqrt(oRx*oRx*oRy*oRy/
					(oRx*oRx*a*a+oRy*oRy));
			double dy = a*dx;
			if (oX > dX)
			{
				dx = -dx;
				dy = -dy;
			}
			oX += dx;
			oY += dy;
		}
		return new Point2D.Double(oX, oY);
	}

	public void paint(Graphics2D g)
	{
		g.drawOval((int)getX(), 
			(int)getY(), 
			(int)getWidth(), 
			(int)getHeight());

		g.drawString(nome, 
			(int)getX() + 8, 
			(int)(getY()+getHeight()/2+7));

        
		if (inic)
		{
			Point2D.Double or, ds;
			or = new Point2D.Double(getX(), getY());
			ds = distFromCenter(or);
			g.drawLine((int)or.getX(), (int)or.getY(),
							(int)ds.getX(), (int)ds.getY());
			Transicao.seta(g, or, ds);
		}
		if (fin)
		{
			g.drawOval((int)getX()+3, 
				(int)getY()+3, 
				(int)getWidth()-6, 
				(int)getHeight()-6);
		}
	}
}
