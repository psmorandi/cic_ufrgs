import javax.swing.*;
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class MoveArea extends JPanel
{
	// automaton states and transitions
	private Vector estados;
	private Vector transicoes;

	private Rectangle moveArea;

	private MouseHandler mh;

	// initial state is unique... so we must store it somewhere, 
	// as to be able to keep it unique ^_^
	private Estado initial;

	// returns the first state that contains the point (x,y)
	public Estado underCursor(int x, int y)
	{
		int i;
		for (i=0;i<estados.size();i++)
		{
			Estado es = (Estado)estados.elementAt(i);
			if (es.contains(x, y))
				return es;
		}
		return null;
	}

	public void toggleInic(Estado es)
	{
		if (initial == null || initial == es)
		{
			initial = es;
			es.toggleInic();
		}
		else
		{
			JOptionPane.showMessageDialog(null,
						"Attempting to define more than one initial state!",
						"Toggle Initial",
						JOptionPane.ERROR_MESSAGE);
		}
	}
	
	// returns the first state that contains the point (x,y)
	public Transicao trUnderCursor(int x, int y)
	{
		int i;
		for (i=0;i<transicoes.size();i++)
		{
			Transicao tr = (Transicao)transicoes.elementAt(i);
			if (tr.contains(x, y))
				return tr;
		}
		return null;
	}
	public MoveArea()
	{
		super();

		setBackground(java.awt.Color.white);
		estados = new Vector();
		transicoes = new Vector();
		
		mh = new MouseHandler(this);
		
		addMouseListener(mh);
		addMouseMotionListener(mh);
	}

	public void newTransition(Estado or, Estado ds)
	{
		Vector trans;
		String sym = JOptionPane.showInputDialog("What symbol shall this transition read?");
		if (sym == null || sym.trim().equals(""))
			return;
		Transicao t;
		trans = or.getTransitions();
		for (int i=0;i<trans.size();i++)
		{
			t = (Transicao)trans.elementAt(i);
			if (t.getSource().equals(or))
			{
				Vector syms = t.getSymbols();
				for (int k=0;k<syms.size();k++)
				{
					String sym_k = (String)syms.elementAt(k);
					if (sym_k.equals(sym))
					{
						JOptionPane.showMessageDialog(null, 
								"Non-deterministic transitions are forbidden!", 
								"Invalid transition",
								JOptionPane.ERROR_MESSAGE);
						return;
					}
				}
				if (t.getDest().equals(ds))
				{
					t.addSymbol(sym);
					repaint();
					return;
				}
			}
		}
		t = new Transicao(or, ds, sym, mh.getMidPoints());
		transicoes.add(t);
		repaint();
	}


	public void newState(int x, int y)
	{
		String stId = JOptionPane.showInputDialog("Enter state's name");
		if (stId == null || stId.trim().equals(""))
			return;
		int i;
		Estado es;
		for (i=0;i<estados.size();i++)
		{
			es = (Estado)estados.elementAt(i);
			if (es.getName().equals(stId))
			{
				JOptionPane.showMessageDialog(null,
								"State already defined!",
								"Invalid State",
								JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		es = new Estado(stId, false, false);
		es.move(x, y);
		estados.add(es);
		repaint();
	}
	
	public void deleteTransitionAt(int x, int y)
	{
		Transicao tr = trUnderCursor(x, y);
		if (tr == null) 
				return;
		int acao = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to remove this transition?",
						"Remove transition",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
		if (acao == JOptionPane.YES_OPTION)
		{
			tr.destroy();
			transicoes.remove(tr);
			repaint();
		}
	}
	
	
	public void deleteStateAt(int x, int y)
	{
		Estado es = underCursor(x, y);
		if (es == null) 
				return;
		int acao = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to remove this state\n"+
						"and all of it's related transitions?",
						"Remove state",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
		if (acao == JOptionPane.YES_OPTION)
		{
			Vector v = es.getTransitions();
			es.removeTransitions();
			// wheee!!! I won't need to do a brute force search-and-remove! 
			// ^_^ I was afraid of having to do so... it'd be scary! o.o'
			// well... Estado.removeTransitions() will have already called
			// Transicao.destroy(), for all of it's transitions... so...
			transicoes.removeAll(v);
			estados.remove(es);
			if (es == initial)
					initial = null;
			repaint();
		}
	}


	public ActionListener listener()
	{
			return mh;
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		if (moveArea == null)
			moveArea = new Rectangle(getWidth(), getHeight());

		Graphics2D g2 = (Graphics2D)g;

		Estado es;
		int i;
		for (i=0;i<estados.size();i++)
		{
			es = (Estado)estados.elementAt(i);
			es.paint(g2);
		}

		for (i=0;i<transicoes.size();i++)
		{
			Transicao t = (Transicao)transicoes.elementAt(i);
			t.draw(g2);
		}

		if (mh.isCreatingTrans())
		{
			double xDst, yDst;
			Estado origem = mh.getOrigin();
			Point2D.Double or = new Point2D.Double(origem.getCenterX(), 
							origem.getCenterY());
			Point2D.Double ds;
			Vector midpoints = mh.getMidPoints();
			
			if (midpoints != null)
			{
				for (i=0;i<midpoints.size();i++)
				{
					ds = (Point2D.Double)midpoints.elementAt(i);
					g2.drawLine((int)or.getX(),
							(int)or.getY(),
							(int)ds.getX(),
							(int)ds.getY());
					or = ds;
				}
			}

			ds = mh.curEndPoint();
			
			g2.drawLine((int)or.getX(),
					(int)or.getY(),
					(int)ds.getX(),
					(int)ds.getY());
		}
	}
	/* gah... forgot to pick those classes... this will be
	 * the first step in the process of joining our efforts =]
	 *  - Mairo, 02/07
	 */
	public Automato getAutomaton()
	{
		String src, dst;
		Vector alfabeto = new Vector();
		
		Automato a = new Automato();

		// first thing: add the initial state
		// it MUST be the first state to be added...
		if (initial == null)
		{
			JOptionPane.showMessageDialog(null,
							"No initial state has been defined!",
							"Warning",
							JOptionPane.WARNING_MESSAGE);
			return null;
		}
		src = initial.getName();
		if (initial.isFinal())
			src = "*"+initial.getName();
		
		a.addState(src);

		for (int i=0;i<transicoes.size();i++)
		{
			Transicao t;
			t = (Transicao)transicoes.elementAt(i);
			Estado or= t.getSource(), ds = t.getDest();
			
			if (or.isFinal())
				src = "*"+or.getName();
			else
				src = or.getName();
			if (ds.isFinal())
				dst = "*"+ds.getName();
			else
				dst = ds.getName();

			Vector syms = t.getSymbols();
			for (int j=0;j < syms.size(); j++)
			{
				String sym = (String)syms.elementAt(j);
				a.addTransition(src, dst, sym);
			}
		}
		return a;
	}
	
	// this is the `inverse operation' of the above --
	// given an automaton, draw it's graph representation...
	// well... I'll put the states, and it'll be up to the user
	// to rearrange them ^^
	//   - Mairo, 03/07
	//   Making what he told above...
	//   - Paulo, 05/07 (What??? Working at Saturday?? Ok.. I haven't
	//   			anything better to do....)
	//  	   Just remember that paintComponent draw the automaton....
	public void drawAutomaton(Automato a)
	{
		Vector trans = a.getTransitions();
		Vector est = a.getStates();
		Vector finais = a.getFinalStates();
		Vector mid = new Vector();
		boolean ehInicial, ehFinal;

		//Creating the states, but.....I guess the initial one is "tosco", maybe there is any other
		//better way to find it...
		for( int i=0; i<est.size(); i++)
		{
			String estadoComp = (String)est.elementAt(i);
			int temp = a.getStateIndex(estadoComp);
			ehInicial = false; ehFinal = false;

			if( temp == 0 )
				ehInicial = true;
				
			
			if (finais.contains(estadoComp))
			{
				ehFinal = true;
			}
			Estado es = new Estado(estadoComp,ehInicial,ehFinal);
			if ( ehInicial )
				initial = es;
			estados.add(es);
		}
		
		for(int i=0; i<trans.size(); i++)
		{
			Estado origem = null, destino = null;
			Vector temp = (Vector)trans.elementAt(i);
			//origem is the trans index
			String or = a.getStateName(i);
			for(int k=0;k<estados.size() && origem == null;k++)
			{
				Estado es = (Estado)estados.elementAt(k);
				if (es.getName().equals(or))
					origem = es;
			}
			
			//Making the transitions between or and ds with the symbol sym
			for(int j=0; j<temp.size(); j++)
			{
				Integer x = (Integer)temp.elementAt(j);
				String ds = a.getStateName(x.intValue());
				String sym = a.getSymbol(j);
				for( int k=0;k<estados.size();k++)
				{
					Estado es = (Estado)estados.elementAt(k);
					if (es.getName().equals(ds))
					{
						destino = es;
					}
				}
				if (destino != null)
				{
					Transicao tr;
					boolean inseriu = false;
					
					for (int bla = 0; bla < transicoes.size() &&  !inseriu; bla++)
					{
						tr = (Transicao)transicoes.elementAt(bla);
						if (tr.getSource().equals(origem) &&
							tr.getDest().equals(destino))
						{
							tr.addSymbol(sym);
							inseriu = true;
						}
					}
					if (!inseriu)
					{
						tr = new Transicao(origem,destino,sym);
						transicoes.add(tr);
					}
				}
			}
		}
		
	}		
}
