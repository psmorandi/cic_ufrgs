/*
 * Created on 28/06/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author Marcelo
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class UmPar {
	// um par para ser usado na lista da matriz de registros
	private String um;
	private String outro;
	
	UmPar() { // construtor	
	}
	
	UmPar (String s1, String s2)  {
		um=s1;
		outro=s2;  
	}	
	
	public String retornaUm () {
		return (um);
	}
	public String retornaOutro ()  {
		return (outro);
	}
}
