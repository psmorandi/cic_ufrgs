import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Menus extends JMenu{

JMenuItem criaItem(String text, int mnemonic, KeyStroke accel)
{
	JMenuItem it = new JMenuItem(text, mnemonic);
	it.setAccelerator(accel);
	return it;
	
}

JMenuItem criaItem(String text, int mnemonic)
{
	return new JMenuItem(text, mnemonic);
}

JMenuItem criaItem(String text)
{
	return new JMenuItem(text);
}

JMenu criaMenu(String text, int mnemonic)
{
	JMenu m = new JMenu(text);
	m.setMnemonic(mnemonic);
	return m;
}
}