//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo TestaCategoria.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
//- Testa se o arquivo lido � uma categoria;
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.util.*;

public class TestaCategoria
{
	Categoria cat;

	public TestaCategoria (Categoria categoria) {
		cat=categoria;		
	}

	public boolean procuraIdentidade (String qualObj)
	{
		Morfismo myMorphism;
		Vector v;

		v= (Vector) cat.getTabMor();

		// verifica todos os morfismos
		for (int i=0; i< cat.getTabMor().size(); i++) {

			myMorphism= (Morfismo) v.get (i);

			if ((myMorphism.id) && ( myMorphism.origem.equals( qualObj) )
					    && ( myMorphism.destino.equals (qualObj ) ))
				return (true);
		}

		return(false);  // se nao saiu ainda nao tem identidade (false)
	}

	public void testaIdentidade () throws CatExcept
	{
		// verificar, para todos os objetos, se ele tem identidade

		Iterator it = cat.getObj().iterator(); // acesso aos objetos da categoria
		String myObject= "";

		for (int i=0; i<cat.getObj().size(); i++)
		{
			myObject=(String) it.next();

			if (!procuraIdentidade(myObject))
			{ // se nao tem, nao eh categoria
				throw new CatExcept("Objeto "+myObject+" n�o possue morfismo identidade");

			}
		}
	}

	
	public void testaComposicao () throws CatExcept
	{
		// verificar, para todos os objetos, se ele tem identidade

		Vector morphism = cat.getTabMor ();
		Vector composition= cat.getComp ();
		String comp;

		Morfismo m1;
		Morfismo m2;

				
		for (int i=0; i< morphism.size () ; i++) 
		{
			m1 = (Morfismo) morphism.get (i);

			for (int j=0 ; j < morphism.size () ; j++) 
			{
				m2 = (Morfismo) morphism.get (j);
				
				// se o destino de m1 eh origem de m2, testa se tem um morfismo pro
				// objeto origem de m1 e destio de m2

				if (m1.destino.equals ( m2.origem ) && !m1.id && !m2.id)
				{
					// Se m1.destino == m2.origem, ent�o necessariamente deve existir 
					// uma composi��o...
					comp = procuraComp ( m2.morfismo, m1.morfismo );

					//Se naum existir, ent�o n�o � categoria...
					if ( comp == null ) throw new CatExcept("N�o existe a composi��o "+m2.morfismo+"_"+m1.morfismo);
				}
			}
		}

	}

	public String procuraComp ( String g, String f )
	{

		Vector composicoes = cat.getComp ();
		Composicao c;

		for (int i=0; i < composicoes.size(); i++)
		{
			c = (Composicao) composicoes.get(i);
			if ( c.morfG.equals(g) && c.morfF.equals(f) )
				return c.morfH;
		}
		return null;
	}


	public void testaAssociatividade() throws CatExcept
	{
		Vector morf = cat.getTabMor();
		Morfismo f, g, h;
		String hog, hog_of, ho_gof, gof;

		for (int i=0; i< morf.size () ; i++)
		{
			f= (Morfismo) morf.get (i);
			for (int j=0; j< morf.size () ; j++)
			{
				g= (Morfismo) morf.get (j);
				for (int k=0; k< morf.size () ; k++)
				{
					h= (Morfismo) morf.get (k);
					if ( (i != j) && (j!=k) && ( i != k ) )
					{
						if ( f.destino.equals (g.origem )  &&
						     g.destino.equals (h.origem )
						   )
						{
							hog = procuraComp ( h.morfismo, g.morfismo );
							hog_of = procuraComp (hog, f.morfismo);

							gof = procuraComp (g.morfismo, f.morfismo);
							ho_gof = procuraComp (h.morfismo, gof);

							if ( (hog_of != null) && (ho_gof != null) )

							if (! hog_of.equals ( ho_gof ) ) throw new CatExcept("N�o � associativa: "+hog_of+" != "+ho_gof);

						}
					}
				   }
				}
			}

	}

	public void testa ( ) throws CatExcept
	{

		testaIdentidade();
		testaComposicao();
		testaAssociatividade();
	}
}
