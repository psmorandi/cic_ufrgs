//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Funtor.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Defini��o dos procedimentos que v�o dar sentido (ou n�o) ao arquivo de entrada.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

public class Funtor {

	private String nomeFuntor;
	private String catOrg, catDest;
	private Vector objetos; //Armazena os objetos do Funtor;
	private Vector morfismos; //Armazena os Morfismos do Funtor;

	//Construtor
	public Funtor( String nome )
	{
		nomeFuntor = new String( nome );
		objetos = new Vector();
		morfismos = new Vector();
	}

	public String getNome()
	{
		return nomeFuntor;
	}

	public Vector getFuntorMorf()
	{
		return morfismos;
	}

	public Vector getFuntorObj() {
		return objetos;
	}
	public Vector getObjOrigem()
	{
		Vector origem = new Vector();
		ObjetoFuntor obj;

		for(int i=0; i<objetos.size(); i++)
		{
			obj = (ObjetoFuntor)objetos.elementAt(i);
			origem.add((String)obj.obj);
		}

		return origem;
	}
	public Vector getObjDestino()
	{
		Vector destino = new Vector();
		ObjetoFuntor obj;

		for(int i=0; i<objetos.size(); i++)
		{
			obj = (ObjetoFuntor)objetos.elementAt(i);
			destino.add((String)obj.imagemObj);
		}

		return destino;
	}

	public Vector getMorOrigem()
	{
		Vector origem = new Vector();
		MorfismoFuntor f;

		for(int i=0; i<morfismos.size(); i++)
		{
			f = (MorfismoFuntor)morfismos.elementAt(i);
			origem.add((String)f.morf);
		}

		return origem;
	}
	public Vector getMorDestino()
	{
		Vector destino = new Vector();
		MorfismoFuntor f;

		for(int i=0; i<morfismos.size(); i++)
		{
			f = (MorfismoFuntor)morfismos.elementAt(i);
			destino.add((String)f.imagemMorf);
		}

		return destino;
	}

	public Categoria getCatOrigem( Hashtable todasCategorias )
	{
		return (Categoria)todasCategorias.get(catOrg);
	}

	public Categoria getCatDestino( Hashtable todasCategorias )
	{
		return (Categoria)todasCategorias.get(catDest);
	}

	public String getStringCatOrigem()
	{
		return catOrg;
	}
	public String getStringCatDestino()
	{
		return catDest;
	}

	public void setFuntorCatOrg( String origem )
	{
		catOrg = origem;
	}

	public void setFuntorCatDest( String destino )
	{
		catDest = destino;
	}

	public void adicionaFuntorObj( ObjetoFuntor o )
	{
		objetos.add(o);
	}

	public void adicionaFuntorMor( MorfismoFuntor m )
	{
		morfismos.add(m);
	}

}
