//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo OjetoFuntor.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Tabela que armazena os morfismos do funtor.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------


import java.util.*;

public class TestaFuntor 
{
	Categoria cat1, cat2;
	Funtor myFunctor;

	// informa��es dos funtor!
	Vector funtorObjOrigem;	
	Vector funtorObjDestino;
	Vector funtorMorphOrigem;
	Vector funtorMorphDestino;
	private static String classe = new String("CLASSE TESTAFUNTOR:: ");

	public TestaFuntor ( Hashtable todasCategorias, Funtor f )
	{
		cat1=f.getCatOrigem(todasCategorias);	// infos de morfismos e composicoes e objetos e ...
		cat2=f.getCatDestino(todasCategorias);
		myFunctor= f;
	}

	
	public void testa ( ) throws CatExcept
	{

		// well... tem que ver se todos os objetos da categoria origem t�o definidos no
		// arquivo de funtor, afinal de contas, o funtor eh uma funcao total total![

		Iterator it = cat1.getObj().iterator(); // acesso aos objetos da categoria ORIGEM
		String myObject;

		// para todos os objetos, ve se tah definido no arquivo de funtor! e mais, v� se tah
		// definido soh uma vez!
		for (int i=0; i< cat1.getObj().size(); i++) {
			myObject = (String) it.next(); //  nome do objeto
			if (!procuraObjEmFuntor (myObject) ) {
				throw new CatExcept("O potencial funtor n�o � total! Faltou um mapeamento para o Objeto "+myObject);
			}
		}

		Vector morOrigem = cat1.getTabMor();
		Morfismo myMorphism;
		String morphismStr;
		// pra todos os morfismos da categoria origem, ve se tah definido no arquivo
		// de funtor! e mais, ve se tah definido soh uma vez!

		for (int i=0; i< morOrigem.size(); i++)
		{
			myMorphism = (Morfismo) morOrigem.get(i); //
			morphismStr = myMorphism.morfismo;  // nome do morfismo

			// se o morfismo nao tah definido, dah pau
			if ( procuraMorEmFuntor (morphismStr) == 0 )
			throw new CatExcept("O potencial funtor n�o � total! Faltou mapeamento para o Morfismo "+morphismStr+".");
			else if ( procuraMorEmFuntor (morphismStr) > 1 )
			throw new CatExcept("O potencial funtor n�o � fun��o! Mais de um mapeamento do Morfismo "+morphismStr+" foi encontrado.");

		}

		// se ainda nao retornou falso eh porque:
		// 	-> tem todos os objetos definidos no `arquivo` funtor uma unica vez
		// 	-> tem todos os morfismos definidos no funtor uma unica vez!
		//
		// 	resumo: tudo que tem na categoria Origem tem no arquivo do funtor.
		//
		// 	resta tratar o caso em que o arquivo de funtor tem mais objetos e/ou morfismos
		// 	que a categoria origem! Nesse caso ia estar mapeando coisa que nao existe na
		// 	categoria origem
		// 	-> se o numero de objetos definidos no funtor for o mesmo que o definido na
		// 	categoria, entao tudo no funtor tb esta definido!
		// 	-> idem pros morfismos!

		if (cat1.getObj().size() != myFunctor.getObjOrigem().size() ) throw new CatExcept("O potencial funtor n�o � fun��o! N�mero de objetos origem no funtor > N�mero de objetos da Categoria destino");

		if (cat1.getTabMor().size() != myFunctor.getMorOrigem() .size() ) throw new CatExcept("O potencial funtor n�o � fun��o! N�mero de morfismos origem no funtor > N�mero de morfismos da Categoria destino");

		// continuando... tem que ver se existe homomorfismo entre os 'grafos'
		temHomomorfismo();
		temHomomorfismoReflexivo ();

		// e por ultimo, mas nao menos importante...
		testaComposicoes (cat1, cat2);
	}

	public void temHomomorfismoReflexivo () throws CatExcept
	{
		// para todos os nodos v� se o morfismo identidade foi
		// mapeado pra identidade na imagem do objeto

		Iterator it = cat1.getObj().iterator(); // objetos da categoria Origem
		String myObject;
		Morfismo m1;
		Morfismo m2;

		String mapeiaObj;
		Morfismo mapeiaMorf;

		for (int i=0; i< cat1.getObj().size(); i++)
		{
			myObject= (String) it.next();

			// procura identidade desse objecto
			m1= procuraMorfismoIdentidade ( cat1, myObject );

			mapeiaObj = procuraCorrespondenteObjEmFuntor ( myObject );
			mapeiaMorf= procuraCorrespondenteMorEmFuntor ( m1.morfismo );

			// agora ve quem eh o morfismo identidade do objeto
			// mapeado pra categoria2! Ve se o morfismo identidade
			// eh o mesmo morfismo mapeado

			m2= procuraMorfismoIdentidade (cat2, mapeiaObj );

			// compara...
			if (!m2.morfismo.equals( mapeiaMorf.morfismo  ) ) throw new CatExcept("N�o preserva a identidade! O morfismo "+m1.morfismo+" n�o foi mapeado para a identidade ma categoria destino.");
			// se pelo menos um n�o mapear decentemente jah deu
			// pau no funtor
		}

	}

	public Morfismo procuraMorfismoIdentidade ( Categoria qualCategoria, String qualObjeto )
	{
		Vector morfismos = qualCategoria.getTabMor();
		Morfismo m1;

		for (int i=0; i< morfismos.size(); i++)
		{
			m1 = (Morfismo) morfismos.get (i);

			if ( m1.origem.equals ( qualObjeto ) && m1.destino.equals (qualObjeto) && m1.id )
			{
				// eh a identidade do objeto 'qualObjeto'
				return m1;
			}
		}

		return null; // teoricamente nunca vai chegar aqui!
	}

	public void temHomomorfismo () throws CatExcept
	{

		Vector morfismosOrigem = cat1.getTabMor();
		String origemOrigem; // origem do morfismo da categoria origem
		String destinoOrigem;// destino do morfismo da categoria origem
		String origemDestino;// origem do morfismo da categoria destino
		String destinoDestino;// destino do morfismo da categoria destino

		Morfismo m1;
		Morfismo ondeVou;

		String nemtiannttv; // no enoght memory to invent a new name to this variable


		// pra todos os morfismos da categoria1
		// 	ver a origem e o destino
		//	mapeia esse morfismo na categoria2
		//	ver na categoria2 quem eh origem e destino desse cara (morfismo)
		//	ver no funtor pra quem deveria ir origem e destino da cat1 e se,
		//		de fato foi (compara com origem e destino da categoria2).
		//
		//	categoria Origem:  (1)
		//	categoria Destino: (2)

		for (int i=0; i< morfismosOrigem.size (); i++)
		{
			m1= (Morfismo) morfismosOrigem.get (i); // morfismos da categoria Origem
			origemOrigem=m1.origem;
			destinoOrigem=m1.destino;

			// m1 vai ser levado em quem??? procura na tabela de morfismos do FUNTOR

			ondeVou= procuraCorrespondenteMorEmFuntor (m1.morfismo);  // retorna o morfismo da categoria2

			if (ondeVou == null) throw new CatExcept("N�o est� definido o destino de "+m1.morfismo); // nao tem o morfismo no destino

			origemDestino = ondeVou.origem;   // isso eh a origem e destino do morfismo na
			destinoDestino= ondeVou.destino;  // categoria DESTINO

			// agora v� onde deveria ter ido e v� se eh pra onde foi!
			// ashioeHOEAHIOSEHOIahoeishioehOHSOAHIOH
			// bah... caro leitor... observe qu�o elucidativo eh o coment�rio acima.
			// :-)

			nemtiannttv= procuraCorrespondenteObjEmFuntor (origemOrigem); // volta um string!
			// dado um objeto da origem, v� qual a imagem na categoria 2 (olha isso no funtor)

			if (!nemtiannttv.equals ( origemDestino) ) throw new CatExcept("N�o preservou a Origem de "+origemOrigem); // nao foi onde deveria ter ido

			nemtiannttv= procuraCorrespondenteObjEmFuntor (destinoOrigem); // volta um string
			if (!nemtiannttv.equals ( destinoDestino) ) throw new CatExcept("N�o preservou o Destino de "+destinoDestino); // nao foi onde deveria ter ido
		}
	}


	public String procuraCorrespondenteObjEmFuntor (String qualObj)
	{
		String temp;

		for (int i=0; i< myFunctor.getObjOrigem().size() ; i++)
		{
			temp = (String) myFunctor.getObjOrigem().get(i);

			if (qualObj.equals ( temp ) ) return ( (String) myFunctor.getObjDestino().get(i) );
			// retorna o destino, ie, onde o objeto foi mapeado no destino
		}

		return null;
	}

	public Morfismo procuraCorrespondenteMorEmFuntor (String qualMorfismo)
	{
		String temp, tempMorfImagem;
		Vector tempMorf;
		Morfismo morfismo;

		for (int i=0; i< myFunctor.getMorOrigem().size() ; i++)
		{
			temp = (String) myFunctor.getMorOrigem().get(i);
			if (qualMorfismo.equals ( temp ) )
			{
				// se achou esse morfismo no FUNTOR, vai na CATEGORIA2 e busca ele

				tempMorfImagem = (String) myFunctor.getMorDestino().get(i);

				// indo na categoria2 e buscando ele...
				tempMorf = cat2.getTabMor();
				for (int j=0; j< tempMorf.size (); j++)
				{
					morfismo = (Morfismo) tempMorf.get (j);
					if (morfismo.morfismo.equals (tempMorfImagem))
					return ( morfismo );
				}

			}
		}

		return null;
	}

	public void testaComposicoes (Categoria cat1, Categoria cat2) throws CatExcept
	{ // asdf
		Vector morfismosOrigem  = cat1.getTabMor();
		Vector morfismosDestino = cat2.getTabMor();

		Morfismo m1Origem, m2Origem;
		Morfismo m1Destino, m2Destino;

		String composicaoOrigem;

		Morfismo compoeMapeia;
		String mapeiaCompoe;


		// negocio eh seguinte...
		// tem que calcular as composicoes da categoria origem! pra cada dupla
		// de morfismos componiveis, tem que mapear:
		// 	-> composicao (na categoria origem -> compor  e levar)
		// 	-> morfismos e compor na categoria destino (levar e compor)
		//
		// 	* o resultado deve ser o mesmo*

		for (int i=0; i< morfismosOrigem.size(); i++)
		{
			m1Origem= (Morfismo) morfismosOrigem.get (i);

			for (int j=0; j< morfismosOrigem.size(); j++)
			{
				m2Origem= (Morfismo) morfismosOrigem.get (j);

				if ( m1Origem.destino.equals( m2Origem.origem ) && !m1Origem.id && !m2Origem.id )
				{
					// destino da primeira eh origem da segunda!

					composicaoOrigem = procuraComp (cat1, m2Origem.morfismo, m1Origem.morfismo); // volta um morph

					// procura a composicaoOrigem no
					// funtor pra saber onde vai levar na
					// categoria2


					compoeMapeia= procuraCorrespondenteMorEmFuntor ( composicaoOrigem );

					// agora mapeia primerio e compoe
					// depois

					m1Destino= procuraCorrespondenteMorEmFuntor ( m1Origem.morfismo );
					m2Destino= procuraCorrespondenteMorEmFuntor ( m2Origem.morfismo );

					if ( !m1Destino.id && !m2Destino.id )
					{

						mapeiaCompoe = procuraComp (cat2, m2Destino.morfismo, m1Destino.morfismo);

						if (! mapeiaCompoe.equals ( compoeMapeia.morfismo ) ) throw new CatExcept("N�o preservou a composi��o de "+m1Origem.morfismo+" com "+m2Origem.morfismo);
					}
				}
			}
		}
	}

	public String procuraComp ( Categoria cat, String g, String f )
	{

		Vector composicoes = cat.getComp ();
		Composicao c;

		for (int i=0; i < composicoes.size(); i++)
		{
			c = (Composicao) composicoes.get(i);
			if ( c.morfG.equals(g) && c.morfF.equals(f) )
				return c.morfH;
		}
		return null;
	}

	public int procuraMorEmFuntor (String qualMorfismo)
	{
		String temp;
		int count=0;

		for (int i=0; i< myFunctor.getMorOrigem().size(); i++)
		{
			temp = (String) myFunctor.getMorOrigem().get(i);

			if (qualMorfismo.equals (temp) ) count++;
		}

		return count;  // ou nao tah definido ou tah definido mais de uma vez
	}

	public boolean procuraObjEmFuntor (String qualObj)
	{
		// procura objeto na classe funtor! ve quantas vezes tah definido lah!
		String temp;
		int count=0;

		for (int i=0; i< myFunctor.getObjOrigem().size() ; i++)
		{
			temp = (String) myFunctor.getObjOrigem().get(i);

			if (qualObj.equals ( temp ) ) count++;

		}

		if (count != 1) return false;  // ou nao tah definido ou tah definido mais de uma vez

		return true;
	}
}
