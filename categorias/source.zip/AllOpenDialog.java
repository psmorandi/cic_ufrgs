//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo AllOpenDialog.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Di�logo que mostra todos os funtores e todas as categorias abertas at� o momento.
// - Somente categorias e funtores v�lidos s�o mantidos abertos.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

public class AllOpenDialog {

	public AllOpenDialog( Hashtable cat, Hashtable funtor )
	{
		JComboBox possibleCat = new JComboBox();
		JComboBox possibleFun = new JComboBox();
		Set categorias = cat.keySet();
		Set funtores = funtor.keySet();
		Iterator it = categorias.iterator();
		while( it.hasNext() )
			possibleCat.addItem( (String) it.next());
		it = funtores.iterator();
		while( it.hasNext() )
			possibleFun.addItem( (String) it.next());

		Object[] message = new Object[4];
		message[0] = "Categorias abertas at� o momento:";
		if (cat.size() > 0)
			message[1] = possibleCat;
		else
			message[1] = "Nenhuma Categoria aberta at� o momento!!!!";
		message[2] = "Funtores abertos at� o momento:";
		if (funtor.size() > 0)
			message[3] = possibleFun;
		else
			message[3] = "Nenhum Funtor aberto at� o momento!!!!";
		JOptionPane.showOptionDialog(null, message, "Categorias e Funtores...",
				JOptionPane.DEFAULT_OPTION,
				JOptionPane.INFORMATION_MESSAGE,
				null, null, null);
	}
}

class SubCatDialog
{
	private Hashtable todasCat;
	private String catMaior, catMenor;
	
	public SubCatDialog( Hashtable c )
	{
		todasCat = c;
		if (todasCat.size() < 1 ) 
			JOptionPane.showMessageDialog(null,"Erro!! Nenhuma Categoria aberta!!!","ERROR",
 				JOptionPane.ERROR_MESSAGE);
		else
		{
			String[] possibleValues = new String[todasCat.size()];
			Set categorias = todasCat.keySet();
			Iterator it = categorias.iterator();
			int i = 0;

			while( it.hasNext() ) 
			{
				possibleValues[i] = (String) it.next();
				i++;				
     			}

			Object selectedCat = JOptionPane.showInputDialog(null,
						"Escolha a Categoria Maior:", "Categoria Maior", JOptionPane.INFORMATION_MESSAGE, null,
						possibleValues, possibleValues[0]);
			if ( selectedCat != null )
			{
				catMaior = (String)selectedCat;
				Object selectedSub = JOptionPane.showInputDialog(null,
					"Categoria Maior selecionada: "+selectedCat+"\nEscolha a SubCategoria:", "SubCategoria", JOptionPane.INFORMATION_MESSAGE, null,
					possibleValues, possibleValues[0]);
				if ( selectedSub != null )
					catMenor = (String)selectedSub;
				else
					catMaior = catMenor = null;
			}
			else
				catMaior = catMenor = null;
		}
	}

	public String getCatMaior()
	{
		return catMaior;
	}
	
	public String getCatMenor()
	{
		return catMenor;
	}

}

class ComporFuntorDialog {

	private String funtor1, funtor2;

	ComporFuntorDialog( Hashtable funtor )
	{
		if (funtor.size() < 1 ) 
			JOptionPane.showMessageDialog(null,"Erro!! Nenhum Funtor aberto!!!","ERROR",
 				JOptionPane.ERROR_MESSAGE);
		else
		{
			String[] possibleValues = new String[funtor.size()];
			Set funtores = funtor.keySet();
			Iterator it = funtores.iterator();
			int i = 0;

			while( it.hasNext() ) 
			{
				possibleValues[i] = (String) it.next();
				i++;				
     			}

			Object selectedF1 = JOptionPane.showInputDialog(null,
						"Funtor 1:", "Compondo Funtor 1 com Funtor 2...", JOptionPane.INFORMATION_MESSAGE, null,
						possibleValues, possibleValues[0]);
			if ( selectedF1 != null )
			{
				funtor1 = (String)selectedF1;
				Object selectedF2 = JOptionPane.showInputDialog(null,
					"Funtor 1: "+selectedF1+"\nFuntor 2:", "Compondo Funtor 1 com Funtor 2...", JOptionPane.INFORMATION_MESSAGE, null,
					possibleValues, possibleValues[0]);
				if ( selectedF2 != null )
					funtor2 = (String)selectedF2;
				else
					funtor1 = funtor2 = null;
			}
			else
				funtor1 = funtor2 = null;
		}
	}

	public String getFuntor1()
	{
		return funtor1;
	}
	public String getFuntor2()
	{
		return funtor2;
	}
}
