//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Composicao.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Arquivo de defini��o de Composi��o.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

public class Composicao {
	String morfH;
	String morfG;
	String morfF;

	public String toString()
	{
		return "composicao:  h " + morfH + " g: " + morfG + " f: " + morfF + "\n";

	}
}

