//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Morfismo.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Tabela que armazena os morfismos.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

public class Morfismo {
		public String origem;	//Origem
		public String destino;	//Destino
		public String morfismo;	//Nome do morfismo
		public boolean id;

		public String toString()
		{
			return "morfismo " + morfismo + " origem: " + origem + " destino: " + destino + "\n";
	//		return "d0("+morfismo+") = "+origem+"\nd1("+morfismo+") = "+destino+"\n";
		}
	}
