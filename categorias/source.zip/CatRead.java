//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo CatRead.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Leitura do arquivo de Categoria.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.lang.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class CatRead {
	private Categoria cat;

public CatRead( BufferedReader arq, JTextArea t )
{
	StringTokenizer morf, comp;      //morf => para morfismo; comp => para composi��es
	String nomeCat, line, nomeMorf;  //Coisas auxiliares autoexplicativas....
	HashSet morfismos;    //Guarda todos os morfismos;
	Morfismo tabelaMorf;  //Nome, origem, destino, identidade? true : false;
	Composicao composicao;
	int numeroTokens;


	line = null;
	morfismos = new HashSet();
	tabelaMorf = new Morfismo();

	do
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
 				JOptionPane.ERROR_MESSAGE);
		}
		if ( line == null )
			JOptionPane.showMessageDialog(null,"Erro!!","ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
	} while (line.trim().equals(""));

	nomeCat = new String(line.trim());
	if ( nomeCat.substring(0,1).equals("<") && nomeCat.substring(nomeCat.length()-1,nomeCat.length()).equals(">") )
	{
		nomeCat = nomeCat.substring(1,nomeCat.length()-1);
	}

	cat = new Categoria( nomeCat );

	t.append("\n..::Categoria "+nomeCat+"::..\n\n");
	t.append(nomeCat+" = < Obj"+nomeCat+", Mor"+nomeCat+", d0, d1, i, o >\n");

	//Nesse while removemos os espa�os em branco e o identificador de obj at� chegar no '{'
	while( !line.trim().equals("{") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	//Nesse while inserimos todos os objetos at� chegar no '}'
	while( !line.trim().equals("}") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
		line = line.trim();
		if ( !line.equals("") && !line.equals("}") )
		{
			//AQUI VC ADICIONA OS OBJETOS
			cat.adicionaObj(line.trim());
		}
	}


	t.append("Obj"+nomeCat+" = "+cat.objToString()+";\n");

	//==================================
	// Leitura dos Morfimos
	//==================================
	//
	//Nesse while removemos os espa�os em branco e o identificador de morf at� chegar no '{'
	while( !line.trim().equals("{") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	//Nesse while inserimos todos os morfismos at� chegar no '}'
	while( !line.trim().equals("}") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}

		morf = new StringTokenizer( line );

		numeroTokens = morf.countTokens();
		Morfismo m;
		String flag;

		m = new Morfismo(); // aloca um *novo* morfismo

		if ( numeroTokens > 3 )
		{
	     		while( morf.hasMoreTokens() )
			{

				flag = morf.nextToken();
				
				nomeMorf = morf.nextToken();
 				morfismos.add(nomeMorf);
				m.morfismo = nomeMorf;
				m.origem = morf.nextToken();
				m.destino = morf.nextToken();

        		if( flag.equals("*") )
				{
					//Adiciona IDENTIDADES
					m.id = true;
				}
				else
				{
					//MORFISMOS NORMAIS
					tabelaMorf.id = false;				
				}				
     		}//while morf

			cat.adicionaMor( m );
		}//if
	}//while line.trim


	t.append("Mor"+nomeCat+" = "+morfismos.toString()+";\n");

	//==================================
	// Leitura das Composi��es
	//==================================
	//
	//Nesse while removemos os espa�os em branco e o identificador de Comp at� chegar no '{'
	while( !line.trim().equals("{") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	//Nesse while inserimos todas as Composi��es at� chegar no '}'
	while( !line.trim().equals("}") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
		
		line = line.trim();

		if (!line.equals("}") && !line.equals(""))
		{
			

			comp = new StringTokenizer( line );
			numeroTokens = comp.countTokens();
			
			String morfF;
			String morfG;
			String morfH;

			composicao = new Composicao(); // aloca um *nova* composicao
			
	     	while( comp.hasMoreTokens() )
			{				

				composicao.morfH= comp.nextToken();				
				composicao.morfG= comp.nextToken();
				composicao.morfF= comp.nextToken();
						
			}

			cat.adicionaComp( composicao );
		}
	}//while line.trim
}// do Construtor

public Categoria returnCat () {
	// marcelo�s Code
	return cat;
}


}
