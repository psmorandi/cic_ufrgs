//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo MorfismoFuntor.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Defini��o dos morfismos lidos do arquivo.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.util.*;

public class MorfismoFuntor
{
	public String morf;
	public String imagemMorf;
}