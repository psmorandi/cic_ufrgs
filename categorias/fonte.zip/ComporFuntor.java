
import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

public class ComporFuntor 
{
	private Funtor funtorOrigem;
	private Funtor funtorDestino;
	private static String debug = "COMPORFUNTOR: ";
	private Funtor resultadoComp;
	
	public ComporFuntor( Funtor f1, Funtor f2 )
	{
		funtorOrigem = f1;
		funtorDestino = f2;
		resultadoComp = null;
	}

	public Funtor compor()	
	{
		if ( ehComponivel( funtorOrigem, funtorDestino ) )
		{
			Funtor f = new Funtor( funtorDestino.getNome()+"_"+funtorOrigem.getNome() );

			//Origem da composicao (f2_f1): origem do funtor origem (f1)!
			//Destino da composicao: destino do funtor destino (f2)!
			//A, B, C s�o categorias!
			//f1: A->B e f2: B->C, entaum f2_f1 = A->C
			f.setFuntorCatOrg( funtorOrigem.getStringCatOrigem() );
			f.setFuntorCatDest( funtorDestino.getStringCatDestino() );
			Vector objetosDoFuntorOrigem = funtorOrigem.getFuntorObj();
			Vector morfismosDoFuntorOrigem = funtorOrigem.getFuntorMorf();

			//Para todos os objetos da origem procurar a correspondente imagem da imagem do funtor destino...
			//.......???????????......t� vo tentar explicar melhor...
			//Seja f1 o funtor origem e f2 o funtor destino do exemplo acima,
			//digamos que f1 mapeia o objeto A em B, ou seja, A pertence a categoria origem de f1 e B pertence
			//a categoria origem de f2. Logo, devemos achar a imagem de B na categoria destino que pertence a B,
			//digamos B mapeia para C, entao na composicao: f2_f1 ==> o objeto A ser� mapeado para o objeto C.
			//Nesse caso A pertence a categoria Origem do funtor f1 e C pertence a categoria destino do funtor f2
			//.....est� claro...???,......
			for (int i=0; i<objetosDoFuntorOrigem.size(); i++)
			{
				ObjetoFuntor objeto1 = (ObjetoFuntor)objetosDoFuntorOrigem.elementAt(i);
				ObjetoFuntor objeto2 = procuraImagemDaImagemObjeto(objeto1.imagemObj,funtorDestino);
				if (objeto2 != null)
				{
					ObjetoFuntor novo = new ObjetoFuntor();
					novo.obj = objeto1.obj;
					novo.imagemObj = objeto2.imagemObj;
					f.adicionaFuntorObj( novo );
				}
				else
					return null;
			}

			for(int i=0; i<morfismosDoFuntorOrigem.size(); i++)
			{
				MorfismoFuntor morf1 = (MorfismoFuntor)morfismosDoFuntorOrigem.elementAt(i);
				MorfismoFuntor morf2 = procuraImagemDaImagemMorfismo(morf1.imagemMorf,funtorDestino);
				if ( morf2 != null )
				{
					MorfismoFuntor novo = new MorfismoFuntor();
					novo.morf = morf1.morf;
					novo.imagemMorf = morf2.imagemMorf;
					f.adicionaFuntorMor( novo );
				}
				else
					return null;
			}
			resultadoComp = f;

			return f;
		}
		
		return null;
	}

	//procura em f2 a imagem do objeto o e retorna essa imagem;
	private ObjetoFuntor procuraImagemDaImagemObjeto( String o, Funtor f2 )
	{
		Vector objetos = f2.getFuntorObj(); //Pega as estruturas ObjetoFuntor armazenadas em f2

		for(int i=0;i<objetos.size();i++ )
		{
			ObjetoFuntor obj2 = (ObjetoFuntor)objetos.elementAt(i);
			if ( o.equals( obj2.obj ) )
			{
				return obj2;
			}
		}

		return null;
	}

	//procura em f2 a imagem do morfismo m e retorna essa imagem
	private MorfismoFuntor procuraImagemDaImagemMorfismo( String m, Funtor f2 )
	{
		Vector morfismos = f2.getFuntorMorf(); //Pega as estruturas MorfismoFuntor armazenadas em f2

		for(int i=0;i<morfismos.size();i++ )
		{
			MorfismoFuntor morf2 = (MorfismoFuntor)morfismos.elementAt(i);
			if ( m.equals( morf2.morf ) )
			{
				return morf2;
			}
		}

		return null;
	}

	private boolean ehComponivel( Funtor origem, Funtor destino )
	{
		//nome da categoria destino do funtor origem == nome da categoria origem do funtor destino!!!
		if ( origem.getStringCatDestino().equals( destino.getStringCatOrigem() ) )
		{
			return true;
		}
		return false;
	}

	//Mostra em t o resultado da Composicao...
	public void resultadoDaComposicao( JTextArea t )
	{
		t.append("Resultado da Composicao de "+funtorOrigem.getNome()+" com "+funtorDestino.getNome()+":\n");
		t.append("Nome do Funtor resultante: <"+resultadoComp.getNome()+">\n");
		t.append("Categoria Origem: <"+resultadoComp.getStringCatOrigem()+">\n");
		t.append("Categoria Destino: <"+resultadoComp.getStringCatDestino()+">\n");
		t.append("Obj\n{\n");
		Vector objetos = resultadoComp.getFuntorObj();
		for (int i=0;i<objetos.size();i++)
		{
			ObjetoFuntor o = (ObjetoFuntor)objetos.elementAt(i);
			t.append(o.obj+" "+o.imagemObj+"\n");
		}
		t.append("}\n");
		t.append("Morf\n{\n");
		Vector morfismos = resultadoComp.getFuntorMorf();
		for (int i=0;i<morfismos.size();i++)
		{
			MorfismoFuntor m = (MorfismoFuntor)morfismos.elementAt(i);
			t.append(m.morf+" "+m.imagemMorf+"\n");
		}
		t.append("}\n");

	}
}
