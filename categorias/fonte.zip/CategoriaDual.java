//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Categoria.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Calculo da categoria DUAL.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

//------------------------------
// Padr�es adotados:
// - Objetos: Letras mai�scula;
// - Setas: Letras Min�sculas;
//------------------------------
public class CategoriaDual {

	private String nomeCat;
	private HashSet obj;		//Armazena os objetos da Categoria;
	private Vector comp;		//Armazena as composi��es da Categoria;
	private Vector tabMor;		//Tabela de Morfismos;


	public Categoria categoriaDual( Categoria cat )
	{
		nomeCat = new String( cat.getNome()+"<OP>" );
		Categoria catDual = new Categoria( nomeCat );
		
		catDual.adicionaObj( cat.getObj() );

		tabMor = new Vector();
		Vector morfismos = cat.getTabMor();

		for(int i=0; i<morfismos.size(); i++)
		{
			Morfismo f = (Morfismo)morfismos.elementAt(i);
			Morfismo dualf = new Morfismo();

			dualf.morfismo = f.morfismo;
			dualf.origem = f.destino;
			dualf.destino = f.origem;
			dualf.id = f.id;
			tabMor.add(dualf);
		}

		catDual.adicionaMor( tabMor );

		Vector composicao = cat.getComp();
		comp = new Vector();

		for(int i=0; i<composicao.size(); i++)
		{
			Composicao c = (Composicao)composicao.elementAt(i);
			Composicao dualc = new Composicao();

			dualc.morfH = c.morfH;
			dualc.morfG = c.morfF;
			dualc.morfF = c.morfG;
			comp.add(dualc);
		}

		catDual.adicionaComp( comp );

		return catDual;
	}

	public Vector getMorfismos () {
		return tabMor;
	}

	public HashSet getObjetos () {
		return obj;
	}

	public Vector getComposicoes () {
		return comp;
	}

	public String getNome()
	{
		return nomeCat;
	}

	public void resultadoDaDual()
	{
		System.out.println("..:: Categoria "+nomeCat+"::..");
		System.out.println("Obj\n{");
		System.out.println(obj);
		System.out.println("}");
		System.out.println("Morf\n{");
		for(int i=0; i<tabMor.size(); i++)
		{
			System.out.println((Morfismo)tabMor.elementAt(i));
		}
		System.out.println("}");
		
		System.out.println("Comp\n{ ");
		for(int i=0; i<comp.size(); i++)
		{

			System.out.println((Composicao)comp.elementAt(i));
		}
		System.out.println("}");
	}
}
