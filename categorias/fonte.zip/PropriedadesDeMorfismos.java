import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class PropriedadesDeMorfismos
{

	private	Categoria cat;
	private Vector myMorphisms;
	private	HashSet myObjects;
	private	Vector myComp;
	private JTextArea t;

	public PropriedadesDeMorfismos (Categoria categoria, JTextArea tt)
	{
		//by PsMj.... just for messages...
		t = tt;

		cat = categoria;

		myMorphisms = cat.getTabMor();
		myObjects = cat.getObj();
		myComp = cat.getComp();
	}

	private boolean ehMono( Morfismo f )
	{
		Vector quemChega;
		String origemDoMorfismo;
		String comp1, comp2;
		Morfismo mj, mk;

		boolean eh = true;  // soh pra debugar! favor tirar essas vari�vel depois

		quemChega = new Vector ();
		

		origemDoMorfismo = f.origem;

		
		// esse vetor tem todos os morfismos cujo destino eh a origem do morfismo apontado por 'i'
		quemChega = morfismosQueChegamNoObjeto ( origemDoMorfismo );
		eh=true;

		for (int j=0; j< quemChega.size(); j++)
		{
			mj = (Morfismo) quemChega.get(j);

			comp1 = procuraComp (mj, f);

			for (int k=0; k< quemChega.size() ; k++)
			{
				if (j != k)
				{       // ISSO (esse if) TAH ERRADO!!!!!!!!!!!!!!!!!!!!!!!!!
					// a categoria xor vai dar pau
					mk = (Morfismo) quemChega.get(k);

					comp2 = procuraComp (mk, f);		
				
					if ( comp2 != null && comp1 != null )
					{
						if (comp1.equals (comp2) && (eh))
						{
							eh = false;
						}
					}
				}
			}
		}

		return eh;
	}

	public void quemEhMono ( String ehMonoOuEhEpi )
	{

		Morfismo m1;

		t.append("\n..::Procurando Todos os "+ehMonoOuEhEpi+" da Categoria "+cat.getNome()+"::..\n");

		for (int i=0; i< myMorphisms.size(); i++) // para todo morfismo
		{
			m1= (Morfismo) myMorphisms.get(i);

			if ( ehMono( m1 ) )
				t.append("Morfismo " + m1.morfismo + " � um "+ehMonoOuEhEpi+"\n");
			else
				t.append("Morfismo " + m1.morfismo + " n�o � um "+ehMonoOuEhEpi+"\n");

		}
		t.append("------------------------------------------------------------------\n\n");
	}

		public void quemEhIso ()
	{

		Morfismo m1;


		t.append("..::Procurando Todos os ISOMORFISMOS da Categoria "+cat.getNome()+"::..\n");
		for (int i=0; i< myMorphisms.size(); i++) // para todo morfismo
		{
			m1= (Morfismo) myMorphisms.get(i);

			if ( ehIso( m1 ) )
				t.append("Morfismo " + m1.morfismo + " � um ISOMORFISMO\n");
		//		System.out.println ("Morfismo " + m1.morfismo + " � um ISOMORFISMO\n");
			else
				t.append("Morfismo " + m1.morfismo + " N�O � um ISOMORFISMO\n");
				//System.out.println ("Morfismo " + m1.morfismo + " n�o � um ISOMORFISMO\n");

		}
		t.append("-----------------------------------------------------\n");


	}

	private boolean ehIso (Morfismo m)
	{
		String origemDeM = m.origem;
		String destinoDeM = m.destino;

		Morfismo identidadeA=null;
		Morfismo identidadeB=null;

		String comp1;
		String comp2;

		Vector morfismosBtoA = morfismosEntreObjetos (destinoDeM, origemDeM);

		// procura identidade do objeto origem e destino do morfismo m

		identidadeA = procuraIdentidade ( origemDeM );
		identidadeB = procuraIdentidade ( destinoDeM );

		Morfismo m2;

		for (int j=0; j< morfismosBtoA.size(); j++)
		{
			m2 = (Morfismo) morfismosBtoA.get (j);

			comp1 =  procuraComp ( m, m2 );
			comp2 =  procuraComp ( m2, m );

			if ((comp1 != null) && (comp2 != null))
			{
				if ((identidadeA.morfismo.equals(comp1 )  ) &&
				    (identidadeB.morfismo.equals(comp2 )  )    )
				{
					return true; //se mais de um naum descomente....
				}
			}
		}
		return false; //idem do laco acima...
	}

	public Morfismo procuraIdentidade (String qualObj)
	{
		Morfismo myMorphism;
		Vector v;

		v= (Vector) cat.getTabMor();

		// verifica todos os morfismos
		for (int i=0; i< cat.getTabMor().size(); i++) {
			myMorphism= (Morfismo) v.get (i);
			if ((myMorphism.id) && ( myMorphism.origem.equals( qualObj) )
					    && ( myMorphism.destino.equals (qualObj ) ))
				return myMorphism;
		}

		return null;  // objeto nao tem identidade!
	}

	public void quemEhEpi ()
	{

		Categoria dual = cat.categoriaDual();

		dual.setNome(cat.getNome());
		PropriedadesDeMorfismos p = new PropriedadesDeMorfismos( dual, t );

		p.quemEhMono ( "EPIMORFISMOS" );

	}

	public Vector objetosIniciais ()
	{
		// ps

		Vector objIniciais = new Vector();
		Vector todosObjetos = new Vector(); //Por que a porcaria do Iterator aponta SEMPRE pra
							//mesma c�pia do hashset na mem�ria... logo
							//naum dah pra fazer for's aninhados com essa
							// #$@#$%#$#$#$%@#$%#$!$%#$%rda....

		//Para todos os objetos da categoria...
		Iterator it = cat.getObj().iterator();
		for( int i=0; i<cat.getObj().size(); i++ )
		{
			todosObjetos.add((String) it.next());
		}

		//Para todos os objetos da categoria...
		for( int i=0; i<todosObjetos.size(); i++ )
		{
			String obj = (String) todosObjetos.get(i); //Candidato a obj inicial...
			boolean achouMaisDeUmMorfismo = false;
			boolean naumAchouMorfismo = false; //Eh redundante mais fica mais claro...
							   //ou naum....

			for(  int j=0; j<todosObjetos.size(); j++  )
			{

				String obj2 = (String) todosObjetos.get(j);

//				System.out.println("Procurando Morfimsos entre: "+obj+" ---> "+obj2+"\n");
				Vector morfismosEntre = morfismosEntreObjetos(obj,obj2);

				if ( morfismosEntre.size() > 1 )
				{
					achouMaisDeUmMorfismo = true;
					//...Achou mais de uma seta entre obj e obj2..
//					System.out.println("Achou mais de um morfismo");

				}
				if ( morfismosEntre.size() == 0 )
				{
					naumAchouMorfismo = true;
					//...N�o achou uma seta entre obj e obj2...
//					System.out.println("N�o achou um morfismo");
				}

			}

			//...se n�o achou mais de um morfimos e a categoria possui uma seta para todos
			// os outros objetos...
			if ( !achouMaisDeUmMorfismo && !naumAchouMorfismo )
			{
				//... ent�o � objeto inicial
				objIniciais.add( obj );
			}
		}

		return objIniciais;

	}

	public Vector objetosTerminais()
	{

	// ps
		Categoria dual = cat.categoriaDual();
		dual.setNome(cat.getNome());

		PropriedadesDeMorfismos p = new PropriedadesDeMorfismos(dual, t);
		return p.objetosIniciais ();
	}

	public Vector objetosZero ()
	{
		MyVector intersect = new MyVector();
		return intersect.and(objetosIniciais(),objetosTerminais());
	}

	public String procuraComp ( Morfismo m1, Morfismo m2 )
	{
		String g, f;

		f= m1.morfismo;
		g= m2.morfismo;

		if (m1.id) return (m2.morfismo);
		if (m2.id) return (m1.morfismo);

		Vector composicoes = cat.getComp ();
		Composicao c;

		for (int i=0; i < composicoes.size(); i++)
		{
			c = (Composicao) composicoes.get(i);
			if ( c.morfG.equals(g) && c.morfF.equals(f) )
			{
				return c.morfH;
			}
		}
		return null;
	}

	public Vector morfismosQueChegamNoObjeto ( String chegaOnde )
	{
		Vector v = new Vector ();
		Morfismo m;

		for (int i=0; i<myMorphisms.size(); i++)
		{
			m = (Morfismo) myMorphisms.get(i);

			if (chegaOnde.equals (m.destino) ) v.add (m);
		}

		return v;
	}


	public Vector morfismosEntreObjetos ( String origem, String destino )
	{
		Vector v = new Vector ();
		Morfismo m;

		for (int i=0; i<myMorphisms.size(); i++)
		{
			m = (Morfismo) myMorphisms.get(i);

			if (origem.equals (m.origem) && destino.equals (m.destino)  ) v.add (m);
		}

		return v;
	}


	public void equalizador( String morf1, String morf2, String eqoCoeqo )
	{
		//As vari�veis seguem a nomenclatura do livro p�g. 183....

		t.append("..::Calculando "+eqoCoeqo+" entre "+morf1+" e "+morf2+"::..\n");

		int counter = 0, naumTem = 0; //Unicidade da seta h

		Morfismo f = procuraMorfismo( morf1 );
		if (f == null)
		{
			t.append("Morfismo Inv�lido! "+morf1+" n�o pertence a categoria em quest�o!\n");
		}
		else
		{
			Morfismo g = procuraMorfismo( morf2 );
			if (g == null)
			{
				t.append("Morfismo Inv�lido! "+morf2+" n�o pertence a categoria "+
					"em quest�o!\n");
			}
			else
			{
				if ( !( f.origem.equals(g.origem) && f.destino.equals(g.destino) ) )
				t.append("Morfismos Inv�lidos para teste de "+eqoCoeqo+"! Os morfismos n�o s�o paralelos!!!\n");
				else
				{
					Vector preEqualizadores = procuraPreEqualizador( f, g );

					if ( preEqualizadores.size() == 1 )
						t.append(eqoCoeqo+" encontrado: "+
								 (PreEqualizador)preEqualizadores.get(0));
					else
					{

					for(int i=0; i<preEqualizadores.size(); i++ )
					{
						PreEqualizador P = (PreEqualizador)preEqualizadores.get(i);
						counter = 0; naumTem = 0;
						for(int j=0; j<preEqualizadores.size(); j++ )
						{

							if ( i!=j )
							{

								PreEqualizador K = (PreEqualizador)preEqualizadores.get(j);
								Vector m = morfismosEntreObjetos(K.objeto, P.objeto);

								if (m.size() != 0)
								{

								//Verifica se comuta... denovo....
								//Dentre todos os morfismos entre K e P, procura os que
								// comutam o tri�ngulo...(pg.183)
									for( int n=0; n<m.size(); n++ )
									{
										Morfismo p = P.morfismo;
										Morfismo k = K.morfismo;
										Morfismo h = (Morfismo)m.get(n);
										if ( comuta(k,h,p) )
										{
										//e comutar mais de uma vez n�o � produto...
											counter++;
										}
									}
								}
							}
						}

						if ( (counter == 1) ) //...se igual a 1 a seta � �NICA....
						{
							t.append(eqoCoeqo+" encontrado: "+P);
						}
						else
							t.append(eqoCoeqo+" N�O ENCONTRADO PARA: "+P);
					}
					}
				}
			}
		}
	}

	private Morfismo procuraMorfismo( String morf )
	{
		for( int i=0; i<myMorphisms.size(); i++ )
		{
			Morfismo m = (Morfismo) myMorphisms.get(i);
			if ( m.morfismo.equals(morf) )
			{
				return m;
			}
		}
		return null;
	}

	private Vector procuraPreEqualizador( Morfismo f, Morfismo g )
	{
		Vector tempPreEq = new Vector(); 

		//Procura candidatos a pre-equalizador que tenham destino na origem de f (ou g):
		for( int i=0; i<myMorphisms.size(); i++ )
		{
			Morfismo m = (Morfismo) myMorphisms.get(i);
			if ( m.destino.equals(f.origem) )
			{
				PreEqualizador p = new PreEqualizador();

				p.objeto = m.origem;
				p.morfismo = m;

				tempPreEq.add(p); 
			}
		}

		Vector preEq = new Vector();

		//...dos candidatos verifica aqueles que "comutam o diagrama"...
		for(int i=0; i<tempPreEq.size(); i++ )
		{
			PreEqualizador P = (PreEqualizador)tempPreEq.get(i);
			Morfismo p = P.morfismo;

			String FoP = procuraComp(p,f);
			if ( FoP != null )
			{
				String GoP = procuraComp(p,g);
				if ( GoP != null )
				{
					if( FoP.equals(GoP) )
					{
					//Se comuta o cone, ent�o � um PreEqualizador....
						PreEqualizador x = new PreEqualizador();
						x.objeto = p.origem;
						x.morfismo = p;
						preEq.add(x);
//						System.out.println("CANDIDATO EFETIVO A PREEQUALIZADOR: "+x);
					}
				}
			}
		}
		return preEq;
	}

	public void coEqualizador(  String morf1, String morf2 )
	{
		Categoria dual = cat.categoriaDual();
		dual.setNome(cat.getNome());

		PropriedadesDeMorfismos p = new PropriedadesDeMorfismos(dual, t);
		p.equalizador(morf1,morf2,"CO-EQUALIZADOR");
	}
 	public void produtoBinario (String obj1, String obj2, String title)
	{
		Vector preProduto = procuraPreProduto (obj1, obj2 );

		Vector v = new Vector ();

		PreProduto p1=null;
	        PreProduto p2=null;
		Morfismo m1, m2;

		Morfismo Pi_A, Pi_B;
		Morfismo r1, r2, inc;

		boolean eh=true;

		Vector morfismosQueComutam1, morfismosQueComutam2;

		t.append("\n\n..::Calculo do "+title+" entre "+obj1+" e "+obj2+"::..\n");

		// nomenclaturas... livro do Blauth, pagina 145

		for (int i=0; i< preProduto.size(); i++)  // produtos
		{
			eh=true;
			for (int j=0; j< preProduto.size(); j++)  // pre-produtos
			{  // compara com todos os outros pre-produtos!

				// todos os morfismos entre o preProduto e produto

				PreProduto asdf1, asdf2;

				asdf1 = (PreProduto) preProduto.get(j);
				asdf2 = (PreProduto) preProduto.get(i);

				v = morfismosEntreObjetos (
				    	       	asdf1.getObjeto(),
				    		asdf2.getObjeto()
				    );

				// para todos os morfismos preProduto -> produto ver quais
				// deles comutam!
				
				
				// lado esquerdo!

				p1 = (PreProduto) preProduto.get (j);
				r1 = p1.getM1(); // morfismo do preProduto pra obj1

				p2 = (PreProduto) preProduto.get (i);
				Pi_A = p2.getM1(); // morfismo do produto pra Obj1

				morfismosQueComutam1 = new Vector ();

				for (int k=0; k< v.size(); k++)
				{
					inc = (Morfismo)v.get(k);

					if ( comuta (r1, inc, Pi_A)  )
						morfismosQueComutam1.add ( inc );
				}

				// lado direito

				r2 = p1.getM2(); // morfismo do preProduto pra obj2

				Pi_B = p2.getM2(); // morfismo do produto pra Obj2

				morfismosQueComutam2 = new Vector ();

				for (int k=0; k< v.size(); k++)
				{
					inc = (Morfismo)v.get(k);
					if ( comuta (r2, inc, Pi_B)  )
						morfismosQueComutam2.add ( (Morfismo) v.get(k) );
				}

				// intersec��o dos morfismos que comutam!
				// Tem que ter exatamente um que fa�a os dois lados comutarem!

				Vector interseccao = new Vector ();
				MyVector tt = new MyVector ();

				interseccao = tt.and (morfismosQueComutam1, morfismosQueComutam2);



				if (interseccao.size() == 1)
				{
					//System.out.println("Foram encontradas = "+interseccao.size()+" intersecoes\n");
				}
				else
				{
					//System.out.println("Foram encontradas = "+interseccao+"\n");

					eh=false;
				}



			}
			if (eh)
			{
				t.append(title+" Encontrado: \n");
				t.append("Objeto = "+p2.getObjeto()+"\n");
				t.append("Morfismo de Proje��o 1 = "+p2.getM1());
				t.append("Morfismo de Proje��o 2 = "+p2.getM2());
			}
			else
				t.append(title+" N�O Encontrado!\n");

		}
		t.append("------------------------------------------------------------------\n\n");
	}

	public void coprodutoBinario( String obj1, String obj2 )
	{
		Categoria dual = cat.categoriaDual();
		PropriedadesDeMorfismos p = new PropriedadesDeMorfismos( dual, t );

		p.produtoBinario( obj1, obj2, "CO-PRODUTO BIN�RIO" );
	}

	public boolean comuta (Morfismo composta, Morfismo f, Morfismo g)
	{
		String m;

		m = procuraComp ( f, g );

		if (m == null) return false;

		if (m.equals (composta.morfismo) ) return true;
		else return false;
		
	}

	public Vector procuraPreProduto (String obj1, String obj2)
	{
		String myObject;

		Vector preProdutoVector = new Vector ();
		Vector setasPraObj1;
		Vector setasPraObj2;

		Iterator it = cat.getObj().iterator();
		myObject="";

		for (int i=0; i<cat.getObj().size(); i++)  // para todos os objetos
		{
			// ve todos os morfismos de 'i' pra obj1

			setasPraObj1 = new Vector ();
			setasPraObj2 = new Vector ();
			

			myObject = (String) it.next();
			
			setasPraObj1 = morfismosEntreObjetos (myObject, obj1 );
			setasPraObj2 = morfismosEntreObjetos (myObject, obj2 );				

			for (int j=0; j< setasPraObj1.size(); j++)
			{
				for (int k=0; k< setasPraObj2.size(); k++)
				{
					PreProduto myPreProduto = new PreProduto();

					myPreProduto.setObjeto (myObject);
					myPreProduto.setM1 ( (Morfismo) setasPraObj1.get(j) );
					myPreProduto.setM2 ( (Morfismo) setasPraObj2.get(k) );

					preProdutoVector.add ( myPreProduto );	
//					System.out.println ("myObject: " + myObject + "  M1: " + (Morfismo) setasPraObj1.get(j) + "   M2: " + (Morfismo) setasPraObj2.get(k) );
					//System.out.println ("preProdutoVector.add: " + myPreProduto + "\n");
				}
			}
		}

		return 	preProdutoVector;
	}
}
