import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MainWindowEvent extends WindowAdapter
{
	public void windowClosing( WindowEvent e )
	{
		System.exit(0);
	}

	public static final JMenu makeMenu( Object base, Object[] items, Object target)
	{
		JMenu m = null;

		if (base instanceof JMenu)
			m = (JMenu)base;
		else if (base instanceof String)
			m = new JMenu( (String)base );
		else return null;

		for(int i = 0; i < items.length; i++)
		{
			if ( items[i] instanceof String ){
				JMenuItem mi = new JMenuItem((String)items[i]);
				if ( target instanceof ActionListener )
					mi.addActionListener( (ActionListener)target);
				m.add(mi);
			} else if ( items[i] instanceof JCheckBoxMenuItem && target instanceof ItemListener ){
				JCheckBoxMenuItem cmi = (JCheckBoxMenuItem)items[i];
				cmi.addItemListener((ItemListener)target);
				m.add(cmi);
			} else if (items[i] instanceof JMenuItem) {
				JMenuItem mi = (JMenuItem)items[i];
				if ( target instanceof ActionListener )
					mi.addActionListener( (ActionListener)target);
				m.add(mi);
			} else if ( items[i] == null )
				m.addSeparator();			
		}
		return m;
	}
	
	static JMenuItem criaItem(String text, int mnemonic, KeyStroke accel)
	{
	        JMenuItem it = new JMenuItem(text, mnemonic);
	        it.setAccelerator(accel);
		return it;

	}

	static JMenuItem criaItem(String text, int mnemonic)
	{
	        return new JMenuItem(text, mnemonic);
	}

	static JMenuItem criaItem(String text)
	{
	        return new JMenuItem(text);
	}

	static JMenu criaMenu(String text, int mnemonic)
	{
	        JMenu m = new JMenu(text);
	        m.setMnemonic(mnemonic);
		return m;
	}
}
