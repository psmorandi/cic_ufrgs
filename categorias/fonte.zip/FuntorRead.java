//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo FuntorRead.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Leitura do arquivo de Funtor.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------
import java.io.*;
import java.lang.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class FuntorRead {
	private Funtor fun;

public FuntorRead( BufferedReader arq, JTextArea t ){
	StringTokenizer token;
	String line, nomeFuntor, catOrigem, catDestino; //Coisas auxiliares Auto-Explicativas 2 - O retorno...
	String classe = new String("CLASSE FUNTORREAD:: ");

	line = null;

	//Vai eliminar os espa�os em branco do in�cio do arquivo...
	do
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
 				JOptionPane.ERROR_MESSAGE);
		}
		if ( line == null )
			JOptionPane.showMessageDialog(null,"Erro!!","ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
	} while (line.trim().equals(""));

	nomeFuntor = new String(line.trim());
	nomeFuntor = nomeFuntor.substring(1,nomeFuntor.length()-1);
	fun = new Funtor( nomeFuntor );


	t.append("\n..::Funtor "+nomeFuntor+"::..\n\n");

	//Vai eliminar os espa�os em branco depois do nome do funtor...
	do
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
 				JOptionPane.ERROR_MESSAGE);
		}
		if ( line == null )
			JOptionPane.showMessageDialog(null,"Erro!!","ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
	} while (line.trim().equals(""));

	token = new StringTokenizer( line );
	catOrigem = token.nextToken();
	catDestino = token.nextToken();

	fun.setFuntorCatOrg( catOrigem );
	fun.setFuntorCatDest( catDestino );

	//Nesse while removemos os espa�os em branco e o identificador de obj at� chegar no '{'

	t.append(nomeFuntor+" = < fo, fm >\n");
	t.append("Categoria Origem  : "+fun.getStringCatOrigem()+"\n");
	t.append("Categoria Destino : "+fun.getStringCatDestino()+"\n");
	while( !line.trim().equals("{") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	//Nesse while inserimos todos os objetos at� chegar no '}'
	while( !line.trim().equals("}") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
		line = line.trim();
		if ( !line.equals("}") && !line.equals("") )
		{
			token = new StringTokenizer( line );
			ObjetoFuntor f = new ObjetoFuntor();
			f.obj = token.nextToken(); f.imagemObj = token.nextToken();
			fun.adicionaFuntorObj( f );
		}
	}

	//==================================
	// Leitura dos Morfimos
	//==================================
	//
	//Nesse while removemos os espa�os em branco e o identificador de morf at� chegar no '{'
	while( !line.trim().equals("{") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	//Nesse while inserimos todos os morfismos at� chegar no '}'
	while( !line.trim().equals("}") )
	{
		try
		{
			line = arq.readLine();
		}
		catch (IOException e )
		{
			JOptionPane.showMessageDialog(null,"Erro: " + e.getMessage(),"ERROR UNDER READING THE FILE",
				JOptionPane.ERROR_MESSAGE);
		}
		
		line = line.trim();

		if ( !line.equals("}") && !line.equals("") )
		{
			token = new StringTokenizer( line );
			MorfismoFuntor f = new MorfismoFuntor();
			f.morf = token.nextToken();
			f.imagemMorf = token.nextToken();
			fun.adicionaFuntorMor( f );
		}
	}//while line.trim
}// do Construtor

public Funtor returnFuntor ()
{
	return fun;
}

}
