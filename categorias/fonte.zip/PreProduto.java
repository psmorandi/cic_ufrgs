//Tabela que armazena os preProdutos
public class PreProduto
{
	private String objeto;	//Origem
	private Morfismo m1;
	private Morfismo m2;

	public String getObjeto ()
	{
		return objeto;
	}

	public Morfismo getM1()
	{
		return m1;
	}

	public Morfismo getM2()
	{
		return m2;
	}	

	public void setObjeto (String x)
	{
		objeto = x;
	}

	public void setM1 (Morfismo x)
	{
		m1=x;
	}

	public void setM2 (Morfismo x)
	{
		m2=x;
	}

	public String toString ()
	{
		return ("Objeto: " + objeto + "\nm1: " + m1 + "\nm2: " + m2 + "\n");
	}

}
