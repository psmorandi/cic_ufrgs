//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo TestaSubCategoria.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
//- Testa se entre duas categorias abertas se � Subcategoria;
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.util.*;

public class TestaSubCategoria 
{
	private Categoria maior, menor;

	
		
	public TestaSubCategoria (Categoria me, Categoria ma) 	
	{		
		// me: menor
		// ma: maior
		maior= ma;
		menor= me;		
	}	

	public boolean testa ( ) 
	{
		// testa se menor eh subcategoria de maior	

		if (!testaObjetos () ) return (false);

		if (!testaMorfismos () ) return (false);

		return (true);
		
	}

	public boolean testaObjetos ()
	{
		HashSet objetosMenor = menor.getObj();
		HashSet objetosMaior = maior.getObj();

		Iterator itMenor = objetosMenor.iterator ();
		//Iterator itMaior = new objetosMaior.iterator ();

		String objMenor, objMaior;
		boolean achou = false;

		for (int i=0; i < objetosMenor.size(); i++) 
		{ 			
			objMenor= (String)itMenor.next ();

			if (!objetosMaior.contains ( objMenor ) ) return (false);			
		} // se continua eh pq a class maior tem todos os objetos da menor

		return (true);
	}
	
	public boolean testaMorfismos ()
	{
		Vector tabMorMenor = menor.getTabMor ();
		Vector tabMorMaior = maior.getTabMor ();

		Morfismo morMenor;
		Morfismo morMaior;
		int indiceMaior;
		
		for ( int i=0; i< tabMorMenor.size (); i++ )
		{
			morMenor = (Morfismo) tabMorMenor.get (i);
			
			indiceMaior = indexOf (morMenor.morfismo);
			if (indiceMaior == -1) return (false);

			morMaior = (Morfismo)tabMorMaior.elementAt(indiceMaior);

			if (!morMaior.origem.equals (morMenor.origem) ) return (false);

			if (!morMaior.destino.equals (morMenor.destino) ) return (false);
			
		}

		return true;
	}

	public int indexOf (String morfismo)
	{
		Vector tabMorMaior = maior.getTabMor ();
		Morfismo morMaior;

		tabMorMaior = maior.getTabMor ();
		
		for (int i=0; i< tabMorMaior.size () ; i++) 
		{
			morMaior = (Morfismo) tabMorMaior.get (i);
			if (morfismo.equals ( morMaior.morfismo )) return i;
		}

		return -1;
	}

	//===========
	// Considerando que jah saum subCat
	//
	public boolean ehLarga()
	{
		HashSet objMaior = maior.getObj();
		HashSet objMenor = menor.getObj();

		if ( objMaior.size() == objMenor.size() )
			return true;

		return false;
	}

	public boolean ehPlena()
	{
		HashSet objMaior = maior.getObj();
		HashSet objMenor = menor.getObj();

		Iterator itMenor = menor.getObj().iterator();
		Iterator itMaior;
		
		Vector morMaior = maior.getTabMor();
		Vector morMenor = menor.getTabMor();

		String menorString;
		String maiorString;

		Morfismo horaDeMorfar;




		for (int i=0; i<objMenor.size(); i++)
		{
			// para todos os objetos do menor ...
			menorString= (String) itMenor.next();


			
			itMaior = maior.getObj().iterator();

			for (int j=0; j< objMaior.size (); j++)
			{
				// ... ve os morfismos destes mesmos objetos na categoria maior
				maiorString= (String) itMaior.next();

				if (maiorString.equals (menorString) ) // ve se eh o mesmo obj
				{					
					for (int k=0; k< morMaior.size (); k++) 
					{
						horaDeMorfar = (Morfismo) morMaior.get (k);
						if (horaDeMorfar.origem.equals (maiorString))
							if (!temEsseMorfismo ( horaDeMorfar ) ) return false;
					}

				}
								

			}			
		}
		return true;
	}

	public boolean temEsseMorfismo ( Morfismo m ) 
	{
		Vector morMenor = menor.getTabMor ();
		Morfismo mMenor;
		HashSet objMenor = menor.getObj();

		if (objMenor.contains ( m.destino ) ) 
		{
			for (int i=0; i < morMenor.size (); i++) 
			{
				mMenor = (Morfismo) morMenor.get (i);
				if ( mMenor.morfismo.equals (m.morfismo) )  return true;
			}
		}
		else 
		{
			// nao tem o objeto! volta verdadeiro
			return true;

		}

		return false;
	}
}
