//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo OjetoFuntor.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Tabela que armazena os morfismos do funtor.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.util.*;

public class ObjetoFuntor
{
	public String obj;
	public String imagemObj;
}