//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Categoria.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Defini��o dos procedimentos que v�o dar sentido (ou n�o) ao arquivo de entrada.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

//------------------------------
// Padr�es adotados:
// - Objetos: Letras mai�scula;
// - Setas: Letras Min�sculas;
//------------------------------
public class Categoria {

	private String nomeCat;
	private HashSet obj;		//Armazena os objetos da Categoria;
	private Vector comp;		//Armazena as composi��es da Categoria;
	private Vector tabMor;		//Tabela de Morfismos;


	//Construtor
	public Categoria( String nome )
	{
		nomeCat = new String( nome );
		obj = new HashSet();
		comp = new Vector();
		tabMor = new Vector();
	}

	public Vector getTabMor () {
		return tabMor;
	}

	public HashSet getObj () {
		return obj;
	}

	public Vector getComp () {
		return comp;
	}

	//----------------------------------------------
		//Adiciona os Objetos ao hashset obj;
	// retorna -1 caso a adi��o n�o tenha sido feito
	// retorna 0 caso a adi��o tenha sido feito
	//-----------------------------------------------
	public int adicionaObj( String o )
	{
		if ( obj.add( o ) )
			return 0;
		else
			return -1;
	}

	public void adicionaObj( HashSet o )
	{
		obj = (HashSet)o.clone();
	}

	//-------------------------------------------------
	//Adiciona as "setas"
	// org -> origem
	// dest -> destino
	// mor -> nome da seta
	// ide -> Identidade???
	//-------------------------------------------------
	// retorna -1 caso a adi��o n�o tenha sido feito
	// retorna 0 caso a adi��o tenha sido feito
	//-------------------------------------------------
	public void adicionaMor( Morfismo morf )
	{
		tabMor.add(morf);

		//E se eu estiver adicionando um morfismo q jah existe com d0 e d1 diferentes???
		//Talvez fosse interessante verificar se existe o morfismo armazenado, se sim, procurar
		//na tabela de morfismos para verificar a concistencia de d0 e d1....
		//
		// ... boa pergunta...!!!
	}

	public void adicionaMor( Vector morf )
	{
		tabMor = morf;
	}

	public void adicionaComp (Composicao c)   
	{
		comp.add(c);		
	}

	public void adicionaComp( Vector c )
	{
		comp = c;
	}
		
	public String objToString()
	{
		return obj.toString();
	}

	public String getNome()
	{
		return nomeCat;
	}

	public void setNome( String n )
	{
		nomeCat = n;
	}

	public Categoria categoriaDual( )
	{
		String nome = new String( nomeCat+"<OP>" );
		Categoria catDual = new Categoria( nome );
		
		catDual.adicionaObj( obj );

		Vector morfismosDual = new Vector();
		Vector morfismos = tabMor;

		for(int i=0; i<morfismos.size(); i++)
		{
			Morfismo f = (Morfismo)morfismos.elementAt(i);
			Morfismo dualf = new Morfismo();

			dualf.morfismo = f.morfismo;
			dualf.origem = f.destino;
			dualf.destino = f.origem;
			dualf.id = f.id;
			morfismosDual.add(dualf);
		}

		catDual.adicionaMor( morfismosDual );

		Vector composicao = comp;
		Vector composicaoDual = new Vector();

		for(int i=0; i<composicao.size(); i++)
		{
			Composicao c = (Composicao)composicao.elementAt(i);
			Composicao dualc = new Composicao();

			dualc.morfH = c.morfH;
			dualc.morfG = c.morfF;
			dualc.morfF = c.morfG;
			composicaoDual.add(dualc);
		}

		catDual.adicionaComp( composicaoDual );

		return catDual;
	}


	public void resultado()
	{
		System.out.println("..:: Categoria "+nomeCat+"::..\n");
		System.out.println("Obj\n{");
		System.out.println(obj);
		System.out.println("}");
		System.out.println("Morf\n{");
		for(int i=0; i<tabMor.size(); i++)
		{
			System.out.println((Morfismo)tabMor.elementAt(i));
		}
		System.out.println("}");
		
		System.out.println("Comp\n{ ");
		for(int i=0; i<comp.size(); i++)
		{

			System.out.println((Composicao)comp.elementAt(i));
		}
		System.out.println("}\n");
	}
}
