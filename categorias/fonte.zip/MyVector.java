
import java.util.*;

public class MyVector extends Vector
{
	public MyVector ()
	{
		super ();
	}

	public Vector and (Vector x, Vector y)
	{
		Vector and = new Vector ();

		for (int i=0; i< x.size (); i++)
		{
			if  ( y.contains (x.get(i)) )
			{
				and.add (x.get(i));
			}
		}

		return and;
	}	
}
