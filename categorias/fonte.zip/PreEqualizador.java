import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class PreEqualizador
{
	public String objeto;
	public Morfismo morfismo;

	public String toString()
	{
		return "<"+objeto+","+morfismo.morfismo+">\n";
	}
}