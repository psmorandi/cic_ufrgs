//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Main.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Procedimentos para inicializa��o da interface.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Main extends JFrame implements ActionListener
{
	private static String programName = new String("CatRON - Category RecOgNizer (R) Ver. 2.0 Final");
	JDesktopPane desktop;
	JTextArea texto;
	JScrollBar scroll;
	Categoria CAT, menorCat, maiorCat;
	Funtor funtor;
	Hashtable allCat; //Todas categorias abertas;
	Hashtable allFun; //Todos funtores abertos;

	public Main()
	{
		super(programName);

		allCat = new Hashtable();
		allFun = new Hashtable();

		getContentPane().setLayout( new BorderLayout() );

		//Menu Arquivo, editar, view, ajuda...
		JMenuBar menu = new JMenuBar();

		//Menus Suspensos:
		JMenu file = MainWindowEvent.makeMenu(MainWindowEvent.criaMenu("Arquivo",KeyEvent.VK_A),
	          new Object[] {
		        MainWindowEvent.criaItem("Abrir Categoria",KeyEvent.VK_C,KeyStroke.getKeyStroke('O',InputEvent.CTRL_MASK) ),
MainWindowEvent.criaItem("Abrir Funtor",KeyEvent.VK_F,KeyStroke.getKeyStroke('F',InputEvent.CTRL_MASK) ),						null,			MainWindowEvent.criaItem("Sair",KeyEvent.VK_R,KeyStroke.getKeyStroke('X',InputEvent.CTRL_MASK) ),
	                }, this);

		JMenu funcoes = MainWindowEvent.makeMenu( MainWindowEvent.criaMenu("Fun��es",KeyEvent.VK_F),
				new Object[] {
				               MainWindowEvent.criaItem("Limpar �rea de Texto", KeyEvent.VK_L, KeyStroke.getKeyStroke('L',InputEvent.CTRL_MASK) ),
					       null,
	 	               		       MainWindowEvent.criaItem("Subcategoria", KeyEvent.VK_S, KeyStroke.getKeyStroke('U',InputEvent.CTRL_MASK) ),
					       MainWindowEvent.criaItem("Compor funtores", KeyEvent.VK_F, null ),
					       null,
					       MainWindowEvent.criaItem("Produto Bin�rio",KeyEvent.VK_B, null ),
					       MainWindowEvent.criaItem("Co-Produto Bin�rio",KeyEvent.VK_P, null ),
					       MainWindowEvent.criaItem("Equalizador",KeyEvent.VK_R, null ),
					       MainWindowEvent.criaItem("Co-Equalizador",KeyEvent.VK_Q, null ),
					       null,
					       MainWindowEvent.criaItem("Todos os Monomorfismos",KeyEvent.VK_M, null ),
					       MainWindowEvent.criaItem("Todos os Epimorfismos",KeyEvent.VK_E, null),
					       MainWindowEvent.criaItem("Todos os Isomorfismos",KeyEvent.VK_I, null),
					       null,
					       MainWindowEvent.criaItem("Objeto Inicial",KeyEvent.VK_J, null),
					       MainWindowEvent.criaItem("Objeto Terminal",KeyEvent.VK_N, null),
					       MainWindowEvent.criaItem("Objeto Zero",KeyEvent.VK_Z, null),
					       null,
					       MainWindowEvent.criaItem("Categorias e Funtores Abertos", KeyEvent.VK_C, null )
				}, this);

		JMenu sobre = MainWindowEvent.makeMenu( MainWindowEvent.criaMenu("Help",KeyEvent.VK_S),
				new Object[] {
					MainWindowEvent.criaItem("Ajuda", KeyEvent.VK_S, KeyStroke.getKeyStroke('I',InputEvent.CTRL_MASK) ),
					null,
					MainWindowEvent.criaItem("Sobre CatRON", KeyEvent.VK_C, null ),
						}, this);

		menu.add(file);
		menu.add(funcoes);
		menu.add(sobre);

		setJMenuBar(menu);

		JToolBar editToolbar = new JToolBar();

		JButton o = new JButton( new ImageIcon("figura/openCat.gif") );
		JButton o2 = new JButton( new ImageIcon("figura/openFun.gif") );
		JButton f2 = new JButton( new ImageIcon("figura/funtorComp.gif") );
		JButton f1 = new JButton( new ImageIcon("figura/subCat.gif") );
		JButton f3 = new JButton( new ImageIcon("figura/mono.gif") );
		JButton f4 = new JButton( new ImageIcon("figura/epi.gif") );
		JButton f5 = new JButton( new ImageIcon("figura/iso.gif") );
		JButton f6 = new JButton( new ImageIcon("figura/objInicial.gif") );
		JButton f7 = new JButton( new ImageIcon("figura/objTerminal.gif") );
		JButton f8 = new JButton( new ImageIcon("figura/objZero.gif") );
		JButton f9 = new JButton( new ImageIcon("figura/produto.gif") );
		JButton f10 = new JButton( new ImageIcon("figura/coproduto.gif") );
		JButton f11 = new JButton( new ImageIcon("figura/eq.gif") );
		JButton f12 = new JButton( new ImageIcon("figura/coeq.gif") );

	        f3.setRequestFocusEnabled(false);
	        f3.setMargin(new Insets(1,1,1,1));
		f3.setToolTipText("Monomorfismos");
		f3.setActionCommand("Mono");
		f3.addActionListener(this);

	        f4.setRequestFocusEnabled(false);
	        f4.setMargin(new Insets(1,1,1,1));
		f4.setToolTipText("Epimorfismos");
		f4.setActionCommand("Epi");
		f4.addActionListener(this);
		
	        f5.setRequestFocusEnabled(false);
	        f5.setMargin(new Insets(1,1,1,1));
		f5.setToolTipText("Isomorfismos");
		f5.setActionCommand("Iso");
		f5.addActionListener(this);
		
	        f6.setRequestFocusEnabled(false);
	        f6.setMargin(new Insets(1,1,1,1));
		f6.setToolTipText("Objetos Iniciais");
		f6.setActionCommand("ObjInicial");
		f6.addActionListener(this);
		
	        f7.setRequestFocusEnabled(false);
	        f7.setMargin(new Insets(1,1,1,1));
		f7.setToolTipText("Objetos Terminais");
		f7.setActionCommand("ObjTerminal");
		f7.addActionListener(this);

	        f8.setRequestFocusEnabled(false);
	        f8.setMargin(new Insets(1,1,1,1));
		f8.setToolTipText("Objetos Zero");
		f8.setActionCommand("ObjZero");
		f8.addActionListener(this);

	        f2.setRequestFocusEnabled(false);
	        f2.setMargin(new Insets(1,1,1,1));
		f2.setToolTipText("Compor Funtores");
		f2.setActionCommand("FuncaoComp");
		f2.addActionListener(this);

	        o.setRequestFocusEnabled(false);
	        o.setMargin(new Insets(1,1,1,1));
		o.setToolTipText("Abrir um Arquivo de Categorias");
		o.setActionCommand("AbrirCat");
		o.addActionListener(this);

		o2.setRequestFocusEnabled(false);
	        o2.setMargin(new Insets(1,1,1,1));
		o2.setToolTipText("Abrir um Arquivo de Funtores");
		o2.setActionCommand("AbrirFun");
		o2.addActionListener(this);

		f1.setRequestFocusEnabled(false);
	        f1.setMargin(new Insets(1,1,1,1));
		f1.setToolTipText("Verificar Subcategoria");
		f1.setActionCommand("FuncaoSub");
		f1.addActionListener(this);

	        f9.setRequestFocusEnabled(false);
	        f9.setMargin(new Insets(1,1,1,1));
		f9.setToolTipText("Produto Bin�rio");
		f9.setActionCommand("Prod");
		f9.addActionListener(this);

	        f10.setRequestFocusEnabled(false);
	        f10.setMargin(new Insets(1,1,1,1));
		f10.setToolTipText("Co-Produto Bin�rio");
		f10.setActionCommand("CoProd");
		f10.addActionListener(this);

	        f11.setRequestFocusEnabled(false);
	        f11.setMargin(new Insets(1,1,1,1));
		f11.setToolTipText("Equalizador");
		f11.setActionCommand("Equ");
		f11.addActionListener(this);

	        f12.setRequestFocusEnabled(false);
	        f12.setMargin(new Insets(1,1,1,1));
		f12.setToolTipText("Co-Equalizador");
		f12.setActionCommand("CoEqu");
		f12.addActionListener(this);

		editToolbar.add(Box.createHorizontalStrut(2));
		editToolbar.add(o);
		editToolbar.add(o2);

		editToolbar.addSeparator();
		
		editToolbar.add(f1);
		editToolbar.add(f2);

		editToolbar.addSeparator();
		
		editToolbar.add(f3);
		editToolbar.add(f4);
		editToolbar.add(f5);

		editToolbar.addSeparator();
		
		editToolbar.add(f6);
		editToolbar.add(f7);
		editToolbar.add(f8);

		editToolbar.addSeparator();
		
		editToolbar.add(f9);
		editToolbar.add(f10);
		editToolbar.add(f11);
		editToolbar.add(f12);

		editToolbar.add(Box.createHorizontalGlue());

		setJMenuBar(menu);
		getContentPane().add(editToolbar, BorderLayout.NORTH);

		desktop = new JDesktopPane();
		getContentPane().add(desktop, BorderLayout.CENTER);

		texto = new JTextArea("Welcome to CatRON  Ver. 2.0 Final\n\n\n");
		texto.setEditable(false);
		texto.setAutoscrolls(true);
		texto.setFont( new Font("DialogInput",Font.BOLD,14));

		JScrollPane scroller = new JScrollPane();
		JViewport port = scroller.getViewport();
		port.add(texto);

		getContentPane().add(scroller);
	}

	public JDesktopPane getDesktop()
	{
		return desktop;
	}

	public static void main ( String args[] )
	{
		Main frame = new Main();
		frame.addWindowListener(new MainWindowEvent());
		frame.setSize(800, 600);
		frame.show();
		System.out.println("DEBUG MESSAGES ON....");
		System.out.println("Senhor usuario, por favor, ignore todas essas"+
		" mensagens que aparecem no Terminal (ou Console, se o senhor for Windows' User...)");

	}

	public void actionPerformed( ActionEvent e )
        {
                if (e.getSource() instanceof JMenuItem)
                {
			JMenuItem mi = (JMenuItem) e.getSource();

			//Preparando as Opcoes:
			JPanel frame = new JPanel();

			if (mi.getText().equals("Sair"))
			{
				System.exit(0);
			}

			if (mi.getText().equals("Sobre CatRON"))
			{
				JOptionPane.showMessageDialog(null,"Autores:\nMarcelo Claro Zembrzuski\nPaulo S�rgio Morandi J�nior\nCatRON � freeware, podendo ser copiado, distribu�do e modificado.\nPsMj(TM) FreeSoftawre (R) 2001-2003\nPsMj(TM) Corp. (C) 1981-2003\ntresemi Corporation 1998 - 2003 (R)","Sobre CatRON - Category RecOgNizer Ver. 2.0 Final",JOptionPane.INFORMATION_MESSAGE);
			}

			if (mi.getText().equals("Abrir Categoria") || mi.getText().equals("Salvar") )
				openSaveAction(mi.getText(),"cat");
			if (mi.getText().equals("Abrir Funtor"))
				openSaveAction(mi.getText(),"fun");
			if(mi.getText().equals("Limpar �rea de Texto"))
					texto.setText("Welcome to CatRON\n\n\n");
			if(mi.getText().equals("Ajuda"))
				JOptionPane.showMessageDialog(null,"\n- Para abrir uma Categoria pressione \"ctrl+o\" ou \"Arquivo\" -> \"Abrir Categorias\"; \n"+"\n- Para abrir um Funtor pressione \"ctrl+f\" ou \"Arquivo\" -> \"Abrir Funtor\";\n"+"\n- Subcategoria: Para testar se uma categoria � sub de outra selecione \"Fun��es\" -> \"Subcategoria\". \nExemplo: para verificar se <1> � subcategoria de <1+1>, ap�s aberto o di�logo, \nonde diz \"Categoria Maior\" selecione no menu a categoria \"<1+1>\" e clique \"OK\". \nDepois selecione no pr�ximo di�logo a subcategoria \"<1>\" e clique \"OK\"\n"+"\n- Compor Funtores: Para compor dois Funtores v�lidos selecione \"Fun��es\" -> \"Compor Funtores\". \nExemplo: para verificar o resultado da composi��o do funtor <f1> com o funtor <f1+1>, ap�s aberto o di�logo, \nonde diz \"Selecione funtor 1:\" selecione no menu o funtor \"<f1>\" e clique \"OK\". \nDepois selecione no pr�ximo di�logo o segundo funtor \"<f1+1>\" e clique \"OK\", o resultado, caso haja,\n ser� <f1+1>_<f1>, onde o \"_\" corresponde a fun��o de composi��o: <f1+1>(<f1>).\n\n- Para verificar quais categorias e funtores est�o abertos pelo CATRON, selecione \n\"Fun��es\" -> \"Categorias e Funtores Abertos\"","HELP",JOptionPane.INFORMATION_MESSAGE);
			if( mi.getText().equals("Categorias e Funtores Abertos") )
			{
				AllOpenDialog x = new AllOpenDialog( allCat, allFun );
			}

			if( mi.getText().equals("Subcategoria") )
			{
				calculaSubCategoria( allCat );
			}
			if ( mi.getText().equals("Compor funtores") )
			{
				comporFuntores( allFun );
			}
			if ( mi.getText().equals("Produto Bin�rio") )
			{
				calculaProdutoBinario( allCat );
			}
			if ( mi.getText().equals("Co-Produto Bin�rio") )
			{
				calculaCoProdutoBinario( allCat );
			}
			if ( mi.getText().equals("Todos os Monomorfismos") )
			{
				calculaMono( allCat );
			}
			if ( mi.getText().equals("Todos os Epimorfismos") )
			{
				calculaEpi( allCat );
			}
			if ( mi.getText().equals("Todos os Isomorfismos") )
			{
				calculaIso( allCat );
			}
			if ( mi.getText().equals("Objeto Inicial") )
			{
				calculaObjInicial( allCat );
			}
			if ( mi.getText().equals("Objeto Terminal") )
			{
				calculaObjTerminal( allCat );
			}
			if ( mi.getText().equals("Objeto Zero") )
			{
				calculaObjZero( allCat );
			}
			if ( mi.getText().equals("Equalizador") )
			{
				calculaEqualizador( allCat );
			}
			if ( mi.getText().equals("Co-Equalizador") )
			{
				calculaCoEqualizador( allCat );
			}


		}//if of event
		else
			if( e.getSource() instanceof JButton )
			{
				JButton b = (JButton)e.getSource();
				String source = b.getActionCommand();
				if( source.equals("AbrirCat") )
				{
					openSaveAction("Abrir Categoria","cat");
				}
				else if ( source.equals("AbrirFun") )
				{
					openSaveAction("Abrir Funtor","fun");
				}
				else if ( source.equals("FuncaoSub") )
				{
					calculaSubCategoria( allCat );
				}
				else if ( source.equals("FuncaoComp") )
				{
					comporFuntores( allFun );
				}
				else if ( source.equals("Mono") )
				{
					calculaMono( allCat );
				}
				else if ( source.equals("Epi") )
				{
					calculaEpi( allCat );
				}
				else if ( source.equals("Iso") )
				{
					calculaIso( allCat );
				}
				else if ( source.equals("ObjInicial") )
				{
					calculaObjInicial( allCat );
				}
				else if ( source.equals("ObjTerminal") )
				{
					calculaObjTerminal( allCat );
				}
				else if ( source.equals("ObjZero") )
				{
					calculaObjZero( allCat );
				}
				else if ( source.equals("Prod") )
				{
					calculaProdutoBinario( allCat );
				}
				else if ( source.equals("CoProd") )
				{
					calculaCoProdutoBinario( allCat );
				}
				else if ( source.equals("Equ") )
				{
					calculaEqualizador( allCat );
				}
				else if ( source.equals("CoEqu") )
				{
					calculaCoEqualizador( allCat );
				}
			}

	}//actionPerformed

	private void calculaMono( Hashtable c )
	{
		MonoDialog p = new MonoDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			x.quemEhMono("MONOMORFISMOS");
		}
	}
	private void calculaEpi( Hashtable c )
	{
		EpiDialog p = new EpiDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			x.quemEhEpi();
		}
	}
	private void calculaIso( Hashtable c )
	{
		IsoDialog p = new IsoDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			x.quemEhIso();
		}

	}
	private void calculaObjInicial( Hashtable c )
	{
		ObjetoInicialDialog p = new ObjetoInicialDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			Vector z = x.objetosIniciais();
			if ( z.size() > 0 )
			{
				texto.append("---------------------------------------------\n");
				texto.append("Objetos Iniciais da Categoria "+
						p.getCategoria().getNome()+": "+z);
			}
			else
				texto.append("A Categoria "+p.getCategoria().getNome()+
					" N�O POSSUI Objetos Iniciais!");
			texto.append("\n---------------------------------------------\n");
		}
	}
	private void calculaObjTerminal( Hashtable c )
	{
		ObjetoTerminalDialog p = new ObjetoTerminalDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			Vector z = x.objetosTerminais();
			if (z.size() > 0)
			{
			 	texto.append("---------------------------------------------\n");
				texto.append("Objetos Terminais da Categoria "+
						p.getCategoria().getNome()+": "+z);
			}
			else
				texto.append("A Categoria "+p.getCategoria().getNome()+
					" N�O POSSUI Objetos Terminais!");
			texto.append("\n---------------------------------------------\n");

		}
	}
	private void calculaObjZero( Hashtable c )
	{
		ObjetoZeroDialog p = new ObjetoZeroDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			Vector z = x.objetosZero();
			if (z.size() > 0)
			{
			 	texto.append("---------------------------------------------\n");
				texto.append("Objetos Zero da Categoria "+p.getCategoria().getNome()+": "+z);
			}
			else
				texto.append("A Categoria "+p.getCategoria().getNome()+
					" N�O POSSUI Objetos Zero!");
			texto.append("\n---------------------------------------------\n");
		}
	}
	private void calculaEqualizador( Hashtable c )
	{
		EqualizadorDialog p = new EqualizadorDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			if ( (p.getMorf1() != null) && (p.getMorf2() != null) )
				x.equalizador(p.getMorf1(),p.getMorf2(),"EQUALIZADOR");
		}
		texto.append("---------------------------------------------\n");
	}
	private void calculaCoEqualizador( Hashtable c )
	{
		CoEqualizadorDialog p = new CoEqualizadorDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			if ( (p.getMorf1() != null) && (p.getMorf2() != null) )
				x.coEqualizador(p.getMorf1(),p.getMorf2());
		}
		texto.append("---------------------------------------------\n");
	}

	private void calculaProdutoBinario( Hashtable c )
	{
		ProdutoBinarioDialog p = new ProdutoBinarioDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			if ( (p.getObj1() != null) && (p.getObj2() != null) )
				x.produtoBinario(p.getObj1(), p.getObj2(),"PRODUTO BIN�RIO");
		}
	}
	private void calculaCoProdutoBinario( Hashtable c )
	{
		CoProdutoBinarioDialog p = new CoProdutoBinarioDialog( c );
		if ( p.getCategoria() != null )
		{
			PropriedadesDeMorfismos x = new PropriedadesDeMorfismos( p.getCategoria(), texto );
			if ( (p.getObj1() != null) && (p.getObj2() != null) )
				x.coprodutoBinario(p.getObj1(), p.getObj2());
		}
	}
	private void comporFuntores( Hashtable f )
	{
		ComporFuntorDialog d = new ComporFuntorDialog( f );

		if ( (d.getFuntor1() != null) && (d.getFuntor2() != null) )
		{
			ComporFuntor teste = new ComporFuntor(
						(Funtor)f.get(d.getFuntor1()),
						(Funtor)f.get(d.getFuntor2())
						);
			Funtor possivelComposicao = teste.compor();
			if (possivelComposicao != null)
			{
				texto.append(d.getFuntor1()+" e "+
					 d.getFuntor2()+" s�o FUNTORES COMPON�VEIS!\n");
				teste.resultadoDaComposicao( texto );
				f.put(possivelComposicao.getNome(),possivelComposicao);
				texto.append("\n-----------------------------------------\n\n");
			}
			else
				texto.append(d.getFuntor1()+" e "+d.getFuntor2()+
				" N�O s�o FUNTORES COMPON�VEIS!\n"+
				"\n-----------------------------------------\n\n");
		}
	}

	private void calculaSubCategoria( Hashtable c )
	{
		SubCatDialog sub = new SubCatDialog( c );

		if ( (sub.getCatMaior() != null) && (sub.getCatMenor() != null) )
		{

 			menorCat = (Categoria)c.get(sub.getCatMenor());
			maiorCat = (Categoria)c.get(sub.getCatMaior());

			TestaSubCategoria tt = new TestaSubCategoria( menorCat, maiorCat);

			if (tt.testa())
			{
				texto.append(menorCat.getNome()+
					" � SUBCATEGORIA de "+maiorCat.getNome()+"\n");
				if (tt.ehLarga () )
				{
					texto.append("		"+menorCat.getNome()+
						"  � SUBCATEGORIA LARGA DE "+maiorCat.getNome()+"\n");

				}
				else
					texto.append("		"+menorCat.getNome()+
						"  � SUBCATEGORIA N�O-LARGA DE "+maiorCat.getNome()+"\n");
				if (tt.ehPlena () )
				{
					texto.append("		"+menorCat.getNome()+
						"  � SUBCATEGORIA PLENA DE "+maiorCat.getNome()+"\n");
				}
				else
					texto.append("		"+menorCat.getNome()+
						"  � SUBCATEGORIA N�O-PLENA DE "+maiorCat.getNome()+"\n");
			}
			else
				texto.append(menorCat.getNome()+" N�O � SUBCATEGORIA de "+
					maiorCat.getNome()+"\n");
		}
	}

	public void openSaveAction( String what, String catFun )
	{
		JPanel frame = new JPanel();
		CatFileFilter catFilter;
		//Abrir ou Salvar Arquivo:
		JFileChooser chooser = new JFileChooser();

		if (catFun.equals("cat") )
		{
			catFilter = new CatFileFilter("ctg", "CTG Arquivo Categorias");
		}
		else
		{
			catFilter = new CatFileFilter("fnt", "FTG Arquivo Funtor");
		}

		catFilter.setExtensionListInDescription(true);

		chooser.setApproveButtonText(what);
		chooser.addChoosableFileFilter(catFilter);
		chooser.setSelectedFile(null);

		frame.add("Center", chooser);

		if ( what.equals("Abrir Categoria") || what.equals("Abrir Funtor") )
		{
			chooser.setDialogType(JFileChooser.OPEN_DIALOG);

			int retval = chooser.showDialog(frame, null);
			if (retval == JFileChooser.APPROVE_OPTION)
			{
				File theFile = chooser.getSelectedFile();
				if (theFile != null)
				{
					openFile(theFile.getPath(), catFun );

					if ( catFun.equals("cat") )
					{
						// marcelo�s Code
						TestaCategoria ttCat = new TestaCategoria ( CAT );
						try
						{
							ttCat.testa ();
							texto.append ("\n"+CAT.getNome()+"  � uma Categoria V�lida!\n\n");
							allCat.put( CAT.getNome(), CAT );
							CAT.resultado();
							Categoria dual = CAT.categoriaDual();
							dual.resultado();
							allCat.put( dual.getNome(), dual );
						}
						catch (CatExcept e)
						{
							texto.append ("\n"+CAT.getNome()+"  N�O � uma Categoria!\n\nMotivo: "+e.getMessage()+"\n\n");
						}
					}
					else
					{
						// Marcelo's Code.... by PsMj
						if ( allCat.get(funtor.getStringCatOrigem()) != null )
						{
							if (allCat.get(funtor.getStringCatDestino()) != null )
							{
							   TestaFuntor ttFun = new TestaFuntor( allCat, funtor );
							try
							{
								ttFun.testa();
								texto.append ("\n"+funtor.getNome()+"  � um FUNTOR V�lido!\n\n");
								allFun.put( funtor.getNome(), funtor );
							}
							catch (CatExcept e)
							{
								texto.append ("\n"+funtor.getNome()+"  N�O � um FUNTOR!\nMotivo: "+e.getMessage()+"\n\n");
							}
							}
							else
							{
							     JOptionPane.showMessageDialog(null,"Erro!! Certifique que a Categoria "+funtor.getStringCatDestino()+" esteja aberta!!\nPara verificar quais categorias est�o abertas no momento, acesse o menu Fun��es.","Categoria Destino Esperada",JOptionPane.ERROR_MESSAGE);
							     texto.append("ERRO NA LEITURA DO FUNTOR. CHEQUE CATEGORIAS ABERTAS\n");
							}

						}
						else
						{
							JOptionPane.showMessageDialog(null,"Erro!! Certifique que a Categoria "+funtor.getStringCatOrigem()+" esteja aberta!!\nPara verificar quais categorias est�o abertas no momento, acesse o menu Fun��es.","Categoria Origem Esperada",JOptionPane.ERROR_MESSAGE);
						        texto.append("ERRO NA LEITURA DO FUNTOR. CHEQUE CATEGORIAS ABERTAS\n");
						}

					}
				}
					texto.append("-----------------------------------------------------\n");

			}
			else
				if (retval == JFileChooser.ERROR_OPTION)
					JOptionPane.showMessageDialog(frame, "An error occured. No file was OPEN.");
		}
		else
		{
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);

			int retval = chooser.showDialog(frame, null);
			if (retval == JFileChooser.APPROVE_OPTION)
			{
				File theFile = chooser.getSelectedFile();
				if (theFile != null)
					saveFile(theFile.getPath());
			}
			else
				if (retval == JFileChooser.ERROR_OPTION)
					JOptionPane.showMessageDialog(frame, "An error occured. No file was SAVE.");
		}
	}

	public void openFile( String fileName, String catFun )
	{
		try
		{
			BufferedReader file = new BufferedReader( new FileReader(fileName));
			//ler a categoria ou funtor
			if (catFun.equals("cat"))
			{
				CatRead cat = new CatRead( file, texto );
				// marcelo�s Code
				CAT = cat.returnCat();
			}
			else
			{
				FuntorRead fun = new FuntorRead( file, texto );
				funtor = fun.returnFuntor();
			}
		}
		catch(IOException excp)
		{
			System.out.println("IO ERROR or File not Found");
			excp.printStackTrace();
		}
	}//openFile

	public void saveFile( String fileName )
	{
		try
		{
			BufferedWriter file = new BufferedWriter( new FileWriter(fileName));

			//SALVAR...
		}
		catch(IOException excp)
		{
			System.out.println("IO ERROR");
			excp.printStackTrace();
		}
	}//saveFile


}
