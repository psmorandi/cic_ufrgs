//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo AllOpenDialog.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Di�logo que mostra todos os funtores e todas as categorias abertas at� o momento.
// - Somente categorias e funtores v�lidos s�o mantidos abertos.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;

public class AllOpenDialog {

	public AllOpenDialog( Hashtable cat, Hashtable funtor )
	{
		JComboBox possibleCat = new JComboBox();
		JComboBox possibleFun = new JComboBox();
		Set categorias = cat.keySet();
		Set funtores = funtor.keySet();
		Iterator it = categorias.iterator();
		while( it.hasNext() )
			possibleCat.addItem( (String) it.next());
		it = funtores.iterator();
		while( it.hasNext() )
			possibleFun.addItem( (String) it.next());

		Object[] message = new Object[4];
		message[0] = "Categorias abertas at� o momento:";
		if (cat.size() > 0)
			message[1] = possibleCat;
		else
			message[1] = "Nenhuma Categoria aberta at� o momento!!!!";
		message[2] = "Funtores abertos at� o momento:";
		if (funtor.size() > 0)
			message[3] = possibleFun;
		else
			message[3] = "Nenhum Funtor aberto at� o momento!!!!";
		JOptionPane.showOptionDialog(null, message, "Categorias e Funtores...",
				JOptionPane.DEFAULT_OPTION,
				JOptionPane.INFORMATION_MESSAGE,
				null, null, null);
	}
}

class SubCatDialog
{
	private Hashtable todasCat;
	private String catMaior, catMenor;
	
	public SubCatDialog( Hashtable c )
	{
		todasCat = c;
		if (todasCat.size() < 1 ) 
			JOptionPane.showMessageDialog(null,"Erro!! Nenhuma Categoria aberta!!!","ERROR",
 				JOptionPane.ERROR_MESSAGE);
		else
		{
			String[] possibleValues = new String[todasCat.size()];
			Set categorias = todasCat.keySet();
			Iterator it = categorias.iterator();
			int i = 0;

			while( it.hasNext() ) 
			{
				possibleValues[i] = (String) it.next();
				i++;				
     			}

			Object selectedCat = JOptionPane.showInputDialog(null,
						"Escolha a Categoria Maior:", "Categoria Maior", JOptionPane.INFORMATION_MESSAGE, null,
						possibleValues, possibleValues[0]);
			if ( selectedCat != null )
			{
				catMaior = (String)selectedCat;
				Object selectedSub = JOptionPane.showInputDialog(null,
					"Categoria Maior selecionada: "+selectedCat+"\nEscolha a SubCategoria:", "SubCategoria", JOptionPane.INFORMATION_MESSAGE, null,
					possibleValues, possibleValues[0]);
				if ( selectedSub != null )
					catMenor = (String)selectedSub;
				else
					catMaior = catMenor = null;
			}
			else
				catMaior = catMenor = null;
		}
	}

	public String getCatMaior()
	{
		return catMaior;
	}
	
	public String getCatMenor()
	{
		return catMenor;
	}

}

class ComporFuntorDialog {

	private String funtor1, funtor2;

	ComporFuntorDialog( Hashtable funtor )
	{
		if (funtor.size() < 1 ) 
			JOptionPane.showMessageDialog(null,"Erro!! Nenhum Funtor aberto!!!","ERROR",
 				JOptionPane.ERROR_MESSAGE);
		else
		{
			String[] possibleValues = new String[funtor.size()];
			Set funtores = funtor.keySet();
			Iterator it = funtores.iterator();
			int i = 0;

			while( it.hasNext() ) 
			{
				possibleValues[i] = (String) it.next();
				i++;				
     			}

			Object selectedF1 = JOptionPane.showInputDialog(null,
						"Funtor 1:", "Compondo Funtor 1 com Funtor 2...", JOptionPane.INFORMATION_MESSAGE, null,
						possibleValues, possibleValues[0]);
			if ( selectedF1 != null )
			{
				funtor1 = (String)selectedF1;
				Object selectedF2 = JOptionPane.showInputDialog(null,
					"Funtor 1: "+selectedF1+"\nFuntor 2:", "Compondo Funtor 1 com Funtor 2...", JOptionPane.INFORMATION_MESSAGE, null,
					possibleValues, possibleValues[0]);
				if ( selectedF2 != null )
					funtor2 = (String)selectedF2;
				else
					funtor1 = funtor2 = null;
			}
			else
				funtor1 = funtor2 = null;
		}
	}

	public String getFuntor1()
	{
		return funtor1;
	}
	public String getFuntor2()
	{
		return funtor2;
	}
}

class CatDialog
{
    private Categoria catEscolhida;

    public CatDialog( Hashtable c, String title )
    {
	if (c.size() < 1 )
	{
		JOptionPane.showMessageDialog(null,"Erro!! Nenhuma Categoria aberta!!!","ERROR",JOptionPane.ERROR_MESSAGE);
		catEscolhida = null;
	}
	else{

	String[] possibleValues = new String[c.size()];
	Set categorias = c.keySet();
	Iterator it = categorias.iterator();
	int i = 0;

	while( it.hasNext() )
	{
		possibleValues[i] = (String) it.next();
		i++;
     	}

	Object selectedCat = JOptionPane.showInputDialog(null,
			     "Escolha a Categoria de interesse:", title, JOptionPane.INFORMATION_MESSAGE, null,
	possibleValues, possibleValues[0]);

	if ( selectedCat != null )
	{
		catEscolhida = (Categoria)c.get((String)selectedCat);
	}
	else
		catEscolhida = null;

	}//do else

     }

     public Categoria getCategoria()
     {
		return catEscolhida;
     }
}

class ProdutoBinarioDialog
{
    private String objeto1;
    private String objeto2;
    private Categoria catEscolhida;

    public ProdutoBinarioDialog( Hashtable c )
    {
    	String title = "Produto Bin�rio";
	CatDialog cat = new CatDialog( c, title );
	catEscolhida = cat.getCategoria();

	if ( catEscolhida != null )
	{
		String[] possibleObjects = new String[catEscolhida.getObj().size()];

		Iterator it = catEscolhida.getObj().iterator();
		int i = 0;

		while( it.hasNext() )
		{
			possibleObjects[i] = (String) it.next();
			i++;
     		}

		Object selectedObj1 = JOptionPane.showInputDialog(null,
		 	     "Escolha um Objeto da Categoria "+catEscolhida.getNome()+":", "Produto Bin�rio", JOptionPane.INFORMATION_MESSAGE, null,
		 	     possibleObjects, possibleObjects[0]);
		if ( selectedObj1 != null )
		{
			Object selectedObj2 = JOptionPane.showInputDialog(null,
		 	    	 "Objeto 1 = "+(String)selectedObj1+"\nEscolha outro Objeto da Categoria "+catEscolhida.getNome()+":", "Produto Bin�rio", JOptionPane.INFORMATION_MESSAGE, null,
		 	     possibleObjects, possibleObjects[0]);
			if ( selectedObj2 != null )
			{
				objeto1 = (String)selectedObj1;
				objeto2 = (String)selectedObj2;
			}
			else
			{
				objeto1 = null;
				objeto2 = null;
			}
		}
		else
		{
			objeto1 = null;
			objeto2 = null;
		}

	}
    }

    public String getObj1()
    {
	    return objeto1;
    }
    public String getObj2()
    {
	    return objeto2;
    }

         public Categoria getCategoria()
     {
		return catEscolhida;
     }

}

class CoProdutoBinarioDialog
{
    private String objeto1;
    private String objeto2;
    private Categoria catEscolhida;

    public CoProdutoBinarioDialog( Hashtable c )
    {

    	String title = "Co-Produto Bin�rio";
	CatDialog cat = new CatDialog( c, title );
	catEscolhida = cat.getCategoria();

	if ( catEscolhida != null )
	{
		String[] possibleObjects = new String[catEscolhida.getObj().size()];

		Iterator it = catEscolhida.getObj().iterator();
		int i = 0;

		while( it.hasNext() )
		{
			possibleObjects[i] = (String) it.next();
			i++;
     		}

		Object selectedObj1 = JOptionPane.showInputDialog(null,
		 	     "Escolha um Objeto da Categoria "+catEscolhida.getNome()+":", "Co-Produto Bin�rio", JOptionPane.INFORMATION_MESSAGE, null,
		 	     possibleObjects, possibleObjects[0]);
		if ( selectedObj1 != null )
		{
			Object selectedObj2 = JOptionPane.showInputDialog(null,
		 	    	 "Objeto 1 = "+(String)selectedObj1+"\nEscolha outro Objeto da Categoria "+catEscolhida.getNome()+":", "Co-Produto Bin�rio", JOptionPane.INFORMATION_MESSAGE, null,
		 	     possibleObjects, possibleObjects[0]);
			if ( selectedObj2 != null )
			{
				objeto1 = (String)selectedObj1;
				objeto2 = (String)selectedObj2;
			}
			else
			{
				objeto1 = null;
				objeto2 = null;
			}
		}
		else
		{
			objeto1 = null;
			objeto2 = null;
		}

	}
}

    public String getObj1()
    {
	    return objeto1;
    }
    public String getObj2()
    {
	    return objeto2;
    }

         public Categoria getCategoria()
     {
		return catEscolhida;
     }

}

class MonoDialog extends CatDialog
{
    public MonoDialog( Hashtable c )
    {
	super( c, "Monomorfismo");
    }
}

class EpiDialog extends CatDialog
{
    public EpiDialog( Hashtable c )
    {
	super( c, "Epimorfimo");
    }
}

class IsoDialog extends CatDialog
{
    public IsoDialog( Hashtable c )
    {
	super( c, "Isomorfismo");
    }
}

class ObjetoInicialDialog extends CatDialog
{
	public ObjetoInicialDialog( Hashtable c )
	{
		super( c, "Objeto Inicial" );
	}
}

class ObjetoTerminalDialog extends CatDialog
{
	public ObjetoTerminalDialog( Hashtable c )
	{
		super( c, "Objeto Terminal" );
	}
}

class ObjetoZeroDialog extends CatDialog
{
	public ObjetoZeroDialog( Hashtable c )
	{
		super( c, "Objeto Zero" );
	}
}

class EqualizadorDialog
{
	private String m1;
	private String m2;
	private Categoria catEscolhida;

	public EqualizadorDialog( Hashtable c )
	{
		CatDialog d = new CatDialog(c, "Equalizador" );

		if (d.getCategoria() != null )
		{
		catEscolhida = (Categoria)d.getCategoria();

		String[] possibleMorf = new String[catEscolhida.getTabMor().size()];

		Vector todosMorfs = catEscolhida.getTabMor();

		for(int i=0; i<todosMorfs.size(); i++ )
		{
			Morfismo m = (Morfismo)todosMorfs.get(i);
			possibleMorf[i] = m.morfismo;
		}

		Object selectedMorf1 = JOptionPane.showInputDialog(null,
					"Escolha um Morfismo da Categoria "+catEscolhida.getNome()+":",
					"Equalizador", JOptionPane.INFORMATION_MESSAGE,
					null,possibleMorf, possibleMorf[0]);

		if ( selectedMorf1 != null )
		{
			Object selectedMorf2 =
			  JOptionPane.showInputDialog(null,"Morfismo 1 = "+(String)selectedMorf1+
			"\nEscolha um morfismo que seja paralelo ao Morfismo 1:", "Equalizador",
			 JOptionPane.INFORMATION_MESSAGE,null,possibleMorf, possibleMorf[0]);

			if ( selectedMorf2 != null )
			{
				m1 = (String)selectedMorf1;
				m2 = (String)selectedMorf2;
			}
			else
			{
				m1 = null;
				m2 = null;
			}
		}
		else
		{
			m1 = null;
			m2 = null;
		}
		}//IF CATEGORIA NULL

	}

	public String getMorf1()
	{
		return m1;
	}

	public String getMorf2()
	{
		return m2;
	}

	public Categoria getCategoria()
	{
		return catEscolhida;
	}

}

class CoEqualizadorDialog
{
	private String m1;
	private String m2;
	private Categoria catEscolhida;

	public CoEqualizadorDialog( Hashtable c )
	{
		CatDialog d = new CatDialog(c, "Co-Equalizador" );
		if (d.getCategoria() != null )
		{
		catEscolhida = (Categoria)d.getCategoria();

		String[] possibleMorf = new String[catEscolhida.getTabMor().size()];

		Vector todosMorfs = catEscolhida.getTabMor();

		for(int i=0; i<todosMorfs.size(); i++ )
		{
			Morfismo m = (Morfismo)todosMorfs.get(i);
			possibleMorf[i] = m.morfismo;
		}

		Object selectedMorf1 = JOptionPane.showInputDialog(null,
					"Escolha um Morfismo da Categoria "+catEscolhida.getNome()+":",
					"Co-Equalizador", JOptionPane.INFORMATION_MESSAGE,
					null,possibleMorf, possibleMorf[0]);

		if ( selectedMorf1 != null )
		{
			Object selectedMorf2 =
			  JOptionPane.showInputDialog(null,"Morfismo 1 = "+(String)selectedMorf1+
			"\nEscolha um morfismo que seja paralelo ao Morfismo 1:", "Co-Equalizador",
			JOptionPane.INFORMATION_MESSAGE,null,possibleMorf, possibleMorf[0]);

			if ( selectedMorf2 != null )
			{
				m1 = (String)selectedMorf1;
				m2 = (String)selectedMorf2;
			}
			else
			{
				m1 = null;
				m2 = null;
			}
		}
		else
		{
			m1 = null;
			m2 = null;
		}
		}//IF CATEGORIA NULL

	}

	public String getMorf1()
	{
		return m1;
	}

	public String getMorf2()
	{
		return m2;
	}

	public Categoria getCategoria()
	{
		return catEscolhida;
	}

}
