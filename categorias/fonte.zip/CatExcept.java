//-----------------------------------------------------------------------------------
// Trabalho de Categorias - 10/2003 - Arquivo Funtor.java
// Autores: 	Paulo S�rgio Morandi J�nior
//		Marcelo Claro Zembrzuski
//
// - Defini��o das exce��es disparadas pelo catron.
//
// PsMj (TM) Corp. 1981 - 2003
// PsMjFreeSoftware (R) - JDD (R) - Java Developer Departament - (C) 2001 - 2003
// tresemi Corporation (C) 1998 - 2003
//-----------------------------------------------------------------------------------

import java.util.*;

public class CatExcept extends Exception
{
	public CatExcept ( String causa )
	{
		super(causa);
	}
}
