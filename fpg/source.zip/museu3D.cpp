/* UNIVERSIDADE DO RIO GRANDE DO SUL - UFRGS
*  Instituto de Inform�tica (II) - Departamento de Inform�tica Aplicada 
* 
* PsMj Corporation (C) 1981 - 2004
* PsMj FreeSoftware (R) 2001 - 2004 and Resser Soft
*  
* Autors:
* Paulo S�rgio Morandi J�nior (PsMj) 2767/01-1
* Rodrigo Resser da Silva 0000/00-0
*
*  MUSEU 3D
*  
*  Objetivo do Trabalho:
*  - Trabalhar com ilumina��o;
   - Movimenta��o de C�mera
   - Detecta��o de Colis�es;
   - Texturas;
   - Desenhos 3D;
*/


#include "util.hpp"
#include "texture.hpp"

typedef struct _Material {
GLfloat ambient[4];
GLfloat difuse[4];
GLfloat specular[4];
GLfloat emission[4];
GLint shininess;
} Material;

typedef struct _Light {
GLfloat pos[4];      //Posi��o da Luz
GLfloat ambient[4];  //GL_AMBIENT
GLfloat difuse[4];   //GL_DIFUSE
GLfloat specular[4]; //"Espelhamento" (GL_SPECULAR)
} Light;

//Posicao do observador no cen�rio...
typedef struct _Character {
GLfloat x;
GLfloat z;
} Character;

typedef struct _Camera {
       GLpoint3f eye, at, up;
       double fovy, nearPlane, farPlane;
} Camera; 

bool luz_ativada = true;
bool tex_ativada = true;
bool firstView = true;

// Parametros de proje��o
GLfloat fAspect;

//Origem  => Vetor de orienta��o no cen�rio (Teapot Vermelha na vista de cima)
//Observador => Posic�o da c�mera na cena (Quadro Branco na vista de cima
Character observador, origem;
Camera camera;

float spin_y = 0.0;

GLfloat border_color[4] = {1.0,0.0,0.0,1.0};
GLfloat env_color[4] = {0.0,1.0,0.0,1.0};

//Texturas:
GLuint texFloor;
GLuint texWall;
GLuint texPilar;
GLuint texRoof;
GLuint texBackDoor;
GLuint texFrontDoor;
GLuint texQuadro1;
GLuint texQuadro2;
GLuint texQuadro3;
GLuint texQuadro4;
GLuint texQuadro5;
GLuint texQuadro6;
GLuint texQuadro7;
GLuint texQuadro8;
GLuint texQuadro9;
GLuint texQuadro10;
GLuint texQuadro11;
GLuint texQuadro12;
GLuint texQuadro13;
GLuint texQuadro14;
GLuint texQuadro15;
GLuint texQuadro16;
GLuint texQuadro17;
GLuint texQuadro18;
GLuint texQuadro19;
GLuint texQuadro20;
GLuint texQuadro21;

Material material;
Light luzAmbiente;

int detect(float x, float z)
{
    int colide = 0;
    
    // Testa limites da sala em X
    if ((x > -775) && (x < 1375))
       colide = 0;
    else
       colide =1;
        
    if (!colide)
        //Testa limites da sala em Z
        if ((z > -175) && (z < 175))
           colide = 0;
        else
           colide = 1;
    
    //Testa colis�o em corredor 1
    //parte superior
    if (!colide)
       if ((x > -427) && (x < -173) && (z > 23) && (z < 173))
          colide = 1;
       else
           colide = 0;
          
    //parte inferior
    //em X
    if (!colide)
       if ((x > - 427) && (x < -173) && (z > -173) && (z < -23))
          colide = 1;
       else
           colide = 0;
       
   
    //Testa colis�o em corredor 2
    //parte superior
    if (!colide)
       if ((x < 427) && (x > 173) && (z > 23) && (z < 173))
          colide = 1;
       else
           colide = 0;
          
    //parte inferior
    //em X
    if (!colide)
       if ((x < 427) && (x > 173) && (z > -173) && (z < -23))
          colide = 1;
       else
           colide = 0;
           
    //Testa colis�o em corredor 3
    //parte superior
    if (!colide)
       if ((x < 1027) && (x > 773) && (z > 23) && (z < 173))
          colide = 1;
       else
           colide = 0;
          
    //parte inferior
    //em X
    if (!colide)
       if ((x < 1027) && (x > 773) && (z > -173) && (z < -23))
          colide = 1;
       else
           colide = 0;
           
    //Testa Colis�o para
    //Pilar 1
       if (!colide)
       if ((x < 122) && (x > 28) && (z < 122) && (z > 28))
          colide = 1;
       else
           colide = 0;
           
    //Pilar 2
       if (!colide)
       if ((x < 122) && (x > 28) && (z > -122) && (z < -28))
          colide = 1;
       else
           colide = 0;
           
    //Pilar 3
       if (!colide)
       if ((x > -122) && (x < -28) && (z < 122) && (z > 28))
          colide = 1;
       else
           colide = 0;
           
    //Pilar 4
       if (!colide)
       if ((x > -122) && (x < -28) && (z > -122) && (z < -28))
          colide = 1;
       else
           colide = 0;
    
           
    return colide;
       
}
 
void positionInit()
{

  camera.eye.set(0.0,60.0,0.0);
  camera.at.set(origem.x,60.0,origem.z);
  camera.up.set(0.0,1.0,0.0);
  camera.fovy = 60; 
  camera.nearPlane = 20.0;
  camera.farPlane = 10e20;
       
  observador.x = 0.0;
  observador.z = 0.0;  
  origem.x = 0.0;
  origem.z = 1.0;
}

void ambientLightInit()
{
  luzAmbiente.pos[0] = 0.0; 
  luzAmbiente.pos[1] = ALTURA_MUSEU; 
  luzAmbiente.pos[2] = 0.0;  
  luzAmbiente.pos[3] = 1.0;
  
  //Ambient Settings...
  luzAmbiente.ambient[0] = 1.0; 
  luzAmbiente.ambient[1] = 1.0; 
  luzAmbiente.ambient[2] = 1.0;  
  luzAmbiente.ambient[3] = 1.0;
  
  //Difuse Settings....
  luzAmbiente.difuse[0] = 1.0; 
  luzAmbiente.difuse[1] = 1.0; 
  luzAmbiente.difuse[2] = 1.0;  
  luzAmbiente.difuse[3] = 1.0;
  
  //Specular Settings...
  luzAmbiente.specular[0] = 1.0; 
  luzAmbiente.specular[1] = 1.0; 
  luzAmbiente.specular[2] = 1.0;  
  luzAmbiente.specular[3] = 1.0;
}

void materialInit()
{
  material.ambient[0] = 1.0; 
  material.ambient[1] = 1.0; 
  material.ambient[2] = 1.0;  
  material.ambient[3] = 1.0;
  
  material.difuse[0] = 1.0; 
  material.difuse[1] = 1.0; 
  material.difuse[2] = 1.0;  
  material.difuse[3] = 1.0;
  
  material.specular[0] = 1.0; 
  material.specular[1] = 1.0; 
  material.specular[2] = 1.0;  
  material.specular[3] = 1.0;
  
  material.emission[0] = 0.0; 
  material.emission[1] = 0.0; 
  material.emission[2] = 0.0;  
  material.emission[3] = 0.0;
  
  material.shininess = 20;
}

void loadTextures()
{
  texFloor = TextureLoad("floor.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texWall = TextureLoad("WALL.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texPilar = TextureLoad("PILAR.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texRoof = TextureLoad("metal.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texBackDoor = TextureLoad("BACKDOOR.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texFrontDoor = TextureLoad("frontdoor.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro1 = TextureLoad("matrixQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro2 = TextureLoad("matrixQuadro2.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro3 = TextureLoad("evoQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro4 = TextureLoad("battleQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro5 = TextureLoad("deusaQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro6 = TextureLoad("lainQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro7 = TextureLoad("witchesQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro8 = TextureLoad("viuvaQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro9 = TextureLoad("magmaQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro10 = TextureLoad("elektraQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro11 = TextureLoad("madQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro12 = TextureLoad("fofuchoQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro13 = TextureLoad("nudeQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro14 = TextureLoad("nude2Quadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro15 = TextureLoad("nude3Quadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro16 = TextureLoad("bebadoQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro17 = TextureLoad("kungfuQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro18 = TextureLoad("mousecatQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro19 = TextureLoad("lionQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro20 = TextureLoad("lion2Quadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
  texQuadro21 = TextureLoad("kikaQuadro.bmp", GL_FALSE, GL_LINEAR, GL_LINEAR_MIPMAP_NEAREST, GL_REPEAT);
}

// Inicializa��o
void SetupRC(void)
{
    // Especifica sistema de coordenadas do modelo
	glMatrixMode(GL_MODELVIEW);
	// Inicializa matriz modelview com a identidade
	glLoadIdentity();

    //Initializing the lights...
    ambientLightInit();
    cout << "Luz Ambiente Ativada!" << endl;
    
    //Initializing the materials...
    materialInit();
    cout << "Brilho Material Ativado!" << endl;
    
    //Initializing the position of observer...
    positionInit();
    
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
 
    glMaterialfv(GL_FRONT, GL_AMBIENT, material.ambient );
    glMaterialfv(GL_FRONT, GL_DIFFUSE, material.difuse );
    glMaterialfv(GL_FRONT, GL_SPECULAR, material.specular ); 
    glMaterialfv(GL_FRONT, GL_EMISSION, material.emission );   
    glMateriali(GL_FRONT, GL_SHININESS, material.shininess );
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, luzAmbiente.ambient);

    glLightfv(GL_LIGHT0, GL_AMBIENT, luzAmbiente.ambient );
    glLightfv(GL_LIGHT0, GL_DIFFUSE, luzAmbiente.difuse );
    glLightfv(GL_LIGHT0, GL_SPECULAR, luzAmbiente.specular );
    glLightfv(GL_LIGHT0, GL_POSITION, luzAmbiente.pos );

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

	// Habilita o modelo de tonaliza��o de Gouraud
	glShadeModel(GL_SMOOTH);
    
    //Habilita Z-Buffer
    glEnable(GL_DEPTH_TEST);
    
    //Habilita Remo��o de superf�cies ocultas
	glEnable(GL_CULL_FACE);
 
    //Sentido do desenho (hor�rio)
    glFrontFace(GL_CW);
    
    //inicializa��es de transparencia
	glEnable (GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glDepthFunc(GL_LEQUAL);

    //Inicializa�� de Texturas: 

    glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, env_color);
    glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border_color);

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    
    //Loading Textures....
    cout << "Lendo Texturas...." << endl;
    loadTextures();
}


/* Fun��o usada para especificar o volume de visualiza��o
*  no caso de proje��o perspectiva
*/  
void PerspectiveViewing(void)
{
	// Especifica manipulacao da matriz de proje��o
	glMatrixMode(GL_PROJECTION);
	// Inicializa matriz com a identidade
	glLoadIdentity();
 
    // Especifica a proje��o perspectiva
    gluPerspective(camera.fovy,fAspect,camera.nearPlane,camera.farPlane);
     
    // Especifica sistema de coordenadas do modelo
	glMatrixMode(GL_MODELVIEW);
	// Inicializa matriz modelview com a identidade
	glLoadIdentity();                            
 
    if (firstView)
    gluLookAt (observador.x, 60.0, observador.z, 
               observador.x+1.5*origem.x, 60.0,observador.z+1.5*origem.z, 
               camera.up.x, camera.up.y, camera.up.z);
    else
	//Vista de cima do cen�rio:
        gluLookAt (observador.x, 500.0, observador.z, 
               observador.x, 60.0,observador.z, 
               0, 0, 1);
}

// Chamada pela GLUT quando a janela � redimensionada
void ChangeSize(GLsizei w, GLsizei h)
{
	// Para previnir uma divis�o por zero
	if ( h == 0 )
		h = 1;

	// Especifica o tamanho da viewport
	glViewport(0, 0, w, h);
            
	// Calcula a corre��o de aspecto
	fAspect = (GLfloat)w/(GLfloat)h;

    PerspectiveViewing();  // no caso de perspectiva
}

void drawBackDoor(int x, int y, int z, int w)
{
  GLpoint3f p1(x,y,z+w), p12(x,y+ALTURA_PORTA,z +w),
             p2(x,y,z-w),p22(x,y+ALTURA_PORTA,z -w) ;

  if (tex_ativada)
  { 
     glEnable(GL_TEXTURE_2D);
     glBindTexture(GL_TEXTURE_2D, texBackDoor);
  }

  glBegin(GL_POLYGON);
   glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p12.x,p12.y,p12.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p22.x,p22.y,p22.z);
   glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
  glEnd();  

  glDisable(GL_TEXTURE_2D);
}

void drawFrontDoor(int x1, int x2, int y, int z)
{
  GLpoint3f p1(x1,y,z), p12(x1,y+ALTURA_PORTA,z),
            p2(x2,y,z), p22(x2,y+ALTURA_PORTA,z) ;

  if (tex_ativada)
  { 
     glEnable(GL_TEXTURE_2D);
     glBindTexture(GL_TEXTURE_2D, texFrontDoor);
  }

  glBegin(GL_POLYGON);
   glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p12.x,p12.y,p12.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p22.x,p22.y,p22.z);
   glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
  glEnd();  

  glDisable(GL_TEXTURE_2D);
}


//h => altura da parede
void drawWallMainRoom(int x, int y, int z, int w, int h)
{
//Paredes da Esquerda...
  GLpoint3f p1(x+8*w,y,z+2*w), p1_2(x+8*w,y+h,z+2*w),
            p2(x+8*w,y,z+8*w), p2_2(x+8*w,y+h,z+8*w),
            p5(x+8*w,y,z-8*w), p5_2(x+8*w,y+h,z-8*w),
            p6(x+8*w,y,z-2*w), p6_2(x+8*w,y+h,z-2*w);

//Paredes da Direita...
  GLpoint3f p9(x-8*w,y,z+8*w), p9_2(x-8*w,y+h,z+8*w),
            p10(x-8*w,y,z+2*w), p10_2(x-8*w,y+h,z+2*w),
            p13(x-8*w,y,z-2*w), p13_2(x-8*w,y+h,z-2*w),
            p14(x-8*w,y,z-8*w), p14_2(x-8*w,y+h,z-8*w);

//Paredes do Fundo...
  GLpoint3f p15(x+8*w,y,z+8*w), p15_2(x+8*w,y+h,z+8*w),
            p16(x-8*w,y,z+8*w), p16_2(x-8*w,y+h,z+8*w);

 //Paredes da Frente...
  GLpoint3f p17(x+8*w,y,z-8*w), p17_2(x+8*w,y+h,z-8*w),
            p18(x-8*w,y,z-8*w), p18_2(x-8*w,y+h,z-8*w);

            
  if (tex_ativada)
  { 
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texWall);
  }

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p6.x,p6.y,p6.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p5.x,p5.y,p5.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p5_2.x,p5_2.y,p5_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p6_2.x,p6_2.y,p6_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p1_2.x,p1_2.y,p1_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p2_2.x,p2_2.y,p2_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p10.x,p10.y,p10.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p9.x,p9.y,p9.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p9_2.x,p9_2.y,p9_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p10_2.x,p10_2.y,p10_2.z);
   glNormal3f(p10_2.x,p10_2.y,p10_2.z); glNormal3f(p9.x,p9.y,p9.z); 
   glNormal3f(p9.x,p9.y,p9.z); glNormal3f(p10.x,p10.y,p10.z); 
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p14.x,p14.y,p14.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p13.x,p13.y,p13.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p13_2.x,p13_2.y,p13_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p14_2.x,p14_2.y,p14_2.z);
   glNormal3f(p14_2.x,p14_2.y,p14_2.z); glNormal3f(p14.x,p14.y,p14.z);  
   glNormal3f(p13.x,p13.y,p13.z); glNormal3f(p13_2.x,p13_2.y,p13_2.z);
  glEnd();
  
  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p16.x,p16.y,p16.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p15.x,p15.y,p15.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p15_2.x,p15_2.y,p15_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p16_2.x,p16_2.y,p16_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p17.x,p17.y,p17.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p18.x,p18.y,p18.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p18_2.x,p18_2.y,p18_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p17_2.x,p17_2.y,p17_2.z);
  glEnd();

   glDisable(GL_TEXTURE_2D);
}

//h => altura da parede
void drawWallRoom2(int x, int y, int z, int w, int h)
{
//Paredes da Esquerda...
  GLpoint3f p1(x+8*w,y,z+2*w), p1_2(x+8*w,y+h,z+2*w),
            p2(x+8*w,y,z+8*w), p2_2(x+8*w,y+h,z+8*w),
            p5(x+8*w,y,z-8*w), p5_2(x+8*w,y+h,z-8*w),
            p6(x+8*w,y,z-2*w), p6_2(x+8*w,y+h,z-2*w);

//Paredes da Direita...
  GLpoint3f p9(x-8*w,y,z+8*w), p9_2(x-8*w,y+h,z+8*w),
            p14(x-8*w,y,z-8*w), p14_2(x-8*w,y+h,z-8*w);

//Paredes do Fundo...
  GLpoint3f p15(x+8*w,y,z+8*w), p15_2(x+8*w,y+h,z+8*w),
            p16(x-8*w,y,z+8*w), p16_2(x-8*w,y+h,z+8*w);

 //Paredes da Frente...
  GLpoint3f p17(x+8*w,y,z-8*w), p17_2(x+8*w,y+h,z-8*w),
            p18(x-8*w,y,z-8*w), p18_2(x-8*w,y+h,z-8*w);

            
  if (tex_ativada)
  { 
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texWall);
  }

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p6.x,p6.y,p6.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p5.x,p5.y,p5.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p5_2.x,p5_2.y,p5_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p6_2.x,p6_2.y,p6_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p1_2.x,p1_2.y,p1_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p2_2.x,p2_2.y,p2_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p14.x,p14.y,p14.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p9.x,p9.y,p9.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p9_2.x,p9_2.y,p9_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p14_2.x,p14_2.y,p14_2.z);
   glNormal3f(p14_2.x,p14_2.y,p14_2.z); glNormal3f(p9.x,p9.y,p9.z); 
   glNormal3f(p9.x,p9.y,p9.z); glNormal3f(p14.x,p14.y,p14.z); 
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p16.x,p16.y,p16.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p15.x,p15.y,p15.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p15_2.x,p15_2.y,p15_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p16_2.x,p16_2.y,p16_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p17.x,p17.y,p17.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p18.x,p18.y,p18.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p18_2.x,p18_2.y,p18_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p17_2.x,p17_2.y,p17_2.z);
  glEnd();

   glDisable(GL_TEXTURE_2D);
}


//h => altura da parede
void drawWallRoom(int x, int y, int z, int w, int h)
{
//Paredes da Esquerda...
  GLpoint3f p2(x+8*w,y,z+8*w), p2_2(x+8*w,y+h,z+8*w),
            p5(x+8*w,y,z-8*w), p5_2(x+8*w,y+h,z-8*w);

//Paredes da Direita...
  GLpoint3f p9(x-8*w,y,z+8*w), p9_2(x-8*w,y+h,z+8*w),
            p10(x-8*w,y,z+2*w), p10_2(x-8*w,y+h,z+2*w),
            p13(x-8*w,y,z-2*w), p13_2(x-8*w,y+h,z-2*w),
            p14(x-8*w,y,z-8*w), p14_2(x-8*w,y+h,z-8*w);

//Paredes do Fundo...
  GLpoint3f p15(x+8*w,y,z+8*w), p15_2(x+8*w,y+h,z+8*w),
            p16(x-8*w,y,z+8*w), p16_2(x-8*w,y+h,z+8*w);

 //Paredes da Frente...
  GLpoint3f p17(x+8*w,y,z-8*w), p17_2(x+8*w,y+h,z-8*w),
            p18(x-8*w,y,z-8*w), p18_2(x-8*w,y+h,z-8*w);

            
  if (tex_ativada)
  { 
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texWall);
  }

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p5.x,p5.y,p5.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p5_2.x,p5_2.y,p5_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p2_2.x,p2_2.y,p2_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p10.x,p10.y,p10.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p9.x,p9.y,p9.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p9_2.x,p9_2.y,p9_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p10_2.x,p10_2.y,p10_2.z);
   glNormal3f(p10_2.x,p10_2.y,p10_2.z); glNormal3f(p9.x,p9.y,p9.z); 
   glNormal3f(p9.x,p9.y,p9.z); glNormal3f(p10.x,p10.y,p10.z); 
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p14.x,p14.y,p14.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p13.x,p13.y,p13.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p13_2.x,p13_2.y,p13_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p14_2.x,p14_2.y,p14_2.z);
   glNormal3f(p14_2.x,p14_2.y,p14_2.z); glNormal3f(p14.x,p14.y,p14.z);  
   glNormal3f(p13.x,p13.y,p13.z); glNormal3f(p13_2.x,p13_2.y,p13_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p16.x,p16.y,p16.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p15.x,p15.y,p15.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p15_2.x,p15_2.y,p15_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p16_2.x,p16_2.y,p16_2.z);
  glEnd();

  glBegin(GL_POLYGON);
   glTexCoord2f(1.0,0.0); glVertex3f(p17.x,p17.y,p17.z);
   glTexCoord2f(0.0,0.0); glVertex3f(p18.x,p18.y,p18.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p18_2.x,p18_2.y,p18_2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p17_2.x,p17_2.y,p17_2.z);
  glEnd();

   glDisable(GL_TEXTURE_2D);
}


//=================================================
//Ch�o da sala principal
// x, y, z => centro da sala;
// w => largura;
//=================================================
void drawFloorMainRoom(int x, int y, int z, int w)
{
  GLpoint3f p1(x+200*w,y,z-200*w), p2(x+200*w,y,z+200*w),
            p3(x-200*w,y,z+200*w), p4(x-200*w,y,z-200*w);

  if (tex_ativada)
  { 
     glEnable(GL_TEXTURE_2D);
     glBindTexture(GL_TEXTURE_2D, texFloor);
  }

  glBegin(GL_POLYGON);
   glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(REPEAT_TEXTURA*1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
   glTexCoord2f(REPEAT_TEXTURA*1.0,REPEAT_TEXTURA*1.0); glVertex3f(p3.x,p3.y,p3.z);
   glTexCoord2f(0.0,REPEAT_TEXTURA*1.0); glVertex3f(p4.x,p4.y,p4.z);
  glEnd();  

  glDisable(GL_TEXTURE_2D);
}

//=================================================
//Ch�o da sala principal
// x, y, z => centro da sala;
// w => largura;
//=================================================
void drawRoofMainRoom(int x, int y, int z, int w)
{
  GLpoint3f p1(x+200*w,y,z-200*w), p2(x+200*w,y,z+200*w),
            p3(x-200*w,y,z+200*w), p4(x-200*w,y,z-200*w);

  if (tex_ativada)
  { 
     glEnable(GL_TEXTURE_2D);
     glBindTexture(GL_TEXTURE_2D, texRoof);
  }

  glColor3f(0.6,0.6,0.6);
  glBegin(GL_POLYGON);
   glTexCoord2f(0.0,0.0); glVertex3f(p3.x,p3.y,p3.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p2.x,p2.y,p2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(1.0,0.0); glVertex3f(p4.x,p4.y,p4.z);
  glEnd();  
  
  glDisable(GL_TEXTURE_2D);
}

void drawMoldura(int x, int y, int z, GLuint quadro)
{
  GLpoint3f p1(x+TAM_QUADRO,y-TAM_QUADRO,z), p2(x+TAM_QUADRO,y+TAM_QUADRO,z),
            p3(x-TAM_QUADRO,y+TAM_QUADRO,z), p4(x-TAM_QUADRO,y-TAM_QUADRO,z);

  if (tex_ativada)
  {  
     glEnable(GL_TEXTURE_2D);
     glBindTexture(GL_TEXTURE_2D, quadro);
  }
  
  glColor3f(0.6,0.6,0.6);
  glBegin(GL_POLYGON);
   glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
   glTexCoord2f(0.0,1.0); glVertex3f(p2.x,p2.y,p2.z);
   glTexCoord2f(1.0,1.0); glVertex3f(p3.x,p3.y,p3.z);
   glTexCoord2f(1.0,0.0); glVertex3f(p4.x,p4.y,p4.z);
  glEnd();  

  glDisable(GL_TEXTURE_2D);
}

//Desenha as colunas (w -> largura do pilar)
void drawPilar(int x, int y, int z, int w)
{
   GLpoint3f p1(x+w,y,z-w), p12(x+w,y+ALTURA_MUSEU,z-w), 
             p2(x+w,y,z+w), p22(x+w,y+ALTURA_MUSEU,z+w),
             p3(x-w,y,z+w), p32(x-w,y+ALTURA_MUSEU,z+w),
             p4(x-w,y,z-w), p42(x-w,y+ALTURA_MUSEU,z-w);
   
  if (tex_ativada)
  {  
      glEnable(GL_TEXTURE_2D);
      glBindTexture(GL_TEXTURE_2D, texPilar);  
  }

   glBegin(GL_POLYGON);
    glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
    glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p22.x,p22.y,p22.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p12.x,p12.y,p12.z);
   glEnd();  
   
   glBegin(GL_POLYGON);
    glTexCoord2f(0.0,0.0); glVertex3f(p4.x,p4.y,p4.z);
    glTexCoord2f(1.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p12.x,p12.y,p12.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p42.x,p42.y,p42.z);
   glEnd();  

   glBegin(GL_POLYGON);
    glTexCoord2f(0.0,0.0); glVertex3f(p3.x,p3.y,p3.z);
    glTexCoord2f(1.0,0.0); glVertex3f(p4.x,p4.y,p4.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p42.x,p42.y,p42.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p32.x,p32.y,p32.z);
   glEnd();  
   
   glBegin(GL_POLYGON);
    glTexCoord2f(0.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
    glTexCoord2f(1.0,0.0); glVertex3f(p3.x,p3.y,p3.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p32.x,p32.y,p32.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p22.x,p22.y,p22.z);
   glEnd();  

   glBegin(GL_POLYGON);
    glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
    glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p22.x,p22.y,p22.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p12.x,p12.y,p12.z);
   glEnd();  

   glDisable(GL_TEXTURE_2D);
}

//Corredores que ligam as salas..
// w ==> largura da sala
// h ==> altura do museu
// l ==> profundidade do corredor
void drawConection(int x, int y, int z, int w, int h, int l)
{
 //Ch�o do corredor:
 GLpoint3f p1(x-5*l,y,z-2*w), p2(x+5*l,y,z-2*w),
           p3(x+5*l,y,z+2*w), p4(x-5*l,y,z+2*w);

  if (tex_ativada)
  {  
      glEnable(GL_TEXTURE_2D);
      glBindTexture(GL_TEXTURE_2D, texWall);  
  }

 //Paredes:
 glBegin(GL_POLYGON);
    glTexCoord2f(1.0,0.0); glVertex3f(p2.x,p2.y,p2.z);
    glTexCoord2f(0.0,0.0); glVertex3f(p1.x,p1.y,p1.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p1.x,p1.y+h,p1.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p2.x,p2.y+h,p2.z);
 glEnd();

 glBegin(GL_POLYGON);
    glTexCoord2f(1.0,0.0); glVertex3f(p4.x,p4.y,p4.z);
    glTexCoord2f(0.0,0.0); glVertex3f(p3.x,p3.y,p3.z);
    glTexCoord2f(0.0,1.0); glVertex3f(p3.x,p3.y+h,p3.z);
    glTexCoord2f(1.0,1.0); glVertex3f(p4.x,p4.y+h,p4.z);
 glEnd();
 
 glDisable(GL_TEXTURE_2D);
}

// Chamada para fazer o desenho
void RenderScene(void)
{

	// Limpa a janela
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
    //Ch�o:
    drawFloorMainRoom(0, 0, 0, LARGURA_MUSEU);
    
    //Teto:
    drawRoofMainRoom(0, ALTURA_MUSEU, 0, LARGURA_MUSEU);
    
    //Salas:
    //Principal:
    drawWallMainRoom(0,0,0,LARGURA_MUSEU,ALTURA_MUSEU);
    //Primeira da Esquerda:
    drawWallMainRoom(2*(8*LARGURA_MUSEU+5*PROFUNDIDADE_CORREDOR),0,0,LARGURA_MUSEU,ALTURA_MUSEU);
    //Primeira da Direita:
    drawWallRoom2(-(8*LARGURA_MUSEU+2*5*PROFUNDIDADE_CORREDOR+8*LARGURA_MUSEU),0,0,LARGURA_MUSEU,ALTURA_MUSEU);
    //�ltima da Esquerda:
    drawWallRoom(4*(8*LARGURA_MUSEU+5*PROFUNDIDADE_CORREDOR),0,0,LARGURA_MUSEU,ALTURA_MUSEU);

    
    //Pilares:
    drawPilar(3*LARGURA_MUSEU,0,3*LARGURA_MUSEU,20);
    drawPilar(-3*LARGURA_MUSEU,0,3*LARGURA_MUSEU,20);
    drawPilar(3*LARGURA_MUSEU,0,-3*LARGURA_MUSEU,20);
    drawPilar(-3*LARGURA_MUSEU,0,-3*LARGURA_MUSEU,20);
    
    //Corredores:
    drawConection(8*LARGURA_MUSEU+5*PROFUNDIDADE_CORREDOR,0,0,LARGURA_MUSEU,ALTURA_MUSEU,PROFUNDIDADE_CORREDOR);
    drawConection(2*(8*LARGURA_MUSEU+5*PROFUNDIDADE_CORREDOR)+8*LARGURA_MUSEU+5*PROFUNDIDADE_CORREDOR,0,0,LARGURA_MUSEU,ALTURA_MUSEU,PROFUNDIDADE_CORREDOR);
    drawConection(-(8*LARGURA_MUSEU+5*PROFUNDIDADE_CORREDOR),0,0,LARGURA_MUSEU,ALTURA_MUSEU,PROFUNDIDADE_CORREDOR);
    
    //Porta:
    drawBackDoor(-799,0,150,LARGURA_PORTA);
    drawFrontDoor(-50, 50, 0, -199);

    //Ar-condicionado:
    //drawArCondicionado(0,0,0,20,10,texAirCond);

    //Quadros:    
    
    glPushMatrix();
    glTranslatef(-700.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro12);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-600.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro11);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-500.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro10);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-100.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro2);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro3);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(100.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro1);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(500.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro4);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(600.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro5);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(700.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro6);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(1100.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro7);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(1200.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro8);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(1300.0,ALTURA_MUSEU/2,8*LARGURA_MUSEU-1);
    drawMoldura(0,0,0,texQuadro9);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1300.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro13);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(1200.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro15);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(1100.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro14);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-500.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro16);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-600.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro17);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(500.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro19);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(600.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro20);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(700.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro21);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(-700.0,ALTURA_MUSEU/2,-199);
    glRotatef(180, 0, 1, 0);
    drawMoldura(0,0,0,texQuadro18);
    glPopMatrix();
    
    
    
//Non First View:
    if (!firstView)
    {
      glColor3f(1.0,1.0,1.0);
      glPushMatrix();
      glTranslatef(observador.x,62.0,observador.z);
      glutSolidCube(5.0);
      glPopMatrix();
    
      glColor3f(1.0,0.0,0.0);    
      glPushMatrix();
      glTranslatef(observador.x+origem.x*12,62.0,observador.z+origem.z*12);
      glutSolidTeapot(5.0);
      glPopMatrix();
    }

    glColor3f(0.6,0.6,0.6); 
	// Execu��o dos comandos de desenho
	glFlush();
    glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y)
{
  float auxX, auxZ =0;
  switch(key)
  {
   case '\033': case 'q': case 'Q': exit(0); break;
   case 'w': case 'W': auxX = observador.x + STEP*origem.x;
                       auxZ = observador.z + STEP*origem.z;                        
                       break;
   case 's': case 'S': auxX = observador.x - STEP*origem.x;
                       auxZ = observador.z - STEP*origem.z;
                       break;
   case 'a': case 'A': spin_y+=4.5;
                       auxX = observador.x;
                       auxZ = observador.z; 
                       break;
   case 'd': case 'D': spin_y-=4.5;
                       auxX = observador.x;
                       auxZ = observador.z; 
                       break;
   case 'l': case 'L': if (luz_ativada)
                       {
                           cout << "Luzes Desativadas!" << endl;
                           glDisable(GL_LIGHTING); 
                           luz_ativada = false;
                       }
                       else
                       {
                           cout << "Luzes Ativadas!" << endl;
                           glEnable(GL_LIGHTING);
                           luz_ativada = true;
                       }
		       auxX = observador.x;
		       auxZ = observador.z;
                       break;
   case 't': case 'T': if (tex_ativada) 
                       {
                           cout << "Texturas Desativadas!" << endl;
                           tex_ativada = false;
                       }
                       else
                       {
                           cout << "Luzes Ativadas!" << endl;
                           tex_ativada = true;
                       }
		       auxX = observador.x;
		       auxZ = observador.z;
                       break;

   case 'r': case 'R': if (firstView) firstView = false;
             	       else firstView = true;
	     	       auxX = observador.x;
	     	       auxZ = observador.z;
             	       break;
   
   case 'k': case 'K':  printf("X: %g\n Z: %g\n\n", observador.x, observador.z); 
                        break;
  }

  if (!detect(auxX, auxZ))
    {
    
       observador.x = auxX;
       observador.z = auxZ;
       origem.x = sin(degToRad(spin_y));
       origem.z = cos(degToRad(spin_y));
       
       printf("X: %g\n Z: %g\n\n", observador.x, observador.z); 

       PerspectiveViewing();
       glutPostRedisplay();
    }
}

void SpecialKeys(int key, int x, int y)
	{
     float auxX, auxZ =0;
    switch(key)
    {
      case GLUT_KEY_UP: auxX = observador.x + STEP*origem.x;
                        auxZ = observador.z + STEP*origem.z;                        
                        break;
      
      case GLUT_KEY_DOWN: auxX = observador.x - STEP*origem.x;
                          auxZ = observador.z - STEP*origem.z;
                          break;
      
      case GLUT_KEY_LEFT: spin_y+=4.5;
                          auxX = observador.x;
                          auxZ = observador.z; 
                          break;
      
      case GLUT_KEY_RIGHT: spin_y-=4.5;
                          auxX = observador.x;
                          auxZ = observador.z; 
                          break;
    }

    printf("AuxX: %g\n AuxZ: %g\n\n", auxX, auxZ);
    
    if (!detect(auxX, auxZ))
    {
    
       observador.x = auxX;
       observador.z = auxZ;
       origem.x = sin(degToRad(spin_y));
       origem.z = cos(degToRad(spin_y));
       
       printf("X: %g\n Z: %g\n\n", observador.x, observador.z); 

       PerspectiveViewing();
       glutPostRedisplay();
    }
      
 }

// Programa Principal
int main(void)
{
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
 	glutInitWindowSize(1024,768);
	glutCreateWindow("MUSEU 3D");
	glutFullScreen();
	glutDisplayFunc(RenderScene);
	glutReshapeFunc(ChangeSize);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(SpecialKeys);
    glutSetCursor(GLUT_CURSOR_NONE);
	SetupRC();
	glutMainLoop();
	return 0;
}
