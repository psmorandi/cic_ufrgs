#ifndef _PSMJ_HPP
#define _PSMJ_HPP

#include <GL/glut.h>
#include <math.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>

#define PI 3.141593
#define ALTURA_MUSEU 150
#define LARGURA_MUSEU 25
#define TAM_QUADRO 20
#define PROFUNDIDADE_CORREDOR 20
#define LARGURA_PORTA 25
#define ALTURA_PORTA 100 
#define REPEAT_TEXTURA 500
#define ESQUERDA 1
#define SPEED 10.0
#define STEP 4.5
#define LARGURA_AR 10

using namespace std;

float degToRad(float angle){
	float temp;
	
	/*if (angle > 360)
		angle = 0;
	if (angle < 0)
		angle = 360;*/

	temp = (PI*angle)/180;

	return(temp);
}

class GLcolor3f{
public:
       float r, g, b;
       GLcolor3f(){r = 0.6; g = 0.6; b = 0.6;}
       GLcolor3f( float rr, float gg, float bb ){r = rr; g = gg; b = bb;}
       void set( float rr, float gg, float bb ){r = rr; g = gg; b = bb;}
       void set( GLcolor3f& c ){r = c.r; g = c.g; b = c.b;}
       void apply(){ glClearColor(r,g,b,1.0); }
};

class GLbackground3f{
private:
        GLcolor3f cor;
public:
       GLbackground3f( float rr, float gg, float bb ){ cor.r = rr; cor.g = gg; cor.b = bb; }
       void set(){ cor.apply(); }
       void clearScreen(){ glClear(GL_COLOR_BUFFER_BIT); }
};

class GLpoint2i {
public:
       int x, y;
       GLpoint2i(){ x = y = 0; }
       GLpoint2i( int xx, int yy ){ x = xx; y = yy; }
       void set( int xx, int yy ){ x = xx; y = yy; }
       void set( GLpoint2i& p ){ x = p.x; y = p.y; }
};

class GLpoint2f {
public:
       float x, y;
       GLpoint2f(){ x = y = 0; }
       GLpoint2f( float xx, float yy ){ x = xx; y = yy; }
       void set( float xx, float yy ){ x = xx; y = yy; }
       void set( GLpoint2f& p ){ x = p.x; y = p.y; }
       GLpoint2f distance( GLpoint2f& p )
       {
          GLpoint2f d;
          d.set( p.x - x, p.y - y );
          return d;
       }
};

class GLpoint3f {
public:
       float x, y, z;
       GLpoint3f(){x = y = z = 0;}
       GLpoint3f( float xx, float yy, float zz ){x = xx; y = yy; z = zz;}
       void set( float xx, float yy, float zz ){ x = xx; y = yy; z = zz;}
       void set( GLpoint3f& p ){ x = p.x; y = p.y; z = p.z;}
       GLpoint3f distance( GLpoint3f& p )
       {
          GLpoint3f d;
          d.set( p.x - x, p.y - y, p.z - z );
          return d;
       }
};

class GLvector3f {
public:
       float x,y,z;
       
       GLvector3f(){x=y=z=0;}
       GLvector3f(float xx, float yy, float zz){x=xx; y=yy; z=zz; }
       GLvector3f(GLvector3f& v){x=v.x; y=v.y; z=v.z;}
       void set(float xx, float yy, float zz){ x=xx; y=yy; z=zz; }
       void set (GLvector3f& v){ x=v.x; y=v.y; z=v.z; }
       void flip(){ x=-x; y=-y; z=-z; }
       void setDiff(GLpoint3f a, GLpoint3f b){ x=a.x-b.x; y=a.y-b.y; z=a.z-b.z;}
       void normalize()
       { 
         double size = x*x + y*y + z*z;
         
         if (size < 0.0000001)
         {
           cout << "ERRO!!!! vetor � (0,0,0)" << endl;
           return;
         }
         float scale = 1.0/(float)sqrt(size);
         x *= scale; y *= scale; z *= scale;
       }
       float dot(GLvector3f v)
       {
         return x*v.x + y*v.y + z*v.z;
       }
       GLvector3f cross(GLvector3f v)
       {
         GLvector3f c(y*v.z - z*v.y, z*v.x - x*v.z, x*v.y - y*v.x);
         return c; 
       }
             
};

#endif
