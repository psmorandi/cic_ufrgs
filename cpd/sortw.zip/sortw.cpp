//
//  TRABALHO DE CLASSIFICACAO E PESQUISA DE
//  DADOS
//
//  Arquivo: sort.cpp
//  Objetivo: Funcoes para ordenar um vetor de chaves, versao para 
//            windows (dos);
//  Aluno: Paulo Sergio Morandi Junior
//  Prof.: Manuel Menezes de Oliveira Neto
//------------------------------------------------------------------------------


#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>   // Para funcao de alocacao dinamica
#include <fstream.h>  // Para manipulacao de arquivos
#include <string.h>

#define FALSE 0
#define TRUE !FALSE

class Sort {

	public:
		void Quicksort( int* , int, int );
		void Bublesort( int* , int );
	private:
		//--------------------------------------------------------
		// Funcao que particiona o vetor de chaves,
		// usada somente pela funcao Quicksort
		// c: ponteiro para o vetor de chaves
		// i: ponteiro para o inicio de um segmento do vetor
		// f: ponteiro para o fim de um segmento do vetor
		// k: valor retornado que aponta para o pivo
		//--------------------------------------------------------
		void Sort::Particao( int* c, int i, int f, int& k){
			int i1 = i, f1 = f, cp = c[i1];
			int esq = TRUE;

			while( i1 < f1 )
				if ( esq )
					if ( cp >= c[f1] )
					{
						c[i1] = c[f1];
						i1++; esq = FALSE;
					}
					else f1--;
				else
					if ( cp < c[i1] )
					{
						c[f1] = c[i1];
						f1--; esq = TRUE;
					}
					else i1++;
			k = i1; c[k] = cp;
		}
};


//-------------------------------------------------------
// METODO DO BUBLESORT
// c: ponteiro para o vetor de chaves
// n: numero de chaves
// -------------------------------------------------------
void Sort::Bublesort( int* c, int n){
	int troca=TRUE;
	int m = n-1, k=1, i, ch;

	while ( troca )
	{
		troca=FALSE;
		for(i=0;i<m;i++)
			if ( c[i] > c[i+1] )
			{
				ch     = c[i];
				c[i]   = c[i+1];
				c[i+1] = ch;
				k = i; 		//Posicao da ultima troca
				troca = TRUE;
			}
		m = k;      //Vetor jah estah ordenado de m+1 ateh n
	}
}

//------------------------------------------------------------
// METODO DO QUICKSORT (PARTICAO E TROCA)
// funcao Quicksort:
// 	c: ponteiro para o vetor de chaves
// 	i: ponteiro para o inicio de um segmento do vetor
// 	f: ponteiro para o fim de um segmento do vetor
// -----------------------------------------------------------
void Sort::Quicksort( int* c, int i, int f ){
	Sort Chama;
	int k;

	if ( f > i )  //testa se segmento nao eh unitario
	{
		Chama.Particao( c, i, f, k);  //Particiona
		Quicksort( c, i, k-1 ); //Ordena S1
		Quicksort( c, k+1, f ); //Ordena S2
	}

}

int main(int argc, char *argv[]){
    int i, dim, *chaves;
	ifstream arq, saida;
	Sort funcoes;

if (argc < 3)
{
	cout << "UFRGS - Universidade Federal do Rio Grande do sul" << endl;
	cout << "PSMJ FILE SORT - final version - NOV/2002" << endl;
	cout << "Autor: Paulo Sergio Morandi Junior" << endl;
	cout << "Uso: "<<argv[0]<<" <opcao_sort> <nome_arq>" << endl << endl;
	cout << "Opcoes de sort: " << endl;
	cout << "-q\t=> Quicksort" << endl;
	cout << "-b\t=> Bublesort" << endl << endl;
	cout << "Bugs e reclamacoes - psmj@ibest.com.br" << endl;
}
else
{
	 arq.open( argv[2] ); //Abre o arquivo somente para leitura
	 if ( !arq )          //Verifica se conseguiu abrir o arquivo
			cout << "Erro: " << argv[2] << " - Arquivo nao encontrado" << endl;
	 else
	 {
		if ( !(strcmp(argv[1],"-b")) )
		{
		//Selecionado a opcao de Bublesort
			arq >> dim;
			chaves = (int *)calloc(dim, sizeof(int));
			i = 0;
			while( i < dim )
			{
			   arq >> chaves[i];
			   i++;
			}
			funcoes.Bublesort( chaves, dim );
		}
		else
			if( !( strcmp(argv[1],"-q") ) )
				{
				//Selecionado a opcao de Quicksort
				arq >> dim;
				chaves = (int *)calloc(dim, sizeof(int));
				i = 0;
				while( i < dim )
				{
					arq >> chaves[i];
					i++;
				}
			funcoes.Quicksort( chaves, 0, dim-1 );
			}
			else
			{
				cout << "Error: \"" << argv[1] << "\" eh uma opcao invalida" << endl;
				exit(-1);
			}
		cout << "Vetor final ordenado em \"ordenado.txt\" " << endl;
		freopen( "ordenado.txt","w",stdout);
		for( i=0; i < dim; i++)
			 cout << chaves[i] << endl;
	arq.close();
	saida.close();
	 }

}
	  return 0;
}
