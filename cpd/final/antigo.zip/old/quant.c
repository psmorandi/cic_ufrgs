#include <assert.h>
#include "types.h"
#include "lista.h"

byte MEDIA_R(Nodo *a, Nodo *b)
{
	int rf1, rf2;
        int media;
        rf1 = a->red * a->freq;
        rf2 = b->red * b->freq;
        media = rf1 + rf2;
        media /= (a->freq + b->freq);
        return (byte)media;
}

byte MEDIA_G(Nodo *a, Nodo *b)
{
	int rf1, rf2;
        int media;
        rf1 = a->green * a->freq;
        rf2 = b->green * b->freq;
        media = rf1 + rf2;
        media /= (a->freq + b->freq);
        return (byte)media;
}

byte MEDIA_B(Nodo *a, Nodo *b)
{
	int rf1, rf2;
        int media;
        rf1 = a->blue * a->freq;
        rf2 = b->blue * b->freq;
        media = rf1 + rf2;
        media /= (a->freq + b->freq);
        return (byte)media;
}



void quantiza_freq(Lista *cores, int max)
{
	Nodo *tmp, *best;
	while (cores->num_nodos > max)
        {
		tmp = RemoveUlt(cores);
                assert(tmp);		// sem problemas, nao deve acontecer
                best = NearestMatch(cores, tmp->red, tmp->green, tmp->blue);
                best->red = MEDIA_R(best, tmp);
                best->green = MEDIA_G(best, tmp);
                best->blue = MEDIA_B(best, tmp);
                best->freq += tmp->freq;
                Reposiciona(cores, best);
        }
}
