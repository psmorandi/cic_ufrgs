#ifndef _TYPES_H
#define _TYPES_H
typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;

typedef enum {TRUE,FALSE} boolean;

typedef struct {
	byte red;
	byte green;
	byte blue;
} rgbpallete;

#endif
