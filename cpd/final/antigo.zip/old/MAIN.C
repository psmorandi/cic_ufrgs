#include "types.h"
#include "lista.h"
#include <stdio.h>

void main(int argc, char *argv[])
{
	int i;
	Lista *l;
        Nodo *tmp;
        if (argc < 2)
        	argv[1] = "allibed.bmp";
	grOn();
	outp(0x3c8, 0);
	for (i=0;i<256;i++)
	{
		outp(0x3c9, i%64);
		outp(0x3c9, i%64);
		outp(0x3c9, i%64);
	}

	l = loadbmp(argv[1]);
//	grOff();
        ordena(l);
//        quantiza_freq(l, 256);

//        grOn();
        
/*        outp(0x3c8, 0);

        tmp = l->prim;
	for (i=0;i<l->num_nodos;i++)
	{
		outp(0x3c9, tmp->blue);
		outp(0x3c9, tmp->green);
		outp(0x3c9, tmp->red);
                tmp = tmp->prox;
	}
        for (i=0;i<256-l->num_nodos;i++)
        {
        	outp(0x3c9, 0);
        	outp(0x3c9, 0);
        	outp(0x3c9, 0);
        }
        
        reloadBmp(argv[1], l);
*/
        fflush(stdout);
        while (getch() != '\x1b');
        grOff();
        printf("%d\n", l->num_nodos);
        return;
}

