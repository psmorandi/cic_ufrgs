struct filehdr {
	word type;
	dword size;
	word resv[2];
	dword offbits;
} __attribute__ ((packed));

struct infohdr {
	dword size;
	dword width;
	dword height;
	word planes;
	word bitcount;
	dword compression;
	dword imgsz;
	dword resv[4];
} __attribute__ ((packed));

struct rgbquad {
	byte blue;
	byte green;
	byte red;
	byte resv;
};

struct bitmapinfo {
 struct infohdr hdr;
 struct rgbquad pal[256];
};

struct bitmaphdr {
	struct filehdr hdr;
	struct infohdr info;
} __attribute__ ((packed));
