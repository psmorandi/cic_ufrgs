#include <stdio.h>
#include <stdlib.h>
#include "types.h"
#include "lista.h"
#include "bitmap.h"

void reloadBmp(char *name, Lista *lista)
{
  byte cores[3];
  byte cor;
  int x,y;
  struct bitmaphdr bmp;
  dword i,j,k;
  int p_cor;
  int tam_lido;
  FILE *in;

  in = NULL;
  if ((in=fopen(name,"rb"))==NULL)
	exit(-1);

  tam_lido = fread(&bmp,1,sizeof(bmp),in);
  fseek(in,bmp.hdr.offbits,SEEK_SET);

  j=bmp.info.width;
  i=(j%4);
//  if (i!=0) i=4-i;
  for (y=bmp.info.height-1;y>=0;y--) {
      for (x=0;x<bmp.info.width;x++) {
          for (p_cor=0;p_cor<3;p_cor++)
              cores[p_cor] = getc(in);

          cor = MaisProxPos(lista, cores[0], cores[1], cores[2]);
	  setpix(x, y, cor);
      }
      for (j=0;j<i;j++)
          (void)getc(in);
  }
  fclose(in);
}

Lista *loadbmp(char *name)
{
  byte cor;
  byte cores[3];
  int x,y;
  struct bitmaphdr bmp;
  dword i,j,k;
  int p_cor;
  int tam_lido;
  FILE *in;
  Lista *l;

  l = CriaLista();

  in = NULL;
  if ((in=fopen(name,"rb"))==NULL)
	exit(-1);

  tam_lido = fread(&bmp,1,sizeof(bmp),in);
  fseek(in,bmp.hdr.offbits,SEEK_SET);

  j=bmp.info.width;
  i=(j%4);
//  if (i!=0) i=4-i;
  for (y=bmp.info.height-1;y>=0;y--) {
      for (x=0;x<bmp.info.width;x++) {
          cor = 0;
	  for (p_cor=0;p_cor<3;p_cor++)
          {
              cores[p_cor] = getc(in);
              cor+=cores[p_cor]>>2;
	  }
          InsereNodo(l, cores[0], cores[1], cores[2]);

          cor /= 3;
          setpix(x, y, cor);
      }
      for (j=0;j<i;j++)
          (void)getc(in);

  }
  fclose(in);
  return l;
}

