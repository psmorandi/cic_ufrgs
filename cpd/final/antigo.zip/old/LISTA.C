#include <stdlib.h>
#include <assert.h>
#include "types.h"
#include "lista.h"

Lista *CriaLista()
{
	Lista *tmp;
	tmp = (Lista *)calloc(1, sizeof(Lista));
	tmp->prim = tmp->ult = NULL;
	tmp->num_nodos = 0;
	return tmp;
}

int cmp(int a, int b)
{
	if (abs(a-b) < 2)
        	return 1;
        return 0;
}

void InsereNodo(Lista *l, byte r, byte g, byte b)
{
	int i;
	Nodo *tmp;
	tmp = l->prim;
	if (tmp == NULL)
	{ // primeiro nodo
		tmp = (Nodo *)calloc(1, sizeof(Nodo));
		assert(tmp);
		tmp->prox = NULL;
		tmp->ant = NULL;
		l->prim = tmp;
		l->ult = tmp;
		tmp->red = r;
		tmp->green = g;
		tmp->blue = b;
		tmp->freq = 1;
		l->num_nodos++;
		return;
	}
	for (i=0;i<l->num_nodos; i++)
	{
		if (cmp(tmp->red,r) && cmp(tmp->green,g) && cmp(tmp->blue, b))
		{
			tmp->freq++;
			return;
		}
		tmp = tmp->prox;
	}
	if (tmp == NULL)
	{
		tmp = (Nodo *)calloc(1, sizeof(Nodo));
		assert(tmp);
		tmp->prox = NULL;
		tmp->ant = l->ult;
		l->ult->prox = tmp;
		l->ult = tmp;
		tmp->red = r;
		tmp->green = g;
		tmp->blue = b;
		tmp->freq = 1;
		l->num_nodos++;
	}
}

void ImprLista(Lista *l)
{
	Nodo *tmp;
	int i;
	tmp = l->prim;
	for (i=0;i<l->num_nodos;i++) {
		printf("(%d, %d, %d) --> %d\n", tmp->red, tmp->green, tmp->blue, tmp->freq);
		tmp = tmp->prox;
	}
}

Nodo *NearestMatch(Lista *l, byte r, byte g, byte b)
{
	Nodo *tmp, *maisprox;
	int best_dif;

        int dif;

        best_dif = 256;		// caso impossivel
        maisprox = NULL;

        tmp = l->prim;
        while (tmp != NULL)
        {
		dif = abs(r-tmp->red)+ abs(g-tmp->green) + abs(b-tmp->blue);
                if (dif < best_dif)
                {
                	best_dif = dif;
                        maisprox = tmp;
                }
                tmp = tmp->prox;
        }
        return maisprox;
}

Nodo *RemoveUlt(Lista *l)
{
	Nodo *tmp;
        if (l->prim == NULL)
        	return NULL;
                
        tmp = l->ult;
        if (l->num_nodos > 1)
        {
        	l->ult = l->ult->ant;
                l->ult->prox = NULL;
        }
        else
        {
        	l->prim = l->ult = NULL;
        }

        l->num_nodos--;
	return tmp;
}

int MaisProxPos(Lista *l, byte r, byte g, byte b)
{
	Nodo *tmp;
	int best_dif, best_pos;

        int pos;
        int dif;

        best_dif = 256;		// caso impossivel
        best_pos = l->num_nodos;

        tmp = l->prim;
        pos = 0;
        while (tmp != NULL)
        {
		dif = abs(r-tmp->red)+ abs(g-tmp->green) + abs(b-tmp->blue);
                if (dif < best_dif)
                {
                	best_dif = dif;
                        best_pos = pos;
                }
                pos++;
                tmp = tmp->prox;
        }
        return best_pos;
}

