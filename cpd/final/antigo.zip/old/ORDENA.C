#include <stdlib.h>
#include <stdio.h>
#include "types.h"
#include "lista.h"

#define ORDENA(campo) \
void ordena_##campo (Lista *l) \
{ \
	int i;\
        Nodo *ordenada, *fim_ord; \
        Nodo *lista;\
        Nodo *tmp;\
        i = l->num_nodos;\
\
        /* inicializa listas */\
        ordenada = l->prim;\
        fim_ord = ordenada;\
        lista = ordenada->prox;\
\
        /* desfaz links */\
        ordenada->prox = NULL;\
        lista->ant = NULL;\
\
        while (lista != NULL)\
        {\
/*        	gotoxy(1, 1);\
                cprintf("nodos restantes: %d   ", i);*/\
\
		i--;\
                tmp = ordenada;\
                while ((tmp != NULL) && (tmp->campo > lista->campo))\
                        tmp = tmp->prox;\
\
                if (tmp == NULL)\
                {\
                        /* nao achou posicao, insere no final da lista */\
                        fim_ord->prox = lista;\
                        lista->ant = fim_ord;\
                        fim_ord = lista;\
                        lista = lista->prox;\
                        /* desfaz links */\
                        fim_ord->prox = NULL;\
                        lista->ant = NULL;\
                }\
                else\
                {\
                        /* achou posicao, tmp eh proximo nodo */\
                        if (tmp->ant == NULL)\
                        {\
                                /* a posicao eh a 1a */\
                                ordenada = lista;\
                                lista = lista->prox;\
\
                                ordenada->prox = tmp;\
                                tmp->ant = ordenada;\
                                ordenada->ant = NULL;\
                                lista->ant = NULL;\
                        }\
                        else\
                        {\
                                lista->ant = tmp->ant;\
                                tmp->ant->prox = lista;\
                                tmp->ant = lista;\
                                lista = lista->prox;\
                                tmp->ant->prox = tmp;\
                                lista->ant = NULL;\
                        }\
                }\
        }\
        l->prim = ordenada;\
        l->ult = fim_ord;\
/*        gotoxy(1,1);\
        cprintf("Ordenacao concluida!"); clreol();*/\
}\

ORDENA(freq)
ORDENA(red)
ORDENA(green)
ORDENA(blue)

void ordena(Lista *l)
{
//        ordena_blue(l);
//        ordena_green(l);
//        ordena_red(l);
        ordena_freq(l);
}

void Reposiciona(Lista *l, Nodo *n)
{
        Nodo *tmp;

        Nodo *foo, *doo;

        tmp = l->prim;

        /* pesquisa 1o nodo com frequencia < frequencia(n) */

        while ((tmp != n) && (tmp->freq >= n->freq))
                tmp = tmp->prox;

        /* posicao eh a posicao do n... soh acontece se nodo jah estiver na posicao correta
           retorna e nao faz nada */
        if (tmp == n)
                return;

        /* senao, tmp ja eh um nodo com freq. < freq(n) */

        /* remove n da lista */
        
        foo = n->ant;
        doo = tmp->ant;
        
        if (foo == NULL)
        {
        	l->prim = l->prim->prox;
                l->prim->ant = NULL;
        }
        else
        {
	        foo->prox = n->prox;
	        if (foo->prox != NULL)
		        foo->prox->ant = foo;
                else /* n era ultimo nodo */
                	l->ult = foo;

	}
        
        if (doo != NULL)
        {
                doo->prox = n;
                n->ant = doo;
        }
        else
        {
                l->prim = n;
                n->ant = NULL;
        }
        n->prox = tmp;
        tmp->ant = n;
}
