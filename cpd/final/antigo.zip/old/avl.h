#include <assert.h>
#include <string.h>
//#include "types.h"

typedef unsigned char byte;

#define FULL 0
#define VAZIO 1

typedef struct pt { 
	int cor;
	int freq;
	struct pt *esq;
	struct pt *dir;
	int bal;
	
} swain; //Struct Without An Interesting Name....

//Monta um novo noh para insercao na arvore AVL, considerando que ele serah
//inserido como uma folha
swain *inicio_no ( int cor )
{
	swain *tmp;
	tmp = (swain *)calloc(1, sizeof(swain));
	tmp->esq = NULL; tmp->dir = NULL;
	tmp->freq = 1; tmp->bal = 0; tmp->cor = cor;
	return tmp;
}

//Faz insercao quando se aplica a rotacao para direita
void rotacao_dir( swain **pt, int *h)
{
	swain *ptu, *ptv;
	
	//Verificar integridade de pt ==> se naum vem null em pt
	ptu = (*pt)->esq;
	//Verificar integridade de ptu ==> se naum vem null de pt->esq
	if (ptu->bal == -1 )
	{//Rotacao direita
		(*pt)->esq = ptu->dir; ptu->dir = *pt;
		(*pt)->bal = 0; *pt = ptu;	
	}
	else
	{//Rotacao dupla direita
		ptv = ptu->dir;
		ptu->dir = ptv->esq; ptv->esq = ptu;
		(*pt)->esq = ptv->dir; ptv->dir = *pt;
		if ( ptv->bal == -1 ) 
			(*pt)->bal = 1;
		else (*pt)->bal = 0;
		if ( ptv->bal == 1 )
			ptu->bal = -1;
		else ptu->bal = 0;
		*pt = ptv;
	}
	(*pt)->bal = 0; *h = FULL;
}

//Faz insercao quando se aplica a rotacao para direita
void rotacao_esq( swain **pt, int *h)
{
	swain *ptu, *ptv;
	
	//Verificar integridade de pt ==> se naum vem null em pt
	ptu = (*pt)->dir;
	//Verificar integridade de ptu ==> se naum vem null de pt->esq
	if (ptu->bal == 1 )
	{//Rotacao esquerda
		(*pt)->dir = ptu->esq; ptu->esq = *pt;
		(*pt)->bal = 0; *pt = ptu;	
	}
	else
	{//Rotacao dupla esquerda
		ptv = ptu->esq;
		ptu->esq = ptv->dir; ptv->dir = ptu;
		(*pt)->dir = ptv->esq; ptv->esq = *pt;
		if ( ptv->bal == 1 ) 
			(*pt)->bal = -1;
		else (*pt)->bal = 0;
		if ( ptv->bal == -1 )
			ptu->bal = 1;
		else ptu->bal = 0;
		*pt = ptv;
	}
	(*pt)->bal = 0; *h = FULL;
}

void ins_AVL ( swain **pt, int cor, int *h )
{	
	if ( *pt == NULL )
	{//Arvore Vazia
		*pt = (swain *)inicio_no( cor ); *h = VAZIO;
	}
	else
	{
		if ( cor == (*pt)->cor ) 
		{//Freq. jah existe. Incrementa e sai
			(*pt)->freq++;
			return;
		}
		if ( cor < (*pt)->cor )
		{//Insersao na subarvore esquerda
			ins_AVL( &((*pt)->esq), cor, h );
			if ( *h )
			{
				switch( (*pt)->bal ){
					case 1 : (*pt)->bal = 0; *h = FULL; break;
					case 0 : (*pt)->bal = -1; break;
					case -1: rotacao_dir( pt, h ); break;
				}
			}
		}
		else
		{
			ins_AVL( &((*pt)->dir), cor, h );
			if ( *h )
			{
				switch( (*pt)->bal ){
					case -1 : (*pt)->bal = 0; *h = FULL; break;
					case 0 : (*pt)->bal = 1; break;
					case 1: rotacao_esq( pt, h ); break;
				}
			}
		}
	}//do else
}//da procedure

//Convert as cores em RGB em um inteiro;
int RGB_i( byte R, byte G, byte B )
{
	int x;
	
	x = ((int)R<<16) + ((int)G<<8) + B;

	return x; 
}

void imprimeAVL ( swain *p )
{
	if( p != NULL )
	{
		imprimeAVL( p->esq );
		printf(" cor = %d \n", p->cor);
		printf(" freq = %d \n", p->freq);
		imprimeAVL( p->dir );
	}
}
