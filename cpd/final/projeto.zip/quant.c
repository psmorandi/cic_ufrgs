#include <assert.h>
#include "types.h"
#include "lista.h"
#include "avl.h"

byte MEDIA_R(Nodo *a, Nodo *b)
{
	int rf1, rf2;
        int media;
        rf1 = RED(a) * a->freq;
        rf2 = RED(b) * b->freq;
        media = rf1 + rf2;
        media /= (a->freq + b->freq);
        return (byte)media;
}

byte MEDIA_G(Nodo *a, Nodo *b)
{
	int rf1, rf2;
        int media;
        rf1 = GREEN(a) * a->freq;
        rf2 = GREEN(b) * b->freq;
        media = rf1 + rf2;
        media /= (a->freq + b->freq);
        return (byte)media;
}

byte MEDIA_B(Nodo *a, Nodo *b)
{
	int rf1, rf2;
        int media;
        rf1 = BLUE(a) * a->freq;
        rf2 = BLUE(b) * b->freq;
        media = rf1 + rf2;
        media /= (a->freq + b->freq);
        return (byte)media;
}

Lista *quantiza_freq(AVLTree *t, int max)
{
	Nodo *tmp, *best;

        Lista *cores;

        cores = AVL2List(t);

	while (cores->num_nodos > max)
        {
		tmp = RemoveUlt(cores);
                assert(tmp);        // sem problemas, nao deve acontecer
                best = NearestMatch(cores, tmp);

                best->cor = RGB(MEDIA_R(best, tmp), MEDIA_G(best, tmp), MEDIA_B(best, tmp));
                best->freq += tmp->freq;
                free(tmp);
                Reposiciona(cores, best);
        }

        return cores;
}
