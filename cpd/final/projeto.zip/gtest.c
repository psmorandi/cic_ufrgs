#ifdef _UNIX
void grOn(void)
{
}

void grOff(void)
{
}

void setpix(int x, int y, unsigned char c)
{
}

#else
#include <dos.h>
#ifndef _TURBOC_
#include <sys/movedata.h>
#define pokeb(s, o, v) _farpokeb(_go32_conventional_mem_selector(), s*16+o, v)
#endif

void grOn(void)
{
		union REGS regs;
		regs.x.ax = 0x0013;
		int86(0x10, &regs, &regs);
}

void grOff(void)
{
		union REGS regs;
		regs.x.ax = 0x0003;
		int86(0x10, &regs, &regs);
}

void setpix(int x,int y,unsigned char cor)
{

//	x-=200;
//	y-=75;
		if (x < 0) return;
		if (y < 0) return;
		if (y > 200) return;
		if (x > 320) return;
		pokeb(0xa000, y*320+x, cor);
}


#endif
