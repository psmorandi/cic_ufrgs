/********************************************************
 * avl.c - rotinas para tratamento de arvores AVL       *
 * genericas.                                           *
 *                                                      *
 * 02/03/2003 - Versao inicial                          *
 * 	- Mairo                                         *
 ********************************************************/


#include <stdlib.h>
#include <assert.h>
#include "avl.h"

/*
 * AVLTree *NewTree(Compara, SameKey) - Cria e inicializa uma
 * arvore AVL vazia
 */
AVLTree *NewTree(int (*Compara)(), void (*SameKey)())
{
	AVLTree *tmp;
	
	tmp = (AVLTree *)calloc(1, sizeof(*tmp));
	assert(tmp != NULL);

	tmp->Compara = Compara;
	tmp->SameKey = SameKey;
	tmp->raiz = NULL;
	tmp->nr_nodes = 0;

	return tmp;
}


/*
 * Node *NewNode(dados, tamanho) - FUNCAO PRIVADA - Cria um nodo
 * para arvore AVL, contendo os dados entrados.
 * Este mecanismo, juntamente com as rotinas Compara e SameKey
 *  tornam estas arvores AVL "genericas".
 */
static Node *NewNode(void *dados, int tamanho)
{
	Node *tmp;
	assert(dados != NULL);
	assert(tamanho > 0);
	tmp = (Node *)calloc(1, sizeof(*tmp)); 
	assert(tmp != NULL);
	/* calloc jah zera todos os campos */
        tmp->dados = (void *)calloc(tamanho, 1);
	assert(tmp->dados != NULL);
	memcpy(tmp->dados, dados, tamanho);
	return tmp;
}


void DestroyNode(Node *node)
{
        assert(node != NULL);
        assert(node->dados != NULL);
//        free(node->dados);
        free(node);
        return;
}

/*
 * avlRotate{Left, Right}(pt, h) - FUNCOES PRIVADAS -
 *  efetuam rotacao a esquerda ou a direita. Usadas internamente por
 *  avlInsere para rebalancear a arvore
 */
static void avlRotateRight( Node **pt, int *h)
{
        Node *ptu, *ptv;

	ptu = (*pt)->esq;

	if (ptu->bal == -1 )
	{//Rotacao direita
		(*pt)->esq = ptu->dir;
                ptu->dir = *pt;
                ptu->pai = (*pt)->pai;
                (*pt)->pai = ptu;
                if ((*pt)->esq != NULL)
                        (*pt)->esq->pai = *pt;
		(*pt)->bal = 0;
                *pt = ptu;
	}
	else
	{//Rotacao dupla direita
		ptv = ptu->dir;		 ptu->pai = ptv;
		ptu->dir = ptv->esq;
		if ( (ptu->dir) != NULL )
			(ptu->dir)->pai = ptu;
                ptv->esq = ptu;
		(*pt)->esq = ptv->dir;
		if ( ((*pt)->esq) != NULL )
			((*pt)->esq)->pai = (*pt);
		ptv->dir = *pt;		(*pt)->pai = ptv;
		if ( ptv->bal == -1 )
			(*pt)->bal = 1;
		else (*pt)->bal = 0;
		if ( ptv->bal == 1 )
			ptu->bal = -1;
		else ptu->bal = 0;
		*pt = ptv;
		(*pt)->pai = NULL;
	}
        (*pt)->bal = 0; *h = 0;
}

//Faz insercao quando se aplica a rotacao para direita
static void avlRotateLeft(Node **pt, int *h)
{
        Node *ptu, *ptv;

	ptu = (*pt)->dir;
	if (ptu->bal == 1 )
	{//Rotacao esquerda
		(*pt)->dir = ptu->esq;
		ptu->esq = *pt;
		ptu->pai = (*pt)->pai;
		(*pt)->pai = ptu;
		if ((*pt)->dir != NULL)
                        (*pt)->dir->pai = *pt;
		(*pt)->bal = 0; *pt = ptu;
	}
	else
	{//Rotacao dupla esquerda
		ptv = ptu->esq;

                ptu->pai = ptv;
		ptu->esq = ptv->dir;
		if ( (ptu->esq) != NULL )
			(ptu->esq)->pai = ptu;
		ptv->dir = ptu;
		(*pt)->dir = ptv->esq;
		if ( ((*pt)->dir) != NULL )
			((*pt)->dir)->pai = (*pt);
		ptv->esq = *pt;		(*pt)->pai = ptv;
		if ( ptv->bal == 1 )
			(*pt)->bal = -1;
		else (*pt)->bal = 0;
		if ( ptv->bal == -1 )
			ptu->bal = 1;
		else ptu->bal = 0;
		*pt = ptv;
		(*pt)->pai = NULL;
	}
        (*pt)->bal = 0; *h = 0;
}


/*
 * int avlInsere(arv, atual, insert, h) - FUNCAO PRIVADA: funcao que
 * faz o trabalho de inserir o nodo na arvore avl. Usada pela funcao
 * Insere abaixo
 */
static int avlInsere(AVLTree *arv, Node **pt, Node *insert, int *h)
{
	assert((*pt) != NULL);
	if ( arv->Compara((*pt)->dados, insert->dados) == 0)
	{//Cor jah existe. Incrementa e sai
		arv->SameKey(*pt, insert);
                arv->nr_nodes--;
		return 0;
	}
	if ( arv->Compara((*pt)->dados,insert->dados) < 0 )
	{//Insersao na subarvore esquerda
		if ((*pt)->esq == NULL)
		{
			(*pt)->esq = insert;
			*h = 1;
		}
		else
			avlInsere(arv, &((*pt)->esq), insert, h );
		((*pt)->esq)->pai = (*pt);
		if ( *h )
		{
			switch( (*pt)->bal ){
				case 1 : (*pt)->bal = 0; *h = 0; break;
				case 0 : (*pt)->bal = -1; break;
				case -1: avlRotateRight( pt, h ); break;
			}
		}
	}
	else
	{
		if ((*pt)->dir == NULL)
		{
			(*pt)->dir = insert;
			*h = 1;
		}
		else
			avlInsere( arv, &((*pt)->dir), insert, h );
		((*pt)->dir)->pai = (*pt);
		if ( *h )
		{
			switch( (*pt)->bal ){
				case -1 : (*pt)->bal = 0; *h = 0; break;
				case 0 : (*pt)->bal = 1; break;
				case 1: avlRotateLeft( pt, h ); break;
			}
		}
	}
}//da procedure


/*
 * Insere(arv, dados, tamanho) - cria um nodo e insere na arvore
 */
void Insere(AVLTree *arv, void *dados, int tamanho)
{
	Node *tmp;
	int h = 0;
	assert(arv != NULL);
	/* consistencia de "dados" e "tamanho" feitas por NewNode */

	tmp = NewNode(dados, tamanho);
	assert(tmp);	/* descargo de consciencia */

	if (arv->raiz == NULL)
	{
		assert(arv->nr_nodes == 0);
                arv->nr_nodes++;
		arv->raiz = tmp;
	}
	else
        {
                arv->nr_nodes++;
		avlInsere(arv, &(arv->raiz), tmp, &h);
        }

	return;
}

/* 
 * avlPesquisa(arv, dados, atual) - FUNCAO PRIVADA - eh quem realmente faz a pesquisa na
 * arvore. Usada internamente por Pesquisa, Sucessor e Predecessor e Exclusao
 */

static Node *avlPesquisa(AVLTree *arv, void *dados, Node *atual)
{
	
	int comparacao;
	if (atual == NULL)
		return NULL;
	else
	{
		comparacao = arv->Compara(atual->dados, dados);
                if (comparacao == 0)
                        return atual;
		else if (comparacao < 0)
			return avlPesquisa(arv, dados, atual->esq);
		else
			return avlPesquisa(arv, dados, atual->dir);
	}
//	return NULL; /* mal nao deve fazer */
}


/*
 * Pesquisa(arv, dados) - Pesquisa a arvore por um nodo cujo dado bata com o dado pesquisado, 
 * utilizando-se a funcao de pesquisa
 */
void *Pesquisa(AVLTree *arv, void *dados)
{
        Node *tmp;
        assert(dados != NULL);

        tmp = avlPesquisa(arv, dados, arv->raiz);
        if (tmp != NULL)
                return tmp->dados;
        return NULL;
}


/*
 * avl{Maximo, Minimo}(atual) - FUNCOES PRIVADAS -
 * retornam o nodo maximo/minimo da subarvore "atual". Usadas
 * internamente por Maximo, Minimo, Sucessor e Predecessor
 */
static Node *avlMinimo(Node *atual)
{
        Node *raiz, *y=NULL;

        assert(atual != NULL);

        raiz = atual;

        while (raiz != NULL)
        {
                y = raiz;
                raiz = raiz->esq;
        }
        return y;
}

static Node *avlMaximo(Node *atual)
{
        Node *raiz, *y=NULL;

        assert(atual != NULL);

        raiz = atual;

        while (raiz != NULL)
        {
                y = raiz;
                raiz = raiz->dir;
        }
        return y;

}

/*
 * {Maximo, Minimo}(arv) - retornam o dado maximo/minimo da arvore arv.
 */

void *Minimo(AVLTree *arv)
{
        Node *tmp;
        assert(arv != NULL);
        tmp = avlMinimo(arv->raiz);
        if (tmp == NULL)
                return NULL;
        return tmp->dados;
}

void *Maximo(AVLTree *arv)
{
        Node *tmp;
        assert(arv != NULL);
        tmp = avlMaximo(arv->raiz);
        if (tmp == NULL)
                return NULL;
        return tmp->dados;
}

/*
 * {Sucessor, Predecessor}(arv, quem) - retorna o sucessor/predecessor
 * do elemento cuja chave eh igual a "quem" (utilizando a funcao de
 * comparacao, indiretamente)
 */
void *Sucessor(AVLTree *arv, void *quem)
{
	Node *pesq, *y;
	assert(arv != NULL);
	assert(quem != NULL);


        pesq = avlPesquisa(arv, quem, arv->raiz);
        assert(pesq != NULL);

        if (pesq->dir != NULL)
        {
                y = avlMinimo(pesq->dir);
                return y->dados;
        }
        y = pesq->pai;

        while ( (y != NULL) && (pesq == y->dir) )
        {
                pesq = y;
                y = y->pai;
        }
        if (y == NULL)
                return NULL;   /* descargo de consciencia */
        return y->dados;
        
}

void *Predecessor(AVLTree *arv, void *quem)
{
	Node *pesq, *y;
	assert(arv != NULL);
	assert(quem != NULL);

	pesq = avlPesquisa(arv, quem, arv->raiz);
        assert(pesq != NULL);

        if (pesq->esq != NULL)
        {
                y = avlMaximo(pesq->esq);
                return y->dados;
        }
        y = pesq->pai;

        while ( (y != NULL) && (pesq == y->esq) )
        {
                pesq = y;
                y = y->pai;
        }
        if (y == NULL)
                return NULL;   /* descargo de consciencia */
        return y->dados;
}

int tstExclui1(AVLTree *arv, Node *atual, void *dados)
{
        Node *tmp;
        if (atual->esq == NULL)
                tmp = atual->dir;
        else
                tmp = atual->esq;

        tmp->pai = atual->pai;

        if (atual->pai == NULL)
                arv->raiz = tmp;
        else
        {
                if (atual->pai->esq == atual)
                        atual->pai->esq = tmp;
                else
                        atual->pai->dir = tmp;
        }
        DestroyNode(atual);
        arv->nr_nodes--;
        return 1;
}

int tstExclui2(AVLTree *arv, Node *atual, void *dados)
{
        Node *pred;
        void *dados_pred;
        /* pesquisa nodo predecessor */
        pred = atual->esq;
        while (pred->dir != NULL)
                pred = pred->dir;
        /* pred eh o nodo que substituira tmp */

        /* salva dados do predecessor */

        dados_pred = pred->dados;
        /* chama tstExclui0(arv, arv->raiz, dados) */
        /* aproveita que DestroyNode mantem os dados intactos */

        tstExclui0(arv, arv->raiz, pred->dados);

        /* altera dados do nodo atual */
        atual->dados = dados_pred;


        /* mudancas no balanco sao feitas apenas por tstExclui0 acima */
        return 0;
}


int tstExclui0(AVLTree *arv, Node *atual, void *dados)
{
        int old_bal, h;
        if (atual == NULL) return 0;
        if (arv->Compara(atual->dados, dados) == 0)
        {

                if ( (atual->esq != NULL) && (atual->dir != NULL) )
                {
                        h = tstExclui2(arv, atual, dados);
                        assert(arv->raiz != NULL);
                        return h; 
                }

                if (atual->esq != NULL || atual->dir != NULL)
                {
                        h = tstExclui1(arv, atual, dados);
                        assert(arv->raiz != NULL);
                        return h;
                }

                if (atual->pai == NULL)
                {
                        assert(arv->nr_nodes == 1);
                        arv->raiz = NULL;
                }
                else
                {
                        if (atual->pai->esq == atual)
                                atual->pai->esq = NULL;
                        else
                                atual->pai->dir = NULL;
                }
                DestroyNode(atual);
                arv->nr_nodes--;
                return 1;
        }
        else
        {
                if (arv->Compara(atual->dados, dados) < 0)
                {
                        old_bal = atual->bal;
                        atual->bal += tstExclui0(arv, atual->esq, dados);

                        if (atual->bal == 2)
                        {
                                if (atual->pai == NULL)
                                        avlRotateLeft(&arv->raiz, &h);
                                else if (atual->pai->esq == atual)
                                        avlRotateLeft(&atual->pai->esq, &h);
                                else
                                        avlRotateLeft(&atual->pai->dir, &h);
                                atual->bal = 0;
                                return 1;
                        }

                        if (atual->bal == 0)
                                return abs(old_bal);
                        else
                                return 0;
                }
                else
                {
                        old_bal = atual->bal;
                        atual->bal -= tstExclui0(arv, atual->dir, dados);

                        if (atual->bal == -2)
                        {
                                if (atual->pai == NULL)
                                        avlRotateRight(&arv->raiz, &h);
                                else if (atual->pai->esq == atual)
                                        avlRotateRight(&atual->pai->esq, &h);
                                else
                                        avlRotateRight(&atual->pai->dir, &h);
                                atual->bal = 0;
                                return 1;
                        }

                        if (atual->bal == 0)
                                return abs(old_bal);
                        else
                                return 0;
                }
        }
}



void Exclui(AVLTree *arv, void *dados)
{
        tstExclui0(arv, arv->raiz, dados);
}

/******************************************************************

void ImprimeArv(int nivel, Node *tmp)
{
	if (tmp == NULL) return;
	ImprimeArv(nivel+1, tmp->esq);
	printf("  %d-%d(%d)  ", nivel, *(int *)tmp->dados, tmp->bal);
	ImprimeArv(nivel+1, tmp->dir);
}

int Comparador(void *a, void *b)
{
	return *(int *)b - *(int *)a;
}

void SameKey(Node *a, Node *b)
{
	assert(0);
}

int main(void)
{
        Node *tmp;

        int op, val;
        int *suc;
	AVLTree *t = NewTree(Comparador, SameKey);

        while (1) {
        printf("1. Insere\n");
        printf("2. Exclui\n");
        printf("3. Pesquisa\n");
        printf("4. Sucessor\n");
        printf("5. Predecessor\n");
        printf("6. Maximo\n");
        printf("7. Minimo\n");
        printf("0. Sair\n");
        printf("\nOpcao escolhida: ");

        do scanf("%d", &op);
        while (op < 0 || op > 7);

        switch(op)
        {
                case 1:
                        printf("Valor a inserir: ");
                        scanf("%d", &val);
                        Insere(t, &val, sizeof(val));
                        ImprimeArv(0, t->raiz);
                        printf("\n");
                        break;
                case 2: 
                        printf("Valor a excluir: ");
                        scanf("%d", &val);
                        Exclui(t, &val);
                        ImprimeArv(0, t->raiz);
                        printf("\n");
                        break;
                case 3: 
                        printf("Valor a pesquisar: ");
                        scanf("%d", &val);
                        suc = Pesquisa(t, &val);
                        printf("valor %d encontrado\n", *suc);
                        break;
                case 4:
                        printf("Sucessor de: ");
                        scanf("%d", &val);
                        suc = Sucessor(t, &val);
                        if (suc != NULL)
                                printf("Sucessor: %d\n", *suc);
                        break;
                case 5: 
                        printf("Predecessor de: ");
                        scanf("%d", &val);
                        suc = Predecessor(t, &val);
                        if (suc != NULL)
                                printf("Sucessor: %d\n", *suc);
                        break;
                case 6:
                        printf("Maximo: ");
                        suc = Maximo(t);
                        if (suc != NULL)
                                printf("%d\n", *suc);
                        break;
                case 7:
                        printf("Minimo: ");
                        suc = Minimo(t);
                        if (suc != NULL)
                                printf("%d\n", *suc);
                        break;
                default:
                        exit(0);
        }
        }
}
******************************************************************/

