/********************************************************
 * avl.h - Definicao das estruturas Node e AVLTree, e   *
 * prototipos das rotinas para construcao e utilizacao  *
 * de arvores AVL genericas.                            *
 *                                                      *
 * 02/03/2003 - Versao inicial                          *
 * 	- Mairo                                         *
 ********************************************************/
#ifndef _AVL_H
#define _AVL_H

typedef struct _Node
{
        void *dados;
	struct _Node *pai;
	struct _Node *esq;
	struct _Node *dir;
	int bal;
} Node;

typedef struct _AVLTree {
	Node *raiz;
	int nr_nodes;
	int (*Compara)(void *, void *);
	void (*SameKey)(Node *, Node *);
} AVLTree;

AVLTree *NewTree(int (*Compara)(), void (*SameKey)());
void Insere(AVLTree *arv, void *dados, int tamanho);
void *Pesquisa(AVLTree *arv, void *dados);
void *Minimo(AVLTree *arv);
void *Maximo(AVLTree *arv);
void *Sucessor(AVLTree *arv, void *quem);
void *Predecessor(AVLTree *arv, void *quem);

#endif /* _AVL_H */
