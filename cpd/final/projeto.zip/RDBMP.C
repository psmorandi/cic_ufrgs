#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "types.h"
#include "lista.h"
#include "bitmap.h"
#include "avl.h"

void reloadBmp(char *name, Lista *lista)
{

  Nodo *tmp;
  struct rgbquad *pal;
  FILE *out;
  byte cores[3];
  byte cor;
  int x,y;
  struct bitmaphdr bmp;
  dword i,j,k;
  int p_cor;
  int tam_lido;
  FILE *in;

  in = NULL;
  if ((in=fopen(name,"rb"))==NULL)
	exit(-1);

  out = fopen("saida.bmp", "wb");
  assert(out!=NULL);

  tam_lido = fread(&bmp,1,sizeof(bmp),in);
  fseek(in,bmp.hdr.offbits,SEEK_SET);

  pal = (struct rgbquad *)calloc(lista->num_nodos, sizeof(struct rgbquad));

  j=bmp.info.width;

  if (bmp.info.bitcount != 24)
  {
        grOff();
        printf("Bitmap deve ser de 24 bits!\n");
        exit(-1);
  }

  bmp.info.bitcount = 8;
  bmp.info.imgsz = bmp.info.width * bmp.info.height;
  bmp.hdr.offbits = sizeof(bmp) + sizeof(struct rgbquad) * lista->num_nodos;
  bmp.hdr.size = bmp.info.imgsz + bmp.hdr.offbits;
  bmp.info.clrUsed = lista->num_nodos;
  bmp.info.clrImportant = lista->num_nodos;
  fwrite(&bmp, 1, sizeof(bmp), out);

  tmp = lista->prim;
  for (i=0;i<lista->num_nodos;i++)
  {
        pal[i].blue = RED(tmp);
        pal[i].green = GREEN(tmp);
        pal[i].red = BLUE(tmp);
        pal[i].resv = 0;
        tmp = tmp->prox;
  }

  fwrite(pal, lista->num_nodos, sizeof(*pal), out);

  i=(j%4);
//  if (i!=0) i=4-i;
  for (y=bmp.info.height-1;y>=0;y--) {
      for (x=0;x<bmp.info.width;x++) {
          for (p_cor=0;p_cor<3;p_cor++)
              cores[p_cor] = getc(in);

          cor = MaisProxPos(lista, cores[0], cores[1], cores[2]);
	  setpix(x, y, cor);
          fputc(cor, out);
      }
      for (j=0;j<i;j++)
          (void)getc(in);
      if (i!=0)
          for (j=0;j<4-i;j++)
                fputc(0, out);
  }
  fclose(in);
  fclose(out);
}

int bmp__compara(void *a, void *b)
{
	TreeEntry *ta, *tb;
	ta = (TreeEntry *)a;
	tb = (TreeEntry *)b;

	if (ta->cor < tb->cor) return -1;
	if (ta->cor > tb->cor) return 1;
	return 0;
}

void FillTreeEntry(TreeEntry *a, byte r, byte g, byte b)
{
        int i;
        a->cor = RGB(r, g, b);
        a->freq = 1;
}

void bmp__samekey(Node *a, Node *b)
{
        TreeEntry *tmp;
        tmp = (TreeEntry *)(a->dados);
        tmp->freq++;
	DestroyNode(b);
	return;
}

AVLTree *loadbmp(char *name)
{
  byte cor;
  byte cores[3];
  long x,y;
  struct bitmaphdr bmp;
  dword i,j,k;
  int p_cor;
  int tam_lido;
  FILE *in;
  AVLTree *l;
  TreeEntry tmp;

  l = NewTree(bmp__compara, bmp__samekey);
  assert(l != NULL);


  in=fopen(name,"rb");
  assert(in != NULL);

  tam_lido = fread(&bmp,1,sizeof(bmp),in);
  fseek(in,bmp.hdr.offbits,SEEK_SET);

  j=bmp.info.width;
  i=(j%4);
  for (y=bmp.info.height-1;y>=0;y--) {
      for (x=0;x<bmp.info.width;x++) {
          cor = 0;
	  for (p_cor=0;p_cor<3;p_cor++)
          {
              cores[p_cor] = getc(in);
              cor+=cores[p_cor]>>2;
	  }
          FillTreeEntry(&tmp, cores[0], cores[1], cores[2]);
          Insere(l, &tmp, sizeof(tmp));

          cor /= 3;
	  setpix(x, y, cor);
      }
      for (j=0;j<i;j++)
          (void)getc(in);
//      printf(".");
  }
  fclose(in);
  return l;
}

