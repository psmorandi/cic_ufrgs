#include "types.h"
#include "avl.h"
#include "lista.h"
#include <assert.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
        int i;
        AVLTree *l;
        Lista *cores;
        Nodo *tmp;
	assert(argc > 1);
	grOn();
	outp(0x3c8, 0);
	for (i=0;i<256;i++)
	{
		outp(0x3c9, i%64);
		outp(0x3c9, i%64);
		outp(0x3c9, i%64);
	}

	l = (AVLTree *)loadbmp(argv[1]);
        cores = quantiza_freq(l, 256);

//        cores = AVL2List(l);
        
        outp(0x3c8, 0);

        tmp = cores->prim;
        for (i=0;i<cores->num_nodos;i++)
	{
                outp(0x3c9, BLUE(tmp)>>2);
                outp(0x3c9, GREEN(tmp)>>2);
                outp(0x3c9, RED(tmp)>>2);
                tmp = tmp->prox;
	}
        for (i=0;i<256-cores->num_nodos;i++)
        {
        	outp(0x3c9, 0);
        	outp(0x3c9, 0);
        	outp(0x3c9, 0);
        }
        
        reloadBmp(argv[1], cores);

        fflush(stdout);
        getchar();
        grOff();
        return;
}

