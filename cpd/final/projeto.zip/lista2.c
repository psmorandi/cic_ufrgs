#include <stdlib.h>
#include <assert.h>
#include "types.h"
#include "lista.h"
#include "avl.h"

Lista *CriaLista()
{
	Lista *tmp;
	tmp = (Lista *)calloc(1, sizeof(Lista));
	assert(tmp);
	tmp->prim = tmp->ult = NULL;
	tmp->num_nodos = 0;
	return tmp;
}

unsigned long RGB(byte r, byte g, byte b)
{
    int i;
    unsigned long cor=0;
    for (i=0;i<8;i++)
    {
        cor |= ((r&1)<<(3*i+2)); r>>=1;
        cor |= ((g&1)<<(3*i+1)); g>>=1;
        cor |= ((b&1)<<(3*i));   b>>=1;
    }
    return cor;
}

byte RED(Nodo *n)
{
    byte r=0;
    unsigned long cor = n->cor;
    int i;
    assert(n!=NULL);
    for (i=0;i<8;i++)
    {
        cor>>=2;
        r |= ((cor&1) << i);
        cor>>=1;
    }
    return r;
}

byte GREEN(Nodo *n)
{
    byte r=0;
    unsigned long cor = n->cor;
    int i;
    for (i=0;i<8;i++)
    {
        cor>>=1;
        r |= ((cor&1) << i);
        cor>>=2;
    }
    return r;
}

byte BLUE(Nodo *n)
{
    byte r=0;
    unsigned long cor = n->cor;
    int i;
    for (i=0;i<8;i++)
    {
        r |= ((cor&1) << i);
        cor>>=3;
    }
    return r;

}

void InsereNodo(Lista *l, byte r, byte g, byte b)
{
	int i;
        unsigned long cor = RGB(r, g, b);
	Nodo *tmp;
	tmp = l->prim;
	if (tmp == NULL)
	{ // primeiro nodo
		tmp = (Nodo *)calloc(1, sizeof(Nodo));
		assert(tmp);
		tmp->prox = NULL;
		tmp->ant = NULL;
		l->prim = tmp;
		l->ult = tmp;
                tmp->cor = cor;
		tmp->freq = 1;
		l->num_nodos++;
		return;
	}
	for (i=0;i<l->num_nodos; i++)
	{
                if (tmp->cor == cor)
		{
			tmp->freq++;
			return;
		}
		tmp = tmp->prox;
	}
	if (tmp == NULL)
	{
		tmp = (Nodo *)calloc(1, sizeof(Nodo));
		assert(tmp);
		tmp->prox = NULL;
		tmp->ant = l->ult;
		l->ult->prox = tmp;
		l->ult = tmp;
                tmp->cor = cor;
		tmp->freq = 1;
		l->num_nodos++;
	}
}


void InsNodoFreq(Lista *l, dword cor, dword freq)
{
    Nodo *tmp;
    tmp = l->prim;
    tmp = (Nodo *)calloc(1, sizeof(Nodo));
    assert(tmp);

    tmp->prox = NULL;
    tmp->ant = l->ult;

    if (l->ult!=NULL)
        l->ult->prox = tmp;

    l->ult = tmp;

    if (l->prim == NULL)
        l->prim = tmp;

    tmp->cor = cor;
    tmp->freq = freq;
    l->num_nodos++;
    return;
}

void ImprLista(Lista *l)
{
	Nodo *tmp;
	int i;
	tmp = l->prim;
	for (i=0;i<l->num_nodos;i++) {
        printf("(%d, %d, %d) --> %d\n", RED(tmp), GREEN(tmp), BLUE(tmp), tmp->freq);
		tmp = tmp->prox;
	}
}

Nodo *NearestMatch(Lista *l, Nodo *orig)
{
	Nodo *tmp, *maisprox;
        unsigned long best_dif;

        unsigned long dif;

        best_dif = (1<<25)-1;         // caso impossivel
        maisprox = NULL;

        tmp = l->prim;
        while (tmp != NULL)
        {
            dif = abs(tmp->cor-orig->cor);
            if (dif < best_dif)
            {
                best_dif = dif;
                maisprox = tmp;
            }
            tmp = tmp->prox;
        }
        return maisprox;
}

Nodo *RemoveUlt(Lista *l)
{
	Nodo *tmp;
        if (l->prim == NULL)
        	return NULL;
                
        tmp = l->ult;
        if (l->num_nodos > 1)
        {
                assert(l->ult->ant);
        	l->ult = l->ult->ant;
                l->ult->prox = NULL;
        }
        else
        {
        	l->prim = l->ult = NULL;
        }

        l->num_nodos--;
	return tmp;
}

int MaisProxPos(Lista *l, byte r, byte g, byte b)
{
	Nodo *tmp;
        unsigned long cor = RGB(r, g, b);
        long best_dif, best_pos;

        int pos;
        long dif;

        best_dif = (1<<25)-1;         // caso impossivel
        best_pos = l->num_nodos;

        tmp = l->prim;
        pos = 0;
        while (tmp != NULL)
        {
                dif = abs(tmp->cor-cor);
                if (dif < best_dif)
                {
                	best_dif = dif;
                        best_pos = pos;
                }
                pos++;
                tmp = tmp->prox;
        }
        return best_pos;
}

void AVL2ListHelper(Node *avl, Lista *list)
{
    TreeEntry *tmp;
    if (avl == NULL)
	return;

    tmp = ((TreeEntry *)avl->dados);

    AVL2ListHelper(avl->esq, list);

    InsNodoFreq(list, tmp->cor, tmp->freq);

    AVL2ListHelper(avl->dir, list);
}

Lista *AVL2List(AVLTree *avl)
{
    Lista *tmp = CriaLista();
    AVL2ListHelper(avl->raiz, tmp);
    return tmp;
}

void Reposiciona(Lista *l, Nodo *n)
{
        Nodo *tmp;

        Nodo *foo, *doo;

        tmp = l->prim;

        /* pesquisa 1o nodo com frequencia < frequencia(n) */

        while ((tmp != n) && (tmp->freq >= n->freq))
                tmp = tmp->prox;

        /* posicao eh a posicao do n... soh acontece se nodo jah estiver na posicao correta
           retorna e nao faz nada */
        if (tmp == n)
                return;

        /* senao, tmp ja eh um nodo com freq. < freq(n) */

        /* remove n da lista */
        
        foo = n->ant;
        doo = tmp->ant;
        
        if (foo == NULL)
        {
        	l->prim = l->prim->prox;
                l->prim->ant = NULL;
        }
        else
        {
	        foo->prox = n->prox;
	        if (foo->prox != NULL)
		        foo->prox->ant = foo;
                else /* n era ultimo nodo */
                	l->ult = foo;
	}
        
        if (doo != NULL)
        {
                doo->prox = n;
                n->ant = doo;
        }
        else
        {
                l->prim = n;
                n->ant = NULL;
        }
        n->prox = tmp;
        tmp->ant = n;
}

