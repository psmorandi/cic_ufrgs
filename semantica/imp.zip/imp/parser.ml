type token =
    PROGRAM of (Support.Error.info)
  | WITH of (Support.Error.info)
  | BEGIN of (Support.Error.info)
  | END of (Support.Error.info)
  | VAR of (Support.Error.info)
  | CONST of (Support.Error.info)
  | PROC of (Support.Error.info)
  | INT of (Support.Error.info)
  | BOOL of (Support.Error.info)
  | NODECL of (Support.Error.info)
  | IF of (Support.Error.info)
  | THEN of (Support.Error.info)
  | ELSE of (Support.Error.info)
  | WHILE of (Support.Error.info)
  | DO of (Support.Error.info)
  | BREAK of (Support.Error.info)
  | THROW of (Support.Error.info)
  | TRY of (Support.Error.info)
  | SKIP of (Support.Error.info)
  | TRUE of (Support.Error.info)
  | FALSE of (Support.Error.info)
  | AND of (Support.Error.info)
  | OR of (Support.Error.info)
  | NOT of (Support.Error.info)
  | DIV of (Support.Error.info)
  | UCID of (string Support.Error.withinfo)
  | LCID of (string Support.Error.withinfo)
  | INTV of (int Support.Error.withinfo)
  | FLOATV of (float Support.Error.withinfo)
  | STRINGV of (string Support.Error.withinfo)
  | APOSTROPHE of (Support.Error.info)
  | DQUOTE of (Support.Error.info)
  | ARROW of (Support.Error.info)
  | BANG of (Support.Error.info)
  | BARGT of (Support.Error.info)
  | BARRCURLY of (Support.Error.info)
  | BARRSQUARE of (Support.Error.info)
  | COLON of (Support.Error.info)
  | COLONCOLON of (Support.Error.info)
  | COLONEQ of (Support.Error.info)
  | COLONHASH of (Support.Error.info)
  | COMMA of (Support.Error.info)
  | DARROW of (Support.Error.info)
  | DDARROW of (Support.Error.info)
  | DOT of (Support.Error.info)
  | EOF of (Support.Error.info)
  | EQ of (Support.Error.info)
  | EQEQ of (Support.Error.info)
  | EXISTS of (Support.Error.info)
  | GT of (Support.Error.info)
  | HASH of (Support.Error.info)
  | LCURLY of (Support.Error.info)
  | LCURLYBAR of (Support.Error.info)
  | LEFTARROW of (Support.Error.info)
  | LPAREN of (Support.Error.info)
  | LSQUARE of (Support.Error.info)
  | LSQUAREBAR of (Support.Error.info)
  | LT of (Support.Error.info)
  | RCURLY of (Support.Error.info)
  | RPAREN of (Support.Error.info)
  | RSQUARE of (Support.Error.info)
  | SEMI of (Support.Error.info)
  | SLASH of (Support.Error.info)
  | STAR of (Support.Error.info)
  | TRIANGLE of (Support.Error.info)
  | USCORE of (Support.Error.info)
  | VBAR of (Support.Error.info)
  | PLUS of (Support.Error.info)
  | MINUS of (Support.Error.info)

open Parsing
# 7 "parser.mly"
open Support.Error
open Support.Pervasive
open Syntax
(* Line 7, file parser.ml *)
let yytransl_const = [|
    0|]

let yytransl_block = [|
  257 (* PROGRAM *);
  258 (* WITH *);
  259 (* BEGIN *);
  260 (* END *);
  261 (* VAR *);
  262 (* CONST *);
  263 (* PROC *);
  264 (* INT *);
  265 (* BOOL *);
  266 (* NODECL *);
  267 (* IF *);
  268 (* THEN *);
  269 (* ELSE *);
  270 (* WHILE *);
  271 (* DO *);
  272 (* BREAK *);
  273 (* THROW *);
  274 (* TRY *);
  275 (* SKIP *);
  276 (* TRUE *);
  277 (* FALSE *);
  278 (* AND *);
  279 (* OR *);
  280 (* NOT *);
  281 (* DIV *);
  282 (* UCID *);
  283 (* LCID *);
  284 (* INTV *);
  285 (* FLOATV *);
  286 (* STRINGV *);
  287 (* APOSTROPHE *);
  288 (* DQUOTE *);
  289 (* ARROW *);
  290 (* BANG *);
  291 (* BARGT *);
  292 (* BARRCURLY *);
  293 (* BARRSQUARE *);
  294 (* COLON *);
  295 (* COLONCOLON *);
  296 (* COLONEQ *);
  297 (* COLONHASH *);
  298 (* COMMA *);
  299 (* DARROW *);
  300 (* DDARROW *);
  301 (* DOT *);
    0 (* EOF *);
  302 (* EQ *);
  303 (* EQEQ *);
  304 (* EXISTS *);
  305 (* GT *);
  306 (* HASH *);
  307 (* LCURLY *);
  308 (* LCURLYBAR *);
  309 (* LEFTARROW *);
  310 (* LPAREN *);
  311 (* LSQUARE *);
  312 (* LSQUAREBAR *);
  313 (* LT *);
  314 (* RCURLY *);
  315 (* RPAREN *);
  316 (* RSQUARE *);
  317 (* SEMI *);
  318 (* SLASH *);
  319 (* STAR *);
  320 (* TRIANGLE *);
  321 (* USCORE *);
  322 (* VBAR *);
  323 (* PLUS *);
  324 (* MINUS *);
    0|]

let yylhs = "\255\255\
\001\000\004\000\004\000\002\000\002\000\005\000\005\000\005\000\
\005\000\006\000\006\000\003\000\003\000\008\000\008\000\009\000\
\009\000\009\000\009\000\009\000\009\000\009\000\009\000\010\000\
\010\000\010\000\010\000\011\000\011\000\011\000\012\000\012\000\
\012\000\012\000\012\000\013\000\013\000\013\000\013\000\007\000\
\007\000\007\000\000\000"

let yylen = "\002\000\
\006\000\001\000\001\000\001\000\003\000\004\000\004\000\008\000\
\001\000\001\000\001\000\001\000\003\000\001\000\005\000\006\000\
\003\000\004\000\001\000\001\000\004\000\004\000\001\000\001\000\
\001\000\001\000\001\000\003\000\003\000\003\000\001\000\003\000\
\002\000\002\000\001\000\001\000\003\000\003\000\003\000\001\000\
\003\000\003\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\043\000\000\000\000\000\000\000\000\000\
\009\000\000\000\000\000\002\000\003\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\019\000\
\023\000\000\000\020\000\000\000\000\000\000\000\005\000\010\000\
\011\000\006\000\026\000\027\000\000\000\025\000\000\000\000\000\
\024\000\000\000\000\000\035\000\036\000\000\000\000\000\000\000\
\000\000\000\000\000\000\014\000\001\000\000\000\000\000\000\000\
\034\000\000\000\033\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\013\000\032\000\000\000\000\000\028\000\029\000\
\030\000\039\000\038\000\037\000\000\000\000\000\018\000\000\000\
\022\000\021\000\000\000\000\000\000\000\008\000\016\000\015\000"

let yydgoto = "\002\000\
\004\000\010\000\028\000\041\000\011\000\034\000\042\000\051\000\
\052\000\043\000\044\000\045\000\046\000"

let yysindex = "\004\000\
\033\255\000\000\015\255\000\000\120\255\255\254\255\254\255\254\
\000\000\038\255\250\254\000\000\000\000\030\255\032\255\022\255\
\159\255\120\255\106\255\085\255\255\254\085\255\085\255\000\000\
\000\000\145\255\000\000\080\255\246\254\035\255\000\000\000\000\
\000\000\000\000\000\000\000\000\085\255\000\000\085\255\085\255\
\000\000\240\254\031\255\000\000\000\000\072\255\054\255\004\255\
\247\254\120\255\096\255\000\000\000\000\085\255\085\255\159\255\
\000\000\245\254\000\000\085\255\085\255\161\255\161\255\161\255\
\085\255\085\255\085\255\106\255\145\255\145\255\100\255\145\255\
\240\254\016\255\000\000\000\000\072\255\072\255\000\000\000\000\
\000\000\000\000\000\000\000\000\049\255\110\255\000\000\159\255\
\000\000\000\000\145\255\145\255\124\255\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\126\255\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\127\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\001\255\006\255\000\000\000\000\020\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\057\255\000\000\000\000\000\000\034\255\087\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\251\255\240\255\250\255\000\000\069\000\097\000\052\000\
\242\255\246\255\000\000\067\000\056\000"

let yytablesize = 189
let yytable = "\014\000\
\015\000\016\000\030\000\007\000\001\000\070\000\060\000\031\000\
\031\000\031\000\029\000\060\000\031\000\060\000\047\000\069\000\
\005\000\031\000\031\000\029\000\031\000\040\000\040\000\040\000\
\012\000\013\000\060\000\031\000\031\000\054\000\031\000\040\000\
\040\000\003\000\040\000\042\000\042\000\042\000\060\000\075\000\
\017\000\030\000\040\000\055\000\071\000\042\000\042\000\076\000\
\042\000\029\000\061\000\079\000\080\000\081\000\018\000\061\000\
\042\000\061\000\017\000\017\000\017\000\007\000\029\000\029\000\
\031\000\029\000\031\000\019\000\031\000\017\000\061\000\093\000\
\031\000\030\000\090\000\021\000\062\000\020\000\040\000\063\000\
\040\000\029\000\061\000\053\000\029\000\029\000\040\000\064\000\
\041\000\041\000\041\000\068\000\042\000\065\000\042\000\056\000\
\066\000\072\000\041\000\041\000\042\000\041\000\088\000\057\000\
\035\000\036\000\059\000\091\000\037\000\041\000\012\000\013\000\
\038\000\032\000\033\000\077\000\078\000\017\000\048\000\049\000\
\086\000\087\000\092\000\089\000\006\000\007\000\008\000\096\000\
\004\000\009\000\012\000\082\000\083\000\084\000\067\000\058\000\
\085\000\000\000\039\000\000\000\000\000\000\000\094\000\095\000\
\000\000\041\000\050\000\041\000\000\000\000\000\073\000\074\000\
\040\000\041\000\000\000\022\000\000\000\000\000\023\000\000\000\
\024\000\025\000\026\000\027\000\000\000\000\000\000\000\000\000\
\000\000\022\000\012\000\013\000\023\000\000\000\024\000\025\000\
\026\000\027\000\000\000\000\000\035\000\036\000\000\000\000\000\
\012\000\013\000\012\000\013\000\038\000"

let yycheck = "\006\000\
\007\000\008\000\017\000\003\001\001\000\015\001\023\001\002\001\
\003\001\004\001\017\000\023\001\018\000\023\001\021\000\012\001\
\002\001\012\001\013\001\026\000\015\001\002\001\003\001\004\001\
\026\001\027\001\023\001\022\001\023\001\040\001\025\001\012\001\
\013\001\001\001\015\001\002\001\003\001\004\001\023\001\056\000\
\003\001\056\000\023\001\054\001\050\000\012\001\013\001\059\001\
\015\001\056\000\067\001\062\000\063\000\064\000\061\001\067\001\
\023\001\067\001\002\001\003\001\004\001\061\001\069\000\070\000\
\059\001\072\000\061\001\038\001\063\001\013\001\067\001\088\000\
\067\001\088\000\059\001\054\001\046\001\046\001\059\001\049\001\
\061\001\088\000\067\001\004\001\091\000\092\000\067\001\057\001\
\002\001\003\001\004\001\038\001\059\001\022\001\061\001\061\001\
\025\001\002\001\012\001\013\001\067\001\015\001\003\001\037\000\
\020\001\021\001\040\000\059\001\024\001\023\001\026\001\027\001\
\028\001\008\001\009\001\060\000\061\000\061\001\022\000\023\000\
\069\000\070\000\013\001\072\000\005\001\006\001\007\001\004\001\
\003\001\010\001\004\001\065\000\066\000\067\000\063\001\039\000\
\068\000\255\255\054\001\255\255\255\255\255\255\091\000\092\000\
\255\255\059\001\002\001\061\001\255\255\255\255\054\000\055\000\
\068\001\067\001\255\255\011\001\255\255\255\255\014\001\255\255\
\016\001\017\001\018\001\019\001\255\255\255\255\255\255\255\255\
\255\255\011\001\026\001\027\001\014\001\255\255\016\001\017\001\
\018\001\019\001\255\255\255\255\020\001\021\001\255\255\255\255\
\026\001\027\001\026\001\027\001\028\001"

let yynames_const = "\
  "

let yynames_block = "\
  PROGRAM\000\
  WITH\000\
  BEGIN\000\
  END\000\
  VAR\000\
  CONST\000\
  PROC\000\
  INT\000\
  BOOL\000\
  NODECL\000\
  IF\000\
  THEN\000\
  ELSE\000\
  WHILE\000\
  DO\000\
  BREAK\000\
  THROW\000\
  TRY\000\
  SKIP\000\
  TRUE\000\
  FALSE\000\
  AND\000\
  OR\000\
  NOT\000\
  DIV\000\
  UCID\000\
  LCID\000\
  INTV\000\
  FLOATV\000\
  STRINGV\000\
  APOSTROPHE\000\
  DQUOTE\000\
  ARROW\000\
  BANG\000\
  BARGT\000\
  BARRCURLY\000\
  BARRSQUARE\000\
  COLON\000\
  COLONCOLON\000\
  COLONEQ\000\
  COLONHASH\000\
  COMMA\000\
  DARROW\000\
  DDARROW\000\
  DOT\000\
  EOF\000\
  EQ\000\
  EQEQ\000\
  EXISTS\000\
  GT\000\
  HASH\000\
  LCURLY\000\
  LCURLYBAR\000\
  LEFTARROW\000\
  LPAREN\000\
  LSQUARE\000\
  LSQUAREBAR\000\
  LT\000\
  RCURLY\000\
  RPAREN\000\
  RSQUARE\000\
  SEMI\000\
  SLASH\000\
  STAR\000\
  TRIANGLE\000\
  USCORE\000\
  VBAR\000\
  PLUS\000\
  MINUS\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun parser_env ->
    let _1 = (peek_val parser_env 5 : Support.Error.info) in
    let _2 = (peek_val parser_env 4 : Support.Error.info) in
    let _3 = (peek_val parser_env 3 : 'DeclList) in
    let _4 = (peek_val parser_env 2 : Support.Error.info) in
    let _5 = (peek_val parser_env 1 : 'CmdListI) in
    let _6 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 123 "parser.mly"
        P (_3, _5) ) :  Syntax.prog ))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string Support.Error.withinfo) in
    Obj.repr((
# 127 "parser.mly"
      _1.v ) : 'Ident))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : string Support.Error.withinfo) in
    Obj.repr((
# 129 "parser.mly"
      _1.v ) : 'Ident))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Decl) in
    Obj.repr((
# 131 "parser.mly"
                                  _1 ) : 'DeclList))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Decl) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'DeclList) in
    Obj.repr((
# 132 "parser.mly"
                                  Sdecl (_1, _3) ) : 'DeclList))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : Support.Error.info) in
    let _2 = (peek_val parser_env 2 : 'Ident) in
    let _3 = (peek_val parser_env 1 : Support.Error.info) in
    let _4 = (peek_val parser_env 0 : 'Type) in
    Obj.repr((
# 136 "parser.mly"
      Var (_2, _4) ) : 'Decl))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : Support.Error.info) in
    let _2 = (peek_val parser_env 2 : 'Ident) in
    let _3 = (peek_val parser_env 1 : Support.Error.info) in
    let _4 = (peek_val parser_env 0 : 'Expr) in
    Obj.repr((
# 138 "parser.mly"
      Const (_2, _4) ) : 'Decl))
; (fun parser_env ->
    let _1 = (peek_val parser_env 7 : Support.Error.info) in
    let _2 = (peek_val parser_env 6 : 'Ident) in
    let _3 = (peek_val parser_env 5 : Support.Error.info) in
    let _4 = (peek_val parser_env 4 : 'Ident) in
    let _5 = (peek_val parser_env 3 : Support.Error.info) in
    let _6 = (peek_val parser_env 2 : 'Type) in
    let _7 = (peek_val parser_env 1 : Support.Error.info) in
    let _8 = (peek_val parser_env 0 : 'CmdList) in
    Obj.repr((
# 140 "parser.mly"
      Proc (_2, (_4, _6), _8) ) : 'Decl))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 142 "parser.mly"
      Nodecl ) : 'Decl))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 146 "parser.mly"
      Inteiro ) : 'Type))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 148 "parser.mly"
      Booleano ) : 'Type))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Command) in
    Obj.repr((
# 152 "parser.mly"
      _1 ) : 'CmdListI))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Command) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'CmdListI) in
    Obj.repr((
# 154 "parser.mly"
      Scmd (_1, _3) ) : 'CmdListI))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Command) in
    Obj.repr((
# 158 "parser.mly"
      _1 ) : 'CmdList))
; (fun parser_env ->
    let _1 = (peek_val parser_env 4 : Support.Error.info) in
    let _2 = (peek_val parser_env 3 : 'DeclList) in
    let _3 = (peek_val parser_env 2 : Support.Error.info) in
    let _4 = (peek_val parser_env 1 : 'CmdListI) in
    let _5 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 160 "parser.mly"
      With (_2, _4) ) : 'CmdList))
; (fun parser_env ->
    let _1 = (peek_val parser_env 5 : Support.Error.info) in
    let _2 = (peek_val parser_env 4 : 'Expr) in
    let _3 = (peek_val parser_env 3 : Support.Error.info) in
    let _4 = (peek_val parser_env 2 : 'CmdList) in
    let _5 = (peek_val parser_env 1 : Support.Error.info) in
    let _6 = (peek_val parser_env 0 : 'CmdList) in
    Obj.repr((
# 164 "parser.mly"
      If (_2, _4, _6) ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Ident) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'Expr) in
    Obj.repr((
# 166 "parser.mly"
      Atrib (_1, _3) ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : Support.Error.info) in
    let _2 = (peek_val parser_env 2 : 'Expr) in
    let _3 = (peek_val parser_env 1 : Support.Error.info) in
    let _4 = (peek_val parser_env 0 : 'CmdList) in
    Obj.repr((
# 168 "parser.mly"
      Wh (_2, _4) ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 170 "parser.mly"
      Break ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 172 "parser.mly"
      Skip ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : 'Ident) in
    let _2 = (peek_val parser_env 2 : Support.Error.info) in
    let _3 = (peek_val parser_env 1 : 'Expr) in
    let _4 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 174 "parser.mly"
      Call (_1, _3) ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 3 : Support.Error.info) in
    let _2 = (peek_val parser_env 2 : 'CmdList) in
    let _3 = (peek_val parser_env 1 : Support.Error.info) in
    let _4 = (peek_val parser_env 0 : 'CmdList) in
    Obj.repr((
# 176 "parser.mly"
      Try (_2, _4) ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 178 "parser.mly"
      Throw ) : 'Command))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Ident) in
    Obj.repr((
# 181 "parser.mly"
                                  Id (_1) ) : 'FatorVal))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : int Support.Error.withinfo) in
    Obj.repr((
# 182 "parser.mly"
                                  Num (_1.v) ) : 'FatorVal))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 183 "parser.mly"
                                  Bool (true) ) : 'FatorVal))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 184 "parser.mly"
                                  Bool (false) ) : 'FatorVal))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'FatorVal) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'FatorVal) in
    Obj.repr((
# 188 "parser.mly"
                                       Eq (_1, _3) ) : 'Comparacao))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'FatorVal) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'FatorVal) in
    Obj.repr((
# 189 "parser.mly"
                                       Gt (_1, _3) ) : 'Comparacao))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'FatorVal) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'FatorVal) in
    Obj.repr((
# 190 "parser.mly"
                                       Lt (_1, _3) ) : 'Comparacao))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'FatorVal) in
    Obj.repr((
# 193 "parser.mly"
                                  _1 ) : 'Fator))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : Support.Error.info) in
    let _2 = (peek_val parser_env 1 : 'Expr) in
    let _3 = (peek_val parser_env 0 : Support.Error.info) in
    Obj.repr((
# 194 "parser.mly"
                                  _2 ) : 'Fator))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : Support.Error.info) in
    let _2 = (peek_val parser_env 0 : 'Fator) in
    Obj.repr((
# 195 "parser.mly"
                                  Neg (_2) ) : 'Fator))
; (fun parser_env ->
    let _1 = (peek_val parser_env 1 : Support.Error.info) in
    let _2 = (peek_val parser_env 0 : 'Fator) in
    Obj.repr((
# 196 "parser.mly"
                                  Not (_2) ) : 'Fator))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Comparacao) in
    Obj.repr((
# 197 "parser.mly"
                                  _1 ) : 'Fator))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Fator) in
    Obj.repr((
# 200 "parser.mly"
                                  _1 ) : 'Termo))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Termo) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'Fator) in
    Obj.repr((
# 201 "parser.mly"
                                  Prod (_1, _3) ) : 'Termo))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Termo) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'Fator) in
    Obj.repr((
# 202 "parser.mly"
                                  Div (_1, _3) ) : 'Termo))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Termo) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'Fator) in
    Obj.repr((
# 203 "parser.mly"
                                  And (_1, _3) ) : 'Termo))
; (fun parser_env ->
    let _1 = (peek_val parser_env 0 : 'Termo) in
    Obj.repr((
# 205 "parser.mly"
                                  _1 ) : 'Expr))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Expr) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'Termo) in
    Obj.repr((
# 206 "parser.mly"
                                  Soma (_1, _3) ) : 'Expr))
; (fun parser_env ->
    let _1 = (peek_val parser_env 2 : 'Expr) in
    let _2 = (peek_val parser_env 1 : Support.Error.info) in
    let _3 = (peek_val parser_env 0 : 'Termo) in
    Obj.repr((
# 207 "parser.mly"
                                  Or (_1, _3) ) : 'Expr))
(* Entry toplevel *)
; (fun parser_env -> raise (YYexit (peek_val parser_env 0)))
|]
let yytables =
  { actions=yyact;
    transl_const=yytransl_const;
    transl_block=yytransl_block;
    lhs=yylhs;
    len=yylen;
    defred=yydefred;
    dgoto=yydgoto;
    sindex=yysindex;
    rindex=yyrindex;
    gindex=yygindex;
    tablesize=yytablesize;
    table=yytable;
    check=yycheck;
    error_function=parse_error;
    names_const=yynames_const;
    names_block=yynames_block }
let toplevel (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (yyparse yytables 1 lexfun lexbuf :  Syntax.prog )
