open Syntax
open Support.Error
(* Objetos Semanticos para verificacao de tipos *)

type qual = VAR | CTE | PROC

type cxt = (string * qual * tipo) list 

(* Verificadores de tipo 

   tyChckExpr : cxt * expr -> tipo
   tyChckDecl : cxt * decl -> cxt
   tyChckCmd  : cxt * cmd  -> bool
   tyChckPr   : cxt * prog -> bool

*)

exception TypeError of string

let rec achaTipo (cxt, nom) =
    match cxt with
        (nm, q, tipo)::cxt' -> 
          if (nom = nm) then
              tipo
          else
              achaTipo (cxt',nom);
      | [] -> raise (TypeError "Identificador nao definido")

let rec tipoQual (cxt,nom) =
    match cxt with
        [] -> raise (TypeError "Identificador nao definido");
      | (nm, q, tipo)::cxt' -> 
          if (nom = nm) then
              q
          else
              tipoQual (cxt',nom)


let rec tyChckExpr (cxt, expr) =
  match expr with
     Bool (_) -> Booleano;
    | Num (_) -> Inteiro;
    | Id (nm) -> achaTipo (cxt, nm);
    | Soma (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Inteiro &&
          tyChckExpr (cxt, e2) = Inteiro) then
          Inteiro
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Prod (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Inteiro &&
          tyChckExpr (cxt, e2) = Inteiro) then
          Inteiro
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Div (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Inteiro &&
          tyChckExpr (cxt, e2) = Inteiro) then
          Inteiro
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Neg (e1) ->
      if tyChckExpr (cxt, e1) = Inteiro then
          Inteiro
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Eq (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Inteiro &&
          tyChckExpr (cxt, e2) = Inteiro) then
          Booleano
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Lt (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Inteiro &&
          tyChckExpr (cxt, e2) = Inteiro) then
          Booleano
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Gt (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Inteiro &&
          tyChckExpr (cxt, e2) = Inteiro) then
          Booleano
      else
          raise (TypeError "Tipo incompativel: Esperando Inteiro, achei Booleano");
    | Not (e1) ->
      if tyChckExpr (cxt, e1) = Booleano then
          Booleano
      else
          raise (TypeError "Tipo incompativel: Esperando Booleano, achei Inteiro");
    | Or (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Booleano &&
          tyChckExpr (cxt, e2) = Booleano) then
          Booleano
      else
          raise (TypeError "Tipo incompativel: Esperando Booleano, achei Inteiro");
    | And (e1, e2) ->
      if (tyChckExpr (cxt, e1) = Booleano &&
          tyChckExpr (cxt, e2) = Booleano) then
          Booleano
      else
          raise (TypeError "Tipo incompativel: Esperando Booleano, achei Inteiro");
and
tyChckCmd (cxt, cmd) =
  match cmd with
      Skip -> true;
    | Throw -> true;
    | Break -> true;
    | If (expr, cmdT, cmdF) ->
        if (tyChckExpr (cxt, expr) = Booleano) then
            tyChckCmd (cxt, cmdT) && tyChckCmd (cxt, cmdF)
        else
            raise (TypeError "Tipo incompativel: Esperando expressao booleana, encontrei expressao inteira!");
    | Wh (expr, cmd) ->
        if (tyChckExpr (cxt, expr) = Booleano) then
            tyChckCmd (cxt, cmd)
        else
            raise (TypeError "Tipo incompativel: Esperando expressao booleana, encontrei expressao inteira!");
    | Atrib (nm, ex) ->
        if ((tyChckExpr (cxt, ex)) = (achaTipo(cxt,nm)) &&
            tipoQual (cxt, nm) = VAR) then
          true
        else
          raise (TypeError "Tentando atribuir valor a identificador que nao eh
          variavel!");
    | With (dec, cmd) ->
        let cxt' = tyChckDecl (cxt, dec)
        in tyChckCmd (cxt', cmd);
    | Scmd (c1, c2) ->
        tyChckCmd (cxt, c1) && tyChckCmd (cxt, c2);
    | Call (proc, expr) ->
        let prTip = achaTipo (cxt, proc)
        in if (prTip = Proced (tyChckExpr (cxt, expr) ) ) then
               true
           else raise (TypeError "Tipo incompativel na chamada de procedimento")
    | Try (c1, c2) ->
        tyChckCmd (cxt, c1) && tyChckCmd (cxt, c2);
and  
tyChckDecl (cx, dec) =
  match dec with
      Var (nm, tip) ->
        ((nm, VAR, tip)::cx);
    | Const (nm, ex) ->
        ((nm, CTE, tyChckExpr (cx, ex)))::cx;
    | Nodecl ->
        cx;
    | Sdecl (d1, d2) ->
        let cx2 = tyChckDecl (cx, d1)
        in tyChckDecl (cx2, d2);
    | Proc (nm, (pr, tipo), cmd) ->
        let cxt' = (nm, PROC, Proced(tipo))::cx in
        let cxt'' = (pr, CTE, tipo)::cxt'
        in if tyChckCmd (cxt', cmd) then
               cxt'
           else
               raise (TypeError "Erro na declaracao de procedimento")

let tyChckProg (cxt, prog) =
  match prog with
     P (d, c) -> 
         let cxt2 = tyChckDecl (cxt, d)
         in tyChckCmd (cxt2, c)


(* Objetos Semanticos para avaliadores  *)

type env_var = Addr of int
             | Clos of string * cmd * env
             | Valor of valores
and
     env = (string * env_var) list

type store = (int * valores) list

(*
   evalExpr : env * sto * expr -> env * sto * expr                     

*)

exception DivideByZero
exception NoRuleApplies of string

let rec achaValorNoStore (id,store) =
        match store with
        [] -> raise (NoRuleApplies "Endere�o de Inv�lido de Mem�ria")
        | (id2,valor)::str' -> if id = id2 then
                                    valor
                                else
                                    achaValorNoStore(id,str')                                

let rec achaValorNoEnv (nm, store, env) = 
                match env with
                 [] -> raise (NoRuleApplies "Identificador Inv�lido")
                | (nm2,env_var)::env' ->  
                                   if nm2 = nm then
                                           match env_var with
                                             Addr (n) -> achaValorNoStore (n,store)
                                           | Valor v -> v
                                   else
                                           achaValorNoEnv (nm, store, env')

let rec evalExpr e = match e with
        (Num(nm),store,env) -> ValNum(nm)
      | (Bool(b),store,env) -> ValBool(b)
      | (Id (nm),store,env) -> achaValorNoEnv(nm,store,env)
      | (Soma(e1,e2),store,env) -> 
             let (ValNum v1) = evalExpr (e1,store,env) in (*ou (v1,store,env)*)
             let (ValNum v2) = evalExpr (e2,store,env) in 
                        ValNum(v1+v2)
      | (Prod(e1,e2),store,env) ->
             let (ValNum v1) = evalExpr (e1,store,env) in 
                let (ValNum v2) = evalExpr (e2,store,env) in 
                        ValNum(v1*v2)
      | (Div(e1,e2),store,env) ->
             let (ValNum v1) = evalExpr (e1,store,env) in 
                let (ValNum v2) = evalExpr (e2,store,env) in 
                        if v2 = 0 then raise (DivideByZero) else
                                ValNum(v1/v2)
      | (And(e1,e2),store,env) ->
             let (ValBool v1) = evalExpr (e1,store,env) in 
                let (ValBool v2) = evalExpr (e2,store,env) in 
                       ValBool(v1 && v2) (*if v1 = False then False else
                             if v2 = False then False else True*)
      | (Or(e1,e2),store,env) ->
             let (ValBool v1) = evalExpr (e1,store,env) in 
                let (ValBool v2) = evalExpr (e2,store,env) in 
                        ValBool(v1 || v2)(*if v1 = True then True else
                             if v2 = True then True else False*)
      | (Eq(e1,e2),store,env) -> 
             let (ValNum v1) = evalExpr (e1,store,env) in 
                let (ValNum v2) = evalExpr (e2,store,env) in 
                        ValBool(v1 = v2) (*if v1 = v2 then True else False*)
      | (Lt(e1,e2),store,env) -> 
             let (ValNum v1) = evalExpr (e1,store,env) in 
                let (ValNum v2) = evalExpr (e2,store,env) in 
                        ValBool(v1 < v2) (*then True else False*)
      | (Gt(e1,e2),store,env) -> 
             let (ValNum v1) = evalExpr (e1,store,env) in 
                let (ValNum v2) = evalExpr (e2,store,env) in 
                        ValBool (v1 > v2) (*then True else False*)
      | (Neg(e),store,env) -> 
             let (ValNum v) = evalExpr (e,store,env) in 
                ValNum (-v)
      | (Not(e),store,env) -> 
             let (ValBool v) = evalExpr (e,store,env) in 
                ValBool(not v) (*if v = True then False else True*)
(*************REGRAS PARA DECLARA��ES*******************************)

let default tipo = match tipo with
          Booleano -> ValBool (false)
        | Inteiro -> ValNum(0)
        | _ -> raise (NoRuleApplies "vai saber neh...")

let new_id store = match store with
          [] -> 1
        | ((addr, _)::_) -> addr+1

let rec alteraStore st id novo =
        match st with
                (id2, valor)::tl -> if id = id2
                                        then (id, novo)::tl
                                        else (id2, valor)::(alteraStore tl id novo)
               | [] -> raise (NoRuleApplies "acho q o sistema de tipos nao funciona mto bem.......")

let rec alteraVariavel env st nome valor =
        match env with
                (nm, env_var)::tl -> if nm = nome
                                        then match env_var with
                                                  Addr (ad) -> alteraStore st ad valor
                                                | _ -> raise (NoRuleApplies "e o sistema de tipos dah pau denoooovo!")
                                        else alteraVariavel tl st nome valor
              | [] -> raise (NoRuleApplies "mas que po@#$@#$ de sistema de tipos
              (e de quebra de linhaas ��!!!")
                                        
                

let rec evalDecl d = match d with
         (Var(nm,tipo),store,env) ->
                 let id = new_id store in
                 let store' = (id, default tipo)::store in
                 let env' = (nm, Addr id)::env
                 in (Nodecl, store', env')
                (*(Nodecl,novo store com default,associar nm com defaut)*) 
        | (Const(nm,exp),store,env) -> 
                 let v = evalExpr (exp,store,env) in 
                 let env' = (nm, Valor v)::env in
                 (Nodecl, store, env')
                    (*(Nodecl,store,associar nm com v)*)
        | (Proc(nm,(pr,tipo),cmd),store,env) ->
                 (Nodecl, store, ((nm, Clos (pr, cmd, env))::env))
              (*uhhh.... isso aqui vai ser legal... hehehehe*)
        | (Sdecl(d1,d2),store,env) -> 
                 let (_,store',env') = evalDecl (d1,store,env) in (*pode!*)
                    let (_,store'',env'') = evalDecl (d2,store',env') in
                               (Nodecl,store'',env'')
        | (_, store, env) -> (Nodecl, store, env)

(*************REGRAS PARA COMANDOS**********************************)
let rec evalCmd c = match c with        
          (Skip,store,env) -> (Skip,store)
        | (Break,store,env) -> (Break,store)
        | (Throw,store,env) -> (Throw,store)
        | (If(expr,cmdT,cmdF),store,env) ->
                let v = evalExpr (expr,store,env) in
                        if v = ValBool (true) then 
                                evalCmd (cmdT,store,env)
                        else
                                evalCmd (cmdF,store,env)

        | (Atrib(nm,ex),store,env) ->
                        let v = evalExpr (ex,store,env) in
                                (Skip, alteraVariavel env store nm v)
        | (Scmd (c1, c2),store,env) ->
                        let (c', st') = evalCmd (c1, store, env) in
                        if c' = Throw || c' = Break 
                                then (c', st')
                                else evalCmd (c2, st', env)
                                        
                        
        | (Wh(expr,cmd),store,env) ->
                        let v = evalExpr(expr,store,env) in
                                if v = ValBool (false) then (Skip,store) 
                                else
                                     let (cmd',store') = evalCmd (cmd,store,env) in
                                     if cmd' = Break
                                        then (Skip, store')
                                        else if cmd' = Throw
                                                then (Throw, store')
                                                else evalCmd (Wh(expr,cmd),store',env)
        | (With (dec, cmd),store,env) ->
                        let (d', store', env') = evalDecl (dec, store, env) in
                        evalCmd (cmd, store', env')
        | (Call (proc, expr),store,env) ->
                        let (Clos (param, cmd, env')) = achaProc (proc, env) in
                        let valor = evalExpr (expr, store, env) in
                        let env'' = ((param, Valor (valor))::env') in
                        evalCmd (cmd, store, env'')
                                    
(*        | (Try(c1,c2),store,env) -> 


    | Call (proc, expr) ->
        let prTip = achaTipo (cxt, proc)
        in if (prTip = Proced (tyChckExpr (cxt, expr) ) ) then
               true
           else raise (TypeError "Tipo incompativel na chamada de procedimento")
    | Try (c1, c2) ->
        tyChckCmd (cxt, c1) && tyChckCmd (cxt, c2);
*) 
      | _ -> raise (NoRuleApplies "faltou!!!!")

let evalProg prog =
  match prog with
     P (d, c) -> 
         let (d', store, env) = evalDecl (d, [], []) in
         let (c', store') = evalCmd (c, store, env) in
         (store', env)
