open Format
open Support.Error
open Support.Pervasive

(* ---------------------------------------------------------------------- *)
(* Datatypes *)

type valores = 
             | ValNum of int
             | ValBool of bool

type expr =
          | Id of string
          | Num of int
          | Bool of bool
          | Soma of expr * expr
          | Prod of expr * expr
          | Div  of expr * expr
          | And  of expr * expr
          | Or   of expr * expr
          | Eq   of expr * expr
          | Gt   of expr * expr
          | Lt   of expr * expr
          | Neg  of expr
          | Not  of expr

type tipo =
          | Inteiro
          | Booleano
          | Proced of tipo

type decl =
          | Var of string * tipo
          | Const of string * expr
          | Proc of string * (string * tipo) * cmd
          | Nodecl
          | Sdecl of decl * decl
and
     cmd =
         | Skip
         | Throw
         | Break
         | Atrib of string * expr
         | If of expr * cmd * cmd
         | Wh of expr * cmd
         | Call of string * expr
         | With of decl * cmd
         | Scmd of cmd * cmd
         | Try of cmd * cmd

type prog = P of decl * cmd

(* ---------------------------------------------------------------------- *)
(* Extracting file info *)

(* ---------------------------------------------------------------------- *)
(* Printing *)

(* The printing functions call these utility functions to insert grouping
  information and line-breaking hints for the pretty-printing library:
     obox   Open a "box" whose contents will be indented by two spaces if
            the whole box cannot fit on the current line
     obox0  Same but indent continuation lines to the same column as the
            beginning of the box rather than 2 more columns to the right
     cbox   Close the current box
     break  Insert a breakpoint indicating where the line maybe broken if
            necessary.
  See the documentation for the Format module in the OCaml library for
  more details. 
*)

let obox0() = open_hvbox 0
let obox() = open_hvbox 2
let cbox() = close_box()
let break() = print_break 0 0


let rec printtm_Type outer t = match t with
    Inteiro ->
      pr "Int";
  | Booleano ->
      pr "Bool";
  | Proced (tip) ->
      pr "Proc(";
      printtm_Type outer tip;
      pr ")"
           

let rec printtm_Expr outer t = match t with
   Id (id) -> pr id;
 | Num (num) -> pr (string_of_int num);
 | Bool (tf) -> pr (string_of_bool tf);
 | Soma (e1, e2) ->
       pr "Soma(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Prod (e1, e2) ->
       pr "Prod(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Div (e1, e2) ->
       pr "Div(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | And (e1, e2) ->
       pr "And(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Or (e1, e2) ->
       pr "Or(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Gt (e1, e2) ->
       pr "Gt(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Lt (e1, e2) ->
       pr "Lt(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Eq (e1, e2) ->
       pr "Eq(";
       printtm_Expr outer e1;
       pr ", ";
       printtm_Expr outer e2;
       pr ")";
 | Neg e1 ->
       pr "Neg ";
       printtm_Expr outer e1;
 | Not e1 ->
       pr "Not ";
       printtm_Expr outer e1


let rec printtm_Decl outer t = match t with
    Var (id, tipo) ->
      pr "Var ";
      pr id;
      pr ":";
      printtm_Type outer tipo;
      print_space();
  | Const (id2, e1) ->
      pr "Const ";
      pr id2;
      pr " = ";
      printtm_Expr outer e1; 
  | Sdecl (decl1, decl2) ->
      printtm_Decl outer decl1;
      pr ";";
      force_newline();
      printtm_Decl outer decl2;
  | Proc (nm, (parN, parT), cmd) -> 
      pr "Proc ";
      pr nm;
      pr "(";
      pr parN;
      pr ":";
      printtm_Type outer parT;
      pr ")";
      printtm_Cmd false cmd;
  | Nodecl ->
      pr "Nodecl"
and 
printtm_Cmd outer t = match t with
    Skip -> pr "Skip";
  | Throw -> pr "Throw";
  | Break -> pr "Break";
  | Atrib (id, valor) ->
      pr id;
      pr " := ";
      printtm_Expr outer valor;
  | If (cond, cTrue, cFalse) ->
      pr "If ";
      printtm_Expr false cond;
      pr " Then ";
      printtm_Cmd false cTrue;
      pr " Else ";
      printtm_Cmd false cFalse;
  | Wh (cond, cmd) ->
      pr "While ";
      printtm_Expr false cond;
      pr " Do ";
      printtm_Cmd false cmd;
  | Call (proc, valor) ->
     pr proc;
     pr "(";
     printtm_Expr false valor;
     pr ")";
  | With (decl, cmd) ->
     pr "With ";
     printtm_Decl false decl;
     pr " Do ";
     printtm_Cmd false cmd;
  | Scmd (c1, c2) ->
     printtm_Cmd false c1;
     pr ";";
     force_newline();
     printtm_Cmd false c2;
  | Try (c1, c2) ->
     pr "Try ";
     printtm_Cmd false c1;
     pr " With ";
     printtm_Cmd false c2


let printtm_Prog outer t = match t with
    P(dec,cmd) ->
       obox0();
       pr "Program With ";
       obox();
       force_newline();
       printtm_Decl false dec;
       cbox();
       force_newline();
       pr "begin";
       obox();
       force_newline();
       printtm_Cmd false cmd;
       cbox();
       force_newline();
       pr "end";
       cbox()

let printtm t = printtm_Prog true t
